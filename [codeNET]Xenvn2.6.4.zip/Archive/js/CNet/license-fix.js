/*
 * CNet Tools compatibility shim.
 *
 * setting.min.js shipped with an unrelated XenVn license prompt.  Patch only
 * that exact message and leave all normal XenForo alerts untouched.
 */
(function () {
    function patch() {
        if (!window.XF || typeof XF.alert !== 'function' || XF.__cnetLicenseAlertFixed) {
            return;
        }

        var alert = XF.alert;
        XF.alert = function (message) {
            if (String(message || '').indexOf('Please activate ' + 'XenVn addon license!') !== -1) {
                return;
            }
            return alert.apply(this, arguments);
        };
        XF.__cnetLicenseAlertFixed = true;
    }

    patch();
    if (!window.XF || typeof XF.alert !== 'function') {
        document.addEventListener('DOMContentLoaded', patch, { once: true });
    }
}());