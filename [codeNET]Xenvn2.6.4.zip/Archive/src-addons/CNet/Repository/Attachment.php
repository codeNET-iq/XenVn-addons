<?php
/* Developed by CNet Tools */
namespace CNet\Repository;
class Attachment extends XFCP_Attachment
{
	public function getDefaultAttachmentConstraints()
	{
		$_ = $this->options();
		$__ = \XF::visitor();
		$___ = 0;
		$____ = $this->app()->uploadMaxFilesize / 1024;
		if ($__->is_admin || $__->is_moderator || $__->isUpgradeUser())
			$___ = $_->cnet_max_file_size;
		if (!$___)
			$___ = $_->attachmentMaxFileSize;
		$_____ = round(min($____, $___));
		return [
			'extensions' => preg_split('/\s+/', trim($_->attachmentExtensions), -1, PREG_SPLIT_NO_EMPTY),
			'size' => $_____ * 1024,
			'width' => $_->attachmentMaxDimensions['width'],
			'height' => $_->attachmentMaxDimensions['height'],
			'count' => $_->attachmentMaxPerMessage
		];
	}
	public function applyVideoAttachmentConstraints(array $_)
	{
		$__ = $this->options();
		$___ = \XF::visitor();
		$_ = parent::applyVideoAttachmentConstraints($_);
		if (!empty($__->allowVideoUploads['enabled']) && ($___->is_admin || $___->is_moderator || $___->isUpgradeUser())) {
			$____ = $__->cnet_max_file_size;
			$_____ = $__->allowVideoUploads['size'];
			$______ = max($____, $_____);
			$_['video_size'] = $______ * 1024;
		}
		return $_;
	}
	public function logAttachmentView(\XF\Entity\Attachment $_)
	{
		$__ = $this->app()->options()->cnet_attachment_acceleration;
		if ($__ && $__ != 'disable' && isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $___)) {
			if ($___[1] != '' && intval($___[1] != 0))
				return true;
		}
		return parent::logAttachmentView($_);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */