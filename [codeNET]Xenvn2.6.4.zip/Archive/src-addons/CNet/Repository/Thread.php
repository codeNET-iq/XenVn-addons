<?php
/* Developed by CNet Tools */
namespace CNet\Repository;
class Thread extends XFCP_Thread
{
	public function markThreadReadByUser(\XF\Entity\Thread $_, \XF\Entity\User $__, $___ = null)
	{
		if ($___ < $_->last_post_date)
			$___ = $_->last_post_date;
		return parent::markThreadReadByUser($_, $__, $___);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */