<?php
/* Developed by CNet Tools */
namespace CNet\Admin\View\Attachment;
class View extends XFCP_View
{
	public function renderRaw()
	{
		return $this->repoUtility()->renderRawAttachment($this->params, $this->response);
	}
	protected function repoUtility()
	{
		return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */