<?php
/* Developed by CNet Tools */
namespace CNet\Admin\View;
class Raw extends \CNet\Pub\View\Raw {}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */