<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Mvc\ParameterBag;
use XF\Db\Schema\Alter;
class AddOn extends XFCP_AddOn
{
	public function actionOptions(ParameterBag $_)
	{
		$this->assertAdminPermission('option');
		$__ = $this->assertAddOnAvailable($_->addon_id_url);
		if ($__ && $__->addon_id == "CNet")
			return $this->redirect($this->buildLink('cnet/setting'));
		return parent::actionOptions($_);
	}
	public function actionUpgrade(ParameterBag $_)
	{
		$__ = $this->assertAddOnAvailable($_->addon_id_url);
		if ($__ && $__->addon_id == "CNet") {
			if ($this->repoUtility()->getCache("cnet\x49\x73\x4e\x6f\x74\x69\x63\x65") || stripos($__->title, "CNet") === false)
				return $this->error(\XF::phrase('this_add_on_cannot_be_upgraded'));
		}
		return parent::actionUpgrade($_);
	}
	public function actionRebuild(ParameterBag $_)
	{
		$__ = $this->assertAddOnAvailable($_->addon_id_url);
		if ($__ && $__->addon_id == "CNet") {
			if ($this->repoUtility()->getCache("cnet\x49\x73\x4e\x6f\x74\x69\x63\x65") || stripos($__->title, "CNet") === false)
				return $this->error(\XF::phrase('this_add_on_cannot_be_rebuilt'));
		}
		return parent::actionRebuild($_);
	}
	protected function installColumnXFRM()
	{
		$_ = $this->app()->db()->getSchemaManager();
		$__ = 'xf_rm_resource';
		if ($_->tableExists($__)) {
			$_->alterTable($__, function (Alter $___) use ($_, $__) {
				if (!$_->columnExists($__, 'image'))
					$___->addColumn('image', 'varchar', 500)->setDefault('');
				if (!$_->columnExists($__, 'description'))
					$___->addColumn('description', 'varchar', 500)->setDefault('');
				if (!$_->columnExists($__, 'scheduled'))
					$___->addColumn('scheduled', 'int')->setDefault(0);
			});
		}
	}
	public function actionFinalize(ParameterBag $_)
	{
		$__ = $this->getAddOnIfAvailable($_->addon_id_url);
		$___ = $this->filter('a', 'str');
		if ($__ && $__->addon_id == "CNet" && ($___ == 'upgrade' || $___ == 'rebuild')) {
			$this->app()->jobManager()->enqueueUnique(
				'cnetAddonHeathCheck',
				"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
				['job_type' => 'health_check'],
				false
			);
		}
		if ($__ && $__->addon_id == 'XFRM' && $___ == 'install')
			$this->installColumnXFRM();
		return parent::actionFinalize($_);
	}
	public function actionInstallFromArchiveConfirm()
	{
		$_ = $this->assertRecordExists('XF:AddOnInstallBatch', $this->filter('batch_id', 'uint'));
		$__ = $_->getPlannedActions();
		foreach ($__ as $___ => $____) {
			if ($___ == "CNet" && ($this->repoUtility()->getCache("cnet\x49\x73\x4e\x6f\x74\x69\x63\x65") || stripos($____['title'], "CNet") === false)) {
				if ($____['action'] == 'upgrade')
					return $this->error(\XF::phrase('this_add_on_cannot_be_upgraded'));
				if ($____['action'] == 'rebuild')
					return $this->error(\XF::phrase('this_add_on_cannot_be_rebuilt'));
			}
		}
		return parent::actionInstallFromArchiveConfirm();
	}
	public function actionInstallFromArchiveComplete()
	{
		$_ = $this->assertRecordExists('XF:AddOnInstallBatch', $this->filter('batch_id', 'uint'));
		foreach ($_['results'] as $__ => $___) {
			if ($__ == "CNet" && $___['status'] != 'error' && ($___['action'] == 'upgrade' || $___['action'] == 'rebuild')) {
				$this->app()->jobManager()->enqueueUnique(
					'cnetAddonHeathCheck',
					"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
					['job_type' => 'health_check'],
					false
				);
			}
			if ($__ == 'XFRM' && $___['status'] != 'error' && $___['action'] == 'install')
				$this->installColumnXFRM();
		}
		return parent::actionInstallFromArchiveComplete();
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */