<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Mvc\ParameterBag;
class Option extends XFCP_Option
{
	public function actionGroup(ParameterBag $_)
	{
		$__ = $this->assertGroupExists($_['group_id']);
		$___ = $__->AddOn;
		if ($___ && $___->active && $___->addon_id == "CNet")
			return $this->redirect($this->buildLink('cnet/setting'));
		return parent::actionGroup($_);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */