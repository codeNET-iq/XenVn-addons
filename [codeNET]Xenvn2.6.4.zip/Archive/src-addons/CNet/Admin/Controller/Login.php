<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Mvc\ParameterBag;
use XF\Pub\App;
class Login extends XFCP_Login
{
	protected function preDispatchController($_, ParameterBag $__)
	{
		App::$allowPageCache = false;
	}
	public function actionLogin()
	{
		$_ = $this->app->options();
		$__ = $_->cnet_login_security ?? false;
		if ($__ && $this->isPost()) {
			$___ = str_ireplace('www.', '', parse_url($_->boardUrl, PHP_URL_HOST));
			$____ = str_ireplace('www.', '', parse_url($this->app->request()->getHostUrl(), PHP_URL_HOST));
			$_____ = $this->filter('login', 'str');
			$_____ = str_replace(['"', "'", "`"], '', $_____);
			$_____ = trim($_____);
			if ($___ == $____ && $_____) {
				$______ = [['username', '=', $_____], ['email', '=', $_____]];
				$_______ = $this->app['session.public']['userId'] ?? false;
				if ($_______)
					$______[] = ['user_id', '=', $_______];
				$________ = $this->finder('XF:User')->whereOr($______)->fetchOne();
				if ($________) {
					if ($________->username == $_____ || $________->email == $_____)
						return parent::actionLogin();
					$_________ = $this->app->request()->getIp();
					$_________ = @inet_pton($_________);
					if (!$_________)
						return parent::actionLogin();
					$__________ = $this->finder('XF:Ip')
						->where('content_type', 'user')
						->where('content_id', $________->user_id)
						->where('ip', $_________)
						->where('log_date', '>', \XF::$time - 86400)
						->whereOr([['action', '=', 'login'], ['action', '=', 'cookie_login'], ['action', '=', 'login_admin']])
						->fetch()->count();
					if ($__________)
						return parent::actionLogin();
				}
				return $this->error(\XF::phrase('cnet_login_admin_to_forum_first', ['url' => $this->app->router('public')->buildLink('index')]));
			}
		}
		return parent::actionLogin();
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */