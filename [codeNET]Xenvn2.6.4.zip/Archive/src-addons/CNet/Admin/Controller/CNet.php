<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Admin\Controller\AbstractController;
use XF\Util\File;
class CNet extends AbstractController
{
	public function actionSetting()
	{
		$this->setSectionContext('cnet_addons_setting');
		$_ = $this->assertRecordExists('XF:OptionGroup', 'cnet');
		if ($_->AddOn && !$_->AddOn->active) {
			return $this->error(\XF::phrase('option_group_belongs_to_disabled_addon', [
				'addon' => $_->AddOn->title,
				'link' => $this->buildLink('add-ons')
			]));
		}
		$__ = $this->repository('XF:Option');
		$___ = [
			'template' => 'setting',
			'group' => $_,
			'groups' => $__->findOptionGroupList()->fetch(),
			'canAdd' => $__->canAddOption()
		];
		return $this->view("CNet\x3aCNet\x5c\x53\x65\x74\x74\x69\x6e\x67", 'cnet_admin_template', $___);
	}
	public function actionUpdate()
	{
		$this->assertPostOnly();
		$_ = $this->filter([
			'options_listed' => 'array-str',
			'options' => 'array',
		]);
		$__ = [];
/*
 * Custom callback controls must also be accepted when XF does not emit the
 * hidden options_listed input (this happened with the broken callback
 * renderer). Keep the normal listed options behaviour, then include every
 * option actually posted by this CNet form.
 */
$____ = array_unique(array_merge(
$_['options_listed'],
array_keys($_['options'])
));
foreach ($____ as $___) {
			if (!isset($_['options'][$___])) {
				$__[$___] = false;
			} else {
				$__[$___] = $_['options'][$___];
			}
		}
		$this->getOptionRepo()->updateOptions($__);
		return $this->redirect($this->getDynamicRedirect($this->buildLink('cnet/setting'), false));
	}
	public function actionCheck()
	{
		$this->setSectionContext('cnet_health_check');
		$_ = $this->service("CNet\x3a\x48\x65\x61\x6c\x74\x68");
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			$_->fileCheck();
			return $this->redirect($this->buildLink('cnet/check'));
		}
		$__ = [
			'fileCheck' => $_->getResult()
		];
		return $this->view("CNet\x3aCNet\x5c\x43\x68\x65\x63\x6b", 'cnet_file_check', $__);
	}
	public function actionScanner()
	{
		if ($this->getNotice())
			return $this->redirect($this->buildLink('cnet/check'));
		$this->setSectionContext('cnet_malware_scanner');
		$_ = $this->filter('run', 'int');
		$__ = '';
		$___ = $this->service("CNet\x3a\x53\x63\x61\x6e\x6e\x65\x72");
		$____ = $this->repoUtility();
		$_____ = '';
		if ($this->isPost() && $this->filter('do_upload', 'str') == 1) {
			$______ = \XF::phrase('error...');
			$this->assertValidCsrfToken();
			$this->setResponseType('json');
			$_______ = $this->request->getFile('upload', false, false);
			if ($_______) {
				$________ = [];
				if (!$_______->isValidFile($________)) {
					$_________ = reset($________);
					return $this->error($_________);
				}
				$__________ = $_______->getTempFile();
				$___________ = $_______->getFileName();
				$____________ = $_______->getExtension();
				$_____________ = File::getTempFile();
				move_uploaded_file($__________, $_____________);
				$______ = $___->scanFiles($_____________, $____________);
				if (is_array($______))
					$______ = \XF::phrase('cnet_scan_result_x', $______);
				else if ($______ === true)
					$______ = '<b>' . \XF::phrase('results') . '</b>: <span class="cnet-scan cnet-file">' . \XF::phrase('clean') . '</span>';
				else
					$______ = '<b>' . \XF::phrase('results') . '</b>: <span class="cnet-scan cnet-detect">' . \XF::phrase('unknown') . '</span>';
			}
			$______________ = $this->view();
			$______________->setJsonParams([
				'result' => $______,
				'filename' => $___________
			]);
			return $______________;
		}
		$_______________ = ['reports' => [], 'files_scanned' => 0, 'files_infected' => 0, 'time' => 0];
		$________________ = 0;
		if ($_ == -1) {
			$this->assertValidCsrfToken();
			$_____ = [\XF::phrase('running')];
			$________________ = \XF::$time;
			$_________________ = $___->scanList();
			if (is_array($_________________)) {
				$____->setCache([
					'cnetFiles' => $_________________,
					'cnetReports' => $_______________
				]);
				$__ = $this->buildLink('cnet/scanner&run=1');
			} else
				$_____ = [$_________________];
		} else if ($_ > 0) {
			[$_________________, $_______________] = $____->getCache(['cnetFiles', 'cnetReports']);
			$__________________ = count($_________________);
			$___________________ = 500;
			$____________________ = ($_ - 1) * $___________________;
			$_________________ = array_slice($_________________, $____________________, $___________________);
			[$_____________________, $______________________, $_____] = $___->scanFiles($_________________);
			$_______________['files_scanned'] += $_____________________;
			$_______________['files_infected'] += $______________________;
			$_______________['reports'] = array_merge($_______________['reports'], $_____);
			$________________ = $_______________['time'] = \XF::$time;
			$____->setCache('cnetReports', $_______________);
			$_____ = [\XF::phrase('running') . ' ' . min($____________________, $__________________) . '/' . $__________________];
			if ($____________________ < $__________________)
				$__ = $this->buildLink('cnet/scanner', '', ['run' => $_ + 1]);
			else {
				$____->setCache('cnetFiles', []);
				$__ = $this->buildLink('cnet/scanner');
			}
		} else {
			$_______________________ = $____->getCache('cnetReports');
			if ($_______________________ && isset($_______________________['reports'])) {
				$_____ = $_______________________['reports'];
				foreach ($_____ as $________________________ => $_________________________) {
					if (!$_________________________ || !isset($_________________________['path'])) {
						unset($_____[$________________________]);
						continue;
					}
					$__________________________ = '<b class="cnet-scan cnet-file">File:</b> ' . $_________________________['path'] . '<br /><b class="cnet-scan cnet-detect">Detect: </b>' . $_________________________['detect'] . '<br /><b class="cnet-scan cnet-line">Line</b>: ' . $_________________________['line'];
					$_____[$________________________] = $__________________________;
				}
				$___________________________ = '<b>Base directory:</b> ' . str_replace('\\', '/', \XF::getRootDirectory()) . '<br />';
				$___________________________ .= '<b>File types:</b> .php, .zip, .txt<br />';
				$___________________________ .= '<b>Max size (system scan):</b> 5 MB<br />';
				$___________________________ .= '<b>Total files scanned:</b> ' . $_______________________['files_scanned'] . '<br />';
				$___________________________ .= '<b>Total files infected:</b> ' . $_______________________['files_infected'];
				$_____[] = $___________________________;
				$________________ = $_______________________['time'];
			}
		}
		$____________________________ = [
			'reports' => $_____,
			'url' => $__,
			'time' => $________________,
			'count' => $_______________['files_infected'],
			'extensions' => '.php, .zip, .txt'
		];
		return $this->view("CNet\x3aCNet\x5c\x53\x63\x61\x6e\x6e\x65\x72", 'cnet_malware_scanner', $____________________________);
	}
	public function actionLimit()
	{
		if ($this->getNotice())
			return $this->redirect($this->buildLink('cnet/check'));
		$this->setSectionContext('cnet_limit_download_log');
		$_ = $this->filterPage();
		$__ = 20;
		$___ = $this->app->addonManager()->getById('XFRM');
		$____ = false;
		if ($___ && $___->isActive()) {
			$_____ = ['User', 'Thread', 'ResourceItem'];
			$____ = true;
		} else
			$_____ = ['User', 'Thread'];
		if ($this->filter('search', 'str')) {
			$this->assertValidCsrfToken();
			$______ = trim($this->filter('search', 'str'));
			if (!empty($______)) {
				$______ = str_replace(['"', "'", "`"], '', $______);
				if (strlen($______) >= 3) {
					if ($this->isPost())
						return $this->redirect($this->buildLink('cnet/limit', '', ['search' => $______, '_xfToken' => $this->app['csrf.token']]));
					$_______ = $this->app()->db()->escapeLike($______, '%?%');
					$________ = [['User.username', 'LIKE', $_______], ['Thread.title', 'LIKE', $_______], ['Attachment.Data.filename', 'LIKE', $_______], ['ip', 'LIKE', $_______]];
					if ($____)
						$________[] = ['ResourceItem.title', 'LIKE', $_______];
					$_________ = $this->finder("CNet\x3a\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x4c\x6f\x67")
						->where('log_time', '>', \XF::$time - 2592000)
						->whereOr($________)
						->with($_____)
						->order('log_time', 'DESC')
						->limitByPage($_, $__);
					$__________ = $_________->fetch();
					if (!$__________->count())
						$__________ = false;
					$___________ = $_________->total();
					$this->assertValidPage($_, $__, $___________, 'cnet/limit');
					$____________ = [
						'entries' => $__________,
						'page' => $_,
						'perPage' => $__,
						'total' => $___________,
						'search' => $______
					];
					return $this->view("CNet\x3aCNet\x5c\x4c\x69\x6d\x69\x74", 'cnet_limit_download_log', $____________);
				}
			}
		}
		$_________ = $this->finder("CNet\x3a\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x4c\x6f\x67")
			->where('log_time', '>', \XF::$time - 2592000)
			->with($_____)
			->order('log_time', 'DESC')
			->limitByPage($_, $__);
		$__________ = $_________->fetch();
		if (!$__________->count())
			$__________ = false;
		$___________ = $_________->total();
		$this->assertValidPage($_, $__, $___________, 'cnet/limit');
		$____________ = [
			'entries' => $__________,
			'page' => $_,
			'perPage' => $__,
			'total' => $___________,
			'search' => ''
		];
		return $this->view("CNet\x3aCNet\x5c\x4c\x69\x6d\x69\x74", 'cnet_limit_download_log', $____________);
	}
	public function actionFiles()
	{
		if ($this->getNotice())
			return $this->redirect($this->buildLink('cnet/check'));
		$this->setSectionContext('cnet_files_manager');
		$_ = $this->filterPage();
		$__ = 20;
		$___ = \XF::visitor()->is_super_admin;
		$____ = $this->filter('path', 'str');
		if ($____ == '.' || strpos($____, '..') !== false)
			return $this->redirect($this->buildLink('cnet/files'));
		$_____ = $this->service("CNet\x3a\x46\x69\x6c\x65\x73");
		$_____->initialize();
		if ($this->filter('backup', 'str')) {
			$this->assertValidCsrfToken();
			if (!$___)
				return $this->noPermission();
			$_____->createBackup();
			return $this->redirect($this->buildLink('cnet/files', '', ['path' => $____, 'page' => ($_ > 1 ? $_ : '')]));
		} else if ($this->filter('info', 'str')) {
			$this->assertValidCsrfToken();
			if (!$___)
				return $this->noPermission();
			[$______, $_______, $________, $_________, $__________, $___________, $____________, $_____________, $______________, $_______________] = $_____->getOSInfo();
			$________________ = [
				'info' => 1,
				'os' => $______,
				'page' => $_,
				'cpu_name' => $_______,
				'cpu_speed' => $________,
				'disk_total' => $____________,
				'disk_free' => $_____________,
				'cpu_cores' => $_________,
				'ram_total' => $__________,
				'ram_free' => $___________,
				'php_ini' => @php_ini_loaded_file(),
				'open_basedir' => $______________,
				'disable_functions' => @ini_get('disable_functions'),
				'error' => $_______________
			];
			return $this->view("CNet\x3aCNet\x5c\x46\x69\x6c\x65\x73", 'cnet_file_manager', $________________);
		} else if ($this->filter('sql', 'str')) {
			$this->assertValidCsrfToken();
			if (!$___)
				return $this->noPermission();
			$_________________ = $__________________ = $_______________ = '';
			if ($this->isPost()) {
				$this->setResponseType('json');
				[$_________________, $__________________, $_______________] = $_____->getSqlQuery($this->app->db(), $this->filter('query', 'str'));
			}
			$________________ = [
				'sql' => 1,
				'page' => $_,
				'query' => $_________________,
				'response' => $__________________,
				'error' => $_______________
			];
			return $this->view("CNet\x3aCNet\x5c\x46\x69\x6c\x65\x73", 'cnet_file_manager', $________________);
		} else if ($___________________ = $this->filter('edit', 'str')) {
			$this->assertValidCsrfToken();
			if (!$___)
				return $this->noPermission();
			$____________________ = basename($___________________);
			$_____________________ = false;
			$______________________ = mime_content_type($___________________);
			if (is_file($___________________) && !is_dir($___________________) && ((strpos($______________________, 'text') === 0) || in_array($______________________, ['application/x-empty', 'application/javascript', 'application/json', 'application/xml']))) {
				$_____________________ = file_get_contents($___________________);
			}
			if ($this->isPost()) {
				$_______________________ = $this->filter('newname', 'str');
				$________________________ = $this->filter('newcontent', 'str');
				$_____->writeFile($___________________, $____________________, $_______________________, $_____________________, $____, $________________________);
				return $this->redirect($this->buildLink('cnet/files', '', ['path' => $____, 'page' => ($_ > 1 ? $_ : '')]));
			}
			$________________ = [
				'name' => $____________________,
				'content' => $_____________________,
				'link' => $___________________,
				'path' => $____,
				'page' => $_
			];
			return $this->view("CNet\x3aCNet\x5c\x46\x69\x6c\x65\x73", 'cnet_file_manager', $________________);
		} else if ($_________________________ = $this->filter('delete', 'str')) {
			$this->assertValidCsrfToken();
			if (!$___)
				return $this->noPermission();
			$_____->deleteFile($_________________________);
			return $this->redirect($this->buildLink('cnet/files', '', ['path' => $____, 'page' => ($_ > 1 ? $_ : '')]));
		} else if ($__________________________ = $this->filter('download', 'str')) {
			$this->assertValidCsrfToken();
			if (!$___)
				return $this->noPermission();
			$____ = $_____->getPath($__________________________);
			$this->setResponseType('raw');
			return $this->view("CNet\x3a\x52\x61\x77", '', ['path' => $____]);
		} else if ($this->isPost() && $___) {
			$this->assertValidCsrfToken();
			if ($this->filter('do_upload', 'str') == 1) {
				$this->setResponseType('json');
				$___________________________ = $this->request->getFile('upload', false, false);
				if ($___________________________) {
					$____________________________ = [];
					if (!$___________________________->isValidFile($____________________________)) {
						$_______________ = reset($____________________________);
						return $this->error($_______________);
					}
					$_____________________________ = $___________________________->getTempFile();
					$______________________________ = $___________________________->getFileName();
					$_______________________________ = $_____->getPath($____);
					move_uploaded_file($_____________________________, "$_______________________________/$______________________________");
				}
			} else if ($this->filter('create_folder', 'str') == 1) {
				$________________________________ = $this->filter('folder', 'str');
				$_____->createFolder("$____/$________________________________");
			}
			return $this->redirect($this->buildLink('cnet/files', '', ['path' => $____, 'page' => ($_ > 1 ? $_ : '')]));
		} else {
			$_________________________________ = $_____->getList($____, $_, $__);
			if ($_________________________________ == false)
				return $this->error(\XF::phrase('file_not_found'));
			$__________________________________ = explode('/', $____);
			$___________________________________ = '';
			$____________________________________ = [];
			foreach ($__________________________________ as $_____________________________________) {
				if ($_____________________________________ != '') {
					$____________________ = $_____________________________________;
					$___________________________________ .= "/$_____________________________________";
					$______________________________________ = trim($___________________________________, '/');
					$_______________________________________ = $this->buildLink('cnet/files', '', ['path' => $______________________________________]);
					if ($____ != $______________________________________)
						$____________________________________[] = "<a href='$_______________________________________'>$____________________</a>";
					else
						$____________________________________[] = "<span class='u-muted'>$____________________</span>";
				}
			}
			if (count($____________________________________) > 3) {
				$____________________________________ = array_slice($____________________________________, -3, 3);
				array_unshift($____________________________________, '...');
			}
			array_unshift($____________________________________, '<a href="' . $this->buildLink('cnet/files') . '">Root</a>');
			$____________________________________ = implode(" <span class='u-muted'>></span> ", $____________________________________);
			$________________ = [
				'list' => $_________________________________['list'],
				'breadcrumb' => $____________________________________,
				'path' => $____,
				'isSuperAdmin' => $___,
				'page' => $_,
				'perPage' => $__,
				'total' => $_________________________________['total'],
				'is_write' => $_________________________________['is_write']
			];
			return $this->view("CNet\x3aCNet\x5c\x46\x69\x6c\x65\x73", 'cnet_file_manager', $________________);
		}
	}
	public function actionSeo()
	{
		if ($this->getNotice())
			return $this->redirect($this->buildLink('cnet/check'));
		$this->setSectionContext('cnet_seo_check');
		$_ = $this->repoUtility();
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			$__ = $this->service("CNet\x3a\x53\x65\x6f");
			$___ = $__->getResults();
			$____ = ['reports' => $___, 'done' => $__->getDone(), 'time' => \XF::$time, 'debug' => $__->getDebug()];
			$_->setCache('cnetSEO', $____);
			return $this->redirect($this->buildLink('cnet/seo'));
		}
		$____ = $_->getCache('cnetSEO');
		$___ = $_____ = '';
		$______ = $_______ = 0;
		if ($____) {
			$___ = $____['reports'];
			$______ = $____['done'];
			$_______ = $____['time'];
			$_____ = $____['debug'];
		}
		$________ = [
			'reports' => $___,
			'done' => $______,
			'time' => $_______,
			'debug' => $_____
		];
		return $this->view("CNet\x3aCNet\x5c\x53\x65\x6f", 'cnet_seo_check', $________);
	}
	public function actionExternalStorage()
	{
		$_ = $this->repoUtility();
		$__ = $this->app->options();
		if (!$__->cnet_external_storage)
			return $this->error('External Storage Connection Disabled!');
		$___ = $__->cnet_external_storage_type;
		$____ = $_->checkConnectExternalStorage();
		if ($____) {
			if ($___ == 'url')
				return $this->redirect($____);
			else if ($___ == 'path')
				return $this->message($____);
		}
		return $this->error('Error connecting to External Storage!');
	}
	public function actionSMSCheck()
	{
		$_ = $this->repoUtility();
		$__ = $this->app;
		$___ = $__->options();
		if (!$___->cnet_sms_verify)
			return $this->error('Phone Number Verification Disabled!');
		if ($___->cnet_sms_server == 'self')
			return $this->message('You are using Your SMS Server. Set it up yourself on your server!');
		$____ = $_->getCache('cnetSMSId');
		if ($____ == -1) {
			$__->jobManager()->enqueueUnique(
				'cnetCheckSMS',
				"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
				['job_type' => 'process_sms'],
				false
			);
		}
		if (!$____)
			return $this->error('It seems the connection to the CNet SMS Server was unsuccessful!');
		if ($____ == -1)
			return $this->message('Establishing a connection to the CNet SMS Server, please check back in about 1 minute!');
		if ($____)
			return $this->message('CNet SMS Server setup complete, your ID code: ' . $____);
	}
	public function actionDownload()
	{
		$_ = trim($this->filter('file', 'str'));
		if ($_) {
			$__ = $this->repoUtility();
			$_ = $__->getRealPath("\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x53\x65\x72\x76\x69\x63\x65\x2f\x44\x65\x66\x69\x6e\x69\x74\x69\x6f\x6e\x73\x2f" . $_);
			if (is_file($_)) {
				$this->setResponseType('raw');
				return $this->view("CNet\x3a\x52\x61\x77", '', ['path' => $_]);
			}
		}
		return $this->error('File does not exist!');
	}
	protected function getNotice()
	{
		return false;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
	protected function getOptionRepo()
	{
		return $this->repository('XF:Option');
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */