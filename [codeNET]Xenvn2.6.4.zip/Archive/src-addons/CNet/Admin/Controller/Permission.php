<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Mvc\ParameterBag;
class Permission extends XFCP_Permission
{
	public function actionUserGroupEdit(ParameterBag $_)
	{
		$__ = parent::actionUserGroupEdit($_);
		if (!$__ instanceof \XF\Mvc\Reply\View)
			return $__;
		$___ = $__->getParam('permissionData');
		if (isset($___['interfaceGroups']['cnet_0_forum']) && isset($___['interfaceGroups']['cnet_1_resource'])) {
			if ($this->repoUtility()->getCache("cnet\x49\x73\x4e\x6f\x74\x69\x63\x65")) {
				unset($___['interfaceGroups']['cnet_0_forum']);
				unset($___['interfaceGroups']['cnet_1_resource']);
			} else if (!$this->app()->addonManager()->getById('XFRM'))
				unset($___['interfaceGroups']['cnet_1_resource']);
			$__->setParam('permissionData', $___);
		}
		return $__;
	}
	public function actionUserGroupSave(ParameterBag $_)
	{
		$this->assertAdminPermission('userGroup');
		$this->assertPostOnly();
		$__ = $this->assertUserGroupExists($_->user_group_id);
		$___ = $this->service('XF:UpdatePermissions');
		$____ = $this->filter('permissions', 'array');
		$___->setUserGroup($__)->setGlobal();
		$___->updatePermissions($____);
		return $this->redirect($this->buildLink('permissions/user-groups', $__));
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */