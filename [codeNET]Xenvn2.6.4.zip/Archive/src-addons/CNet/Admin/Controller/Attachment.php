<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Mvc\ParameterBag;
class Attachment extends XFCP_Attachment
{
	public function actionIndex(ParameterBag $_)
	{
		if (\XF::$versionId >= 2030035) {
			if ($_->attachment_id)
				return $this->rerouteController(self::class, 'view', $_);
			if ($this->request->exists('delete_attachments'))
				return $this->rerouteController(self::class, 'delete');
		} else {
			if ($_->attachment_id)
				return $this->rerouteController(__CLASS__, 'view', $_);
			if ($this->request->exists('delete_attachments'))
				return $this->rerouteController(__CLASS__, 'delete');
		}
		$__ = $this->app['session.admin'];
		$___ = $this->filter('type', 'str');
		if ($___)
			$__->set('cnet_attachment_type_filter', $___);
		else
			$___ = $__->get('cnet_attachment_type_filter');
		if ($___ && $___ != 'clear') {
			$____ = $this->filter(
				[
					'content_type' => 'str',
					'username' => 'str',
					'start' => 'datetime',
					'end' => 'datetime',
					'order' => 'str',
					'direction' => 'str',
					'mode' => 'str',
					'_skipFilter' => 'str',
					'page' => 'int'
				]
			);
			$____ = array_filter($____);
			$____['type'] = $___;
			return $this->redirect($this->buildLink('attachments/type-filter', null, $____));
		}
		$_____ = parent::actionIndex($_);
		if ($_____ instanceof \XF\Mvc\Reply\View)
			$_____->setParam('type', 'clear');
		return $_____;
	}
	public function actionTypeFilter(ParameterBag $_)
	{
		$__ = $this->filter('type', 'str');
		if (\XF::$versionId >= 2030035) {
			if ($_->attachment_id)
				return $this->rerouteController(self::class, 'view', $_);
			if ($this->request->exists('delete_attachments'))
				return $this->rerouteController(self::class, 'delete');
			$___ = $this->getAttachmentRepo();
			$____ = $this->filterPage();
			$_____ = 20;
			$______ = $this->setupAttachmentFilterer();
			$_______ = $______->apply()->limitByPage($____, $_____);
			if ($__ == 'storage')
				$_______->where('storage', 1);
			else if ($__ == 'scan') {
				$_______->where('scan', '<>', '');
				$_______->where('scan', '<>', 'clean');
			}
			$________ = $______->getLinkParams();
			if ($this->isPost())
				return $this->redirect($this->buildLink('attachments/type-filter', null, $________), '');
			$_________ = $_______->total();
			$this->assertValidPage($____, $_____, $_________, 'attachments/type-filter');
			if (!$_________) {
				$__________ = $this->app['session.admin'];
				$__________->set('cnet_attachment_type_filter', 0);
			}
			$___________ = [
				'attachments' => $_______->fetch(),
				'handlers' => $___->getAttachmentHandlers(),
				'page' => $____,
				'perPage' => $_____,
				'total' => $_________,
				'linkParams' => $________,
				'filterDisplay' => $______->getDisplayValues(),
				'type' => $__
			];
			return $this->view('XF:Attachment\Listing', 'attachment_list', $___________);
		} else {
			if ($_->attachment_id)
				return $this->rerouteController(__CLASS__, 'view', $_);
			$____________ = [];
			$____ = $this->filterPage();
			$_____ = 20;
			if ($this->request->exists('delete_attachments'))
				return $this->rerouteController(__CLASS__, 'delete');
			$___ = $this->getAttachmentRepo();
			$_____________ = $___->findAttachmentsForList()->limitByPage($____, $_____);
			if ($______________ = $this->filter('content_type', 'str')) {
				$_____________->where('content_type', $______________);
				$____________['content_type'] = $______________;
			}
			if ($_______________ = $this->filter('username', 'str')) {
				$________________ = $this->finder('XF:User')->where('username', $_______________)->fetchOne();
				if ($________________) {
					$_____________->where('Data.user_id', $________________->user_id);
					$____________['username'] = $________________->username;
				}
			}
			if ($_________________ = $this->filter('start', 'datetime')) {
				$_____________->where('attach_date', '>', $_________________);
				$____________['start'] = $_________________;
			}
			if ($__________________ = $this->filter('end', 'datetime')) {
				$_____________->where('attach_date', '<', $__________________ + 86400);
				$____________['end'] = $__________________;
			}
			if ($___________________ = $this->filter('mode', 'str')) {
				if ($___________________ == 'size') {
					$_____________->order('Data.file_size', 'DESC');
				} else if ($___________________ == 'recent') {
					$_____________->order('attach_date', 'DESC');
				}
				$____________['mode'] = $___________________;
			}
			if ($__ == 'storage')
				$_____________->where('storage', 1);
			else if ($__ == 'scan') {
				$_____________->where('scan', '<>', '');
				$_____________->where('scan', '<>', 'clean');
			}
			if ($this->isPost())
				return $this->redirect($this->buildLink('attachments/type-filter', null, $____________), '');
			$_________ = $_____________->total();
			$this->assertValidPage($____, $_____, $_________, 'attachments/type-filter');
			if (!$_________) {
				$__________ = $this->app['session.admin'];
				$__________->set('cnet_attachment_type_filter', 0);
			}
			$___________ = [
				'attachments' => $_____________->fetch(),
				'handlers' => $___->getAttachmentHandlers(),
				'page' => $____,
				'perPage' => $_____,
				'total' => $_________,
				'linkFilters' => $____________,
				'datePresets' => \XF::language()->getDatePresets(),
				'type' => $__
			];
			return $this->view('XF:Attachment\Listing', 'attachment_list', $___________);
		}
	}
	public function actionExternalStorage(ParameterBag $_)
	{
		$__ = $this->app()->options();
		if (!$__->cnet_external_storage)
			return $this->noPermission();
		$___ = $_->attachment_id;
		if (!$___)
			return $this->notFound();
		$____ = $this->filter([
			'content_type' => 'str',
			'username' => 'str',
			'start' => 'datetime',
			'end' => 'datetime',
			'order' => 'str',
			'direction' => 'str',
			'mode' => 'str',
			'_skipFilter' => 'str',
			'page' => 'int',
		]);
		if ($____['page'] == 1)
			unset($____['page']);
		$_____ = $this->filter('action', 'str');
		$____ = array_filter($____);
		$______ = $this->app()->addonManager()->getById('XFRM');
		$______ = ($______ && $______->isActive());
		if ($______)
			$_______ = $this->app()->em()->findOne('XF:Attachment', ['attachment_id', '=', $___], ['Data', 'Post', 'ResourceUpdate', 'ResourceVersion']);
		else
			$_______ = $this->app()->em()->findOne('XF:Attachment', ['attachment_id', '=', $___], ['Data', 'Post']);
		$________ = $_______->getRealFilePath(true);
		$_________ = $_______->Data;
		$__________ = $_________->extension;
		$___________ = $_________->file_size;
		$____________ = explode(',', $__->cnet_external_storage_ext);
		$_____________ = intval($__->cnet_external_storage_minsize) * 1024;
		$______________ = false;
		$_______________ = $_______->content_type;
		if ($_______________ == 'post') {
			$________________ = $_______->Post->Thread ?? false;
			if ($________________) {
				$_________________ = $________________->node_id;
				foreach ($__->cnet_external_storage_category as $__________________) {
					if (strpos($__________________, 'RM') === false && $__________________ == $_________________) {
						$______________ = true;
						break;
					}
				}
			}
		} else if ($______ && $_______________ == 'resource_update') {
			$___________________ = $_______->ResourceUpdate->Resource ?? false;
			if ($___________________) {
				$____________________ = $___________________->resource_category_id;
				foreach ($__->cnet_external_storage_category as $__________________) {
					if (strpos($__________________, 'RM') !== false) {
						$__________________ = intval(str_replace('RM', '', $__________________));
						if ($__________________ == $____________________) {
							$______________ = true;
							break;
						}
					}
				}
			}
		} else if ($______ && $_______________ == 'resource_version') {
			$___________________ = $_______->ResourceVersion->Resource ?? false;
			if ($___________________) {
				$____________________ = $___________________->resource_category_id;
				foreach ($__->cnet_external_storage_category as $__________________) {
					if (strpos($__________________, 'RM') !== false) {
						$__________________ = intval(str_replace('RM', '', $__________________));
						if ($__________________ == $____________________) {
							$______________ = true;
							break;
						}
					}
				}
			}
		} else if ($_______________ == 'conversation_message') {
			if (!$__->cnet_external_storage_message)
				return $this->error('Attachments in Direct Messages are not allowed');
			$______________ = true;
		} else if ($_______________ == 'profile_post') {
			if (!$__->cnet_external_storage_message)
				return $this->error('Attachments in Profile Post are not allowed');
			$______________ = true;
		}
		if (!$______________)
			return $this->error('The attachment is not in the allowed Forum / Resource categories');
		if ($___________ < $_____________)
			return $this->error('Attachment file size is not allowed');
		if (!in_array($__________, $____________))
			return $this->error('Attachment file extension is not allowed');
		if ($this->isPost()) {
			$_____________________ = $this->repoUtility();
			$______________________ = $_______->getRealFilePath();
			if ($_____ == 'move') {
				if ($_____________________->uploadToExternalStorage($______________________)) {
					$_______->set('storage', 1, ['forceSet' => true]);
					$_______________________ = fopen($______________________, 'c');
					if ($_______________________) {
						if (flock($_______________________, LOCK_EX | LOCK_NB)) {
							ftruncate($_______________________, 0);
							$_______->save(true, false);
						}
						fclose($_______________________);
					}
				} else
					return $this->error('');
			} else if ($_____ == 'restore') {
				if ($_____________________->restoreToInternalStorage($______________________)) {
					$_______->set('storage', 0, ['forceSet' => true]);
					$_______->save(true, false);
				} else
					return $this->error('');
			}
			$________________________ = $this->app['session.admin'];
			$_________________________ = $________________________->get('cnet_attachment_type_filter');
			if ($_________________________ && $_________________________ != 'clear') {
				$____['type'] = $_________________________;
				return $this->redirect($this->buildLink('attachments/type-filter', null, $____), '');
			} else
				return $this->redirect($this->buildLink('attachments', null, $____));
		}
		$____['action'] = $_____;
		$__________________________ = [
			'template' => 'attachment_action',
			'storage' => true,
			'action' => $_____,
			'dataPath' => $________,
			'attachment' => $_______,
			'linkParams' => $____
		];
		return $this->view('XF:Attachment\ExternalStorage', 'cnet_admin_template', $__________________________);
	}
	public function actionScan(ParameterBag $_)
	{
		$__ = $this->app()->options();
		if (!$__->cnet_malware_scanner)
			return $this->noPermission();
		$___ = $_->attachment_id;
		if (!$___)
			return $this->notFound();
		$____ = $this->app()->em()->findOne('XF:Attachment', ['attachment_id', '=', $___], ['Data']);
		if (!$____)
			return $this->notFound();
		$_____ = $____->Data;
		if (!$_____)
			return $this->notFound();
		if (!in_array($_____->extension, ['php', 'zip', 'txt']))
			return $this->error('Only scan the following file formats: .php, .zip, .txt');
		$______ = $this->filter([
			'content_type' => 'str',
			'username' => 'str',
			'start' => 'datetime',
			'end' => 'datetime',
			'order' => 'str',
			'direction' => 'str',
			'mode' => 'str',
			'_skipFilter' => 'str',
			'page' => 'int',
		]);
		if ($______['page'] == 1)
			unset($______['page']);
		$______ = array_filter($______);
		if ($this->isPost()) {
			$_______ = $this->repoUtility()->scanAttachment($____, $_____);
			if ($____->scan != $_______) {
				$____->set('scan', $_______, ['forceSet' => true]);
				$____->save(true, false);
			}
			$________ = $this->app['session.admin'];
			$_________ = $________->get('cnet_attachment_type_filter');
			if ($_________ && $_________ != 'clear') {
				$______['type'] = $_________;
				return $this->redirect($this->buildLink('attachments/type-filter', null, $______), '');
			} else
				return $this->redirect($this->buildLink('attachments', null, $______));
		}
		$__________ = $____->getRealFilePath(true);
		$_______ = $____->scan;
		if ($_______ == 'clean')
			$_______ = '<b>' . \XF::phrase('results') . '</b>: <span class="cnet-scan cnet-file">' . \XF::phrase('clean') . '</span>';
		else if (!$_______)
			$_______ = '<b>' . \XF::phrase('results') . '</b>: <span class="cnet-scan cnet-detect">' . \XF::phrase('unknown') . '</span>';
		else {
			$_______ = unserialize($_______);
			$_______ = \XF::phrase('cnet_scan_result_x', $_______);
		}
		$___________ = [
			'template' => 'attachment_action',
			'scan' => true,
			'attachment' => $____,
			'dataPath' => $__________,
			'result' => $_______,
			'linkParams' => $______
		];
		return $this->view('XF:Attachment\ExternalStorage', 'cnet_admin_template', $___________);
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */