<?php
/* Developed by CNet Tools */
namespace CNet\Admin\Controller;
use XF\Mvc\ParameterBag;
class TemplateModification extends XFCP_TemplateModification
{
	public function actionIndex()
	{
		$_ = parent::actionIndex();
		if (!$_ instanceof \XF\Mvc\Reply\View)
			return $_;
		$__ = $_->getParam('groupedModifications');
		if (isset($__["CNet"])) {
			if ($this->repoUtility()->getCache("cnet\x49\x73\x4e\x6f\x74\x69\x63\x65"))
				unset($__["CNet"]);
			else if (!$this->app()->addonManager()->getById('XFRM')) {
				foreach ($__["CNet"] as $___ => $____) {
					if (stripos($____['template'], 'xfrm_') === 0)
						unset($__["CNet"][$___]);
				}
			}
			$_->setParam('groupedModifications', $__);
		}
		return $_;
	}
	public function actionSave(ParameterBag $_)
	{
		$this->assertPostOnly();
		if ($this->filter('test', 'bool'))
			return $this->rerouteController(__CLASS__, 'test', $_);
		if ($_['modification_id'])
			$__ = $this->assertTemplateModificationExists($_['modification_id']);
		else
			$__ = $this->em()->create('XF:TemplateModification');
		$this->modificationSaveProcess($__)->run();
		return $this->redirect($this->buildLink('template-modifications/edit', $__));
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */