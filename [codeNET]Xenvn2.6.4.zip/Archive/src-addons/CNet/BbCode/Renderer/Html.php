<?php
/* Developed by CNet Tools */
namespace CNet\BbCode\Renderer;
class Html extends XFCP_Html
{
	protected function getRenderedLink($_, $__, array $___)
	{
		$____ = $this->repoUtility()->buildRedirectUrl($__, $___);
		$_____ = '';
		if ($____) {
			[$__, $_____] = $____;
			if (stripos($_, \XF::app()->options()->boardUrl) === 0)
				$_ = preg_replace('/^https?:\/\//i', '', $_);
			else if (preg_match('/^((https?:\/\/|www\.)\S+\.|\d+\.\d+\.\d+\.\d+)\S+.*/i', $_)) {
				if (stripos($_, 'http://') === false && stripos($_, 'https://') === false)
					$_ = 'https://' . $_;
				$_ = parse_url($_, PHP_URL_HOST);
			}
			$___['noProxy'] = true;
		}
		$______ = parent::getRenderedLink($_, $__, $___);
		if ($_____) {
			$_______ = \XF::app()->templater();
			$________ = $_______->fontAwesome('fa-globe', ['title' => $_____, 'class' => 'cnet-lang-icon']);
			$______ = $________ . ' ' . $______;
		}
		return $______;
	}
	public function renderTagCode(array $_, $__, array $___, array $____)
	{
		$_____ = \XF::app();
		if ($_____->options()->cnet_force_like == 'all' && $____ && isset($____['entity'])) {
			$______ = $____['entity'];
			$_______ = false;
			$________ = $______->getEntityContentType();
			$_________ = false;
			if ($________ == 'post') {
				$__________ = $______->Thread;
				$_______ = $__________->node_id;
				$_________ = $__________->user_id;
			} else if ($________ == 'resource_update') {
				$___________ = $______->Resource;
				$_______ = $___________->resource_category_id;
				$_________ = $___________->user_id;
			}
			if ($_______ && $this->repoUtility()->isLimitCategory($_______, $________)) {
				$____________ = \XF::visitor();
				$_____________ = ($____________->user_id && $____________->user_state == 'valid');
				$______________ = true;
				if ($_____________ && $____________->user_id == $_________) {
					$______________ = false;
				}
				if ($______________ && $_____________) {
					if ($________ == 'post') {
						if ($____________->hasNodePermission($_______, 'cnet_bypass_like_view'))
							$______________ = false;
						else
							$______________ = !$______->hasLikePost();
					} else if ($________ == 'resource_update') {
						if ($____________->hasResourceCategoryPermission($_______, 'cnet_bypass_like_view'))
							$______________ = false;
						else
							$______________ = !$___________->hasLikeResource();
					}
				}
				if (!$_____________ || $______________) {
					$_______________ = $this->renderSubTree($_, $____);
					$_______________ = preg_replace('#^\s*\r?\n+#', '', $_______________);
					$_______________ = rtrim($_______________);
					$config['phrase'] = '';
					if ($__)
						$config['phrase'] = strtoupper(preg_replace('#[^a-z0-9_-]#i', '-', $__));
					$________________ = substr_count($_______________, "\n") + 1;
					$_________________ = \XF::phrase('like');
					$__________________ = \XF::phrase('reply');
					$___________________ = \XF::phrase('view');
					$____________________ = \XF::phrase('cnet_you_must_x_the_content_to_y', ['action' => $_________________, 'result' => $___________________]);
					$_____________________ = \XF::phrase('cnet_you_must_x_the_content_to_y', ['action' => "$_________________ / $__________________", 'result' => $___________________]);
					if (!$_____________)
						$______________________ = \XF::phrase('cnet_login_to_view');
					else if ($________ == 'post') {
						$______________________ = ($______->isFirstPost() ? $_____________________ : $____________________);
					} else if ($________ == 'resource_update') {
						$______________________ = ($___________->Discussion ? $_____________________ : $____________________);
					} else
						$______________________ = $____________________;
					return $this->templater->renderTemplate('public:bb_code_tag_code', [
						'content' => $______________________ . "\n(" . \XF::phrase('cnet_x_lines', ['line' => $________________]) . ')',
						'language' => 'hidden',
						'config' => $config
					]);
				}
			}
		}
		return parent::renderTagCode($_, $__, $___, $____);
	}
	public function renderTagAttach(array $_, $__, array $___, array $____)
	{
		if (\XF::options()->cnet_view_all_image) {
			$_____ = intval($this->renderSubTreePlain($_));
			if ($_____) {
				if (!isset($____['attachments'][$_____])) {
					$______ = \XF::app()->find('XF:Attachment', $_____);
					if ($______ && $______->has_thumbnail) {
						$____['viewAttachments'] = true;
						$____['attachments'][$_____] = $______;
						if (isset($__['type']) && strtolower($__['type']) == 'full')
							$__['type'] = '';
						else if (is_string($__) && strtolower($__) == 'full')
							$__ = '';
					}
				} else {
					$______ = $____['attachments'][$_____];
					if ($______->has_thumbnail)
						$____['viewAttachments'] = true;
				}
			}
		}
		return parent::renderTagAttach($_, $__, $___, $____);
	}
	protected function repoUtility()
	{
		return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */