<?php
/* Developed by CNet Tools */
namespace CNet\Pub\View;
class Raw extends \XF\Mvc\View
{
	public function renderRaw()
	{
		$this->response->header('Last-Modified', gmdate('D, d M Y H:i:s') . ' GMT');
		$this->response->header('Cache-control', 'private, no-cache, max-age=0');
		$this->response->header('X-Robots-Tag', 'noindex');
		if (isset($this->params['image'])) {
			$this->response->setAttachmentFileParams($this->params['fileName']);
			$_ = $this->params['image'];
			imagepng($_, null, 0);
			imagedestroy($_);
			return '';
		} else if (isset($this->params['path'])) {
			$__ = $this->params['path'];
			if (!$__ || !is_file($__)) {
				$this->response->httpCode(500);
				return '';
			}
			$___ = filesize($__);
			if (isset($this->params['fileName']))
				$____ = $this->params['fileName'];
			else
				$____ = basename($__);
			$this->response->setAttachmentFileParams($____);
			$this->response->header('Content-Length', $___);
			if (!ob_get_level() && $___ <= 1048576) {
				readfile($__);
				return '';
			} else {
				$_____ = fopen($__, 'rb');
				if (!$_____) {
					$this->response->httpCode(500);
					return '';
				}
				while (!feof($_____)) {
					$______ = fread($_____, 32768);
					if ($______ === false || $______ === '')
						break;
					echo $______;
				}
				fclose($_____);
				return '';
			}
		}
		$this->response->contentType($this->params['contentType']);
		return $this->params['data'];
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */