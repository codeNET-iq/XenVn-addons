<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
class ResourceItem extends XFCP_ResourceItem
{
	protected function getResourceViewExtraWith()
	{
		$_ = parent::getResourceViewExtraWith();
		$__ = $this->app()->options();
		if ($__->cnet_multilingual_content)
			$_[] = 'Language';
		return $_;
	}
	public function actionDownload(ParameterBag $_)
	{
		$__ = $this->app()->options();
		if (!$__->cnet_multilingual_content || !$__->cnet_sync_attachments_language || !$this->filter('chooser', 'uint'))
			return parent::actionDownload($_);
		$___ = $this->assertViewableResource($_->resource_id);
		$____ = $___->CurrentVersion;
		$_____ = null;
		if (!$____ || !$____->canDownload($_____))
			return $this->noPermission($_____);
		$__ = $this->app()->options();
		$______ = $___->CurrentVersionAttachments;
		$_______ = $___->getDefaultLanguageResources();
		if ($_______) {
			$________ = $_______->CurrentVersion;
			$_________ = $_______->CurrentVersionAttachments;
			$__________ = $this->repoUtility()->getLanguageList();
			$___________ = [
				'chooser' => true,
				'resource' => $___,
				'version' => $____,
				'files' => $______,
				'defaultVersion' => $________,
				'defaultFiles' => $_________,
				'defaultLanguageCode' => $__________[$_______->Language->language_code]
			];
			return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x56\x65\x72\x73\x69\x6f\x6e\x5c\x44\x6f\x77\x6e\x6c\x6f\x61\x64", 'cnet_multilingual', $___________);
		}
		return parent::actionDownload($_);
	}
	public function actionDownloadLogs(ParameterBag $_)
	{
		$this->assertRegistrationRequired();
		$__ = $this->app()->options();
		$___ = \XF::visitor();
		$____ = $___->user_id;
		$_____ = $this->assertViewableResource($_->resource_id, $this->getResourceViewExtraWith());
		if (!$__->cnet_limit_download || !$____ || $___->user_state != 'valid' || !in_array('RM' . $_____->resource_category_id, (array)$__->cnet_limit_category))
			return $this->error(\XF::phrase('do_not_have_permission'));
		if ($_____->user_id == $____ || $___->is_admin) {
			$______ = $this->filterPage();
			$_______ = 20;
			$________ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
			$________->setType('Resource');
			$_________ = $________->downloadLogs($_____->resource_id, true, $______, $_______);
			if ($_________) {
				$__________ = $_________['count'];
				$this->assertValidPage($______, $_______, $__________, 'resources/download-logs', $_____);
				$___________ = $_____->Category;
				$____________ = ($___________ ? $___________->getBreadcrumbs() : []);
				$____________[] = [
					'href' => $this->buildLink('resources', $_____),
					'value' => \XF::phrase('xfrm_resource'),
				];
				$_____________ = [
					'downloadLogs' => true,
					'resource' => $_____,
					'logs' => $_________['logs'],
					'count' => $__________,
					'page' => $______,
					'perPage' => $_______,
					'breadcrumbs' => $____________
				];
				return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x4c\x6f\x67\x73", 'cnet_xfrm_downloaded_list', $_____________);
			}
		}
		return $this->error(\XF::phrase('do_not_have_permission'));
	}
	public function actionUpdate(ParameterBag $_)
	{
		$this->assertRegistrationRequired();
		$__ = $this->app();
		$___ = $__->options();
		$____ = \XF::visitor();
		$_____ = $____->user_id;
		$______ = $this->assertViewableResource($_->resource_id, $this->getResourceViewExtraWith());
		if (!$______->canUpdate())
			return $this->error(\XF::phrase('do_not_have_permission'));
		$_______ = $__['session.public'];
		$________ = $______->Category;
		$_________ = $________->resource_category_id;
		$__________ = $______->Description;
		$___________ = $__________->resource_update_id;
		$____________ = ($____->is_admin || $____->is_moderator);
		$_____________ = $______->canUptop();
		$______________ = ($___->cnet_update_attachment && ($____->hasResourceCategoryPermission($_________, 'uploadUpdateAttach') || $____->hasResourceCategoryPermission($_________, 'uploadUpdateVideo') || $____________));
		$_______________ = ($___->cnet_optimal_meta_data && ($_____ == $______->user_id || $____________));
		$________________ = $___->cnet_multilingual_content && ($_____ == $______->user_id || $____________);
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			$this->setResponseType('json');
			$_________________ = $this->request->getFile('upload', false, false);
			$__________________ = $__________->message;
			if ($______________ && $_________________) {
				$___________________ = $this->repository('XF:Attachment');
				$____________________ = $___________________->getDefaultAttachmentConstraints();
				$_____________________ = $___________________->getAttachmentHandler('resource_update');
				$____________________['extensions'] = ['jpg', 'jpeg', 'jpe', 'png', 'gif', 'webp'];
				if ($________ && $________->canUploadVideos())
					$____________________ = $___________________->applyVideoAttachmentConstraints($____________________);
				$_________________->applyConstraints($____________________);
				$______________________ = [];
				if (!$_________________->isValid($______________________)) {
					$_______________________ = reset($______________________);
					return $this->error($_______________________);
				}
				$________________________ = $_________________->getFileWrapper();
				$_________________________ = $this->filter('data_id', 'int');
				if ($_________________________) {
					$__________________________ = \XF::$time;
					$___________________________ = ['gif', 'jpg', 'jpeg', 'png', 'webp'];
					$____________________________ = $__->finder('XF:Attachment')->where('data_id', $_________________________)->fetchOne();
					$_____________________________ = $____________________________->Data;
					if ($_____________________________) {
						$______________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
						$_______________________________ = $_____________________________->filename;
						$________________________________ = $_____________________________->getExtension();
						$_________________________________ = $________________________->getExtension();
						$__________________________________ = $________________________->getFileName();
						if ($________________________________ = $_________________________________ || (in_array($________________________________, $___________________________) && in_array($_________________________________, $___________________________))) {
							$_____________________________->user_id = $____->user_id;
							$_____________________________->filename = $__________________________________;
							$_____________________________->upload_date = $__________________________;
							$___________________________________ = $__->service('XF:Attachment\Preparer');
							$___________________________________->updateDataFromFile($_____________________________, $________________________);
							$____________________________->attach_date = $__________________________;
							$____________________________->save(true, false);
							$____________________________________ = $____________________________->attachment_id;
							$_____________________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
							$__________________ = str_replace([$______________________________, $_______________________________], [$_____________________________________, $__________________________________], $__________________, $______________________________________);
							if ($______________________________________)
								$__________->message = $__________________;
							$__->jobManager()->enqueueUnique(
								'cnetAttachmentUrlResourceUpdate' . $___________,
								"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
								[
									'job_type' => 'attachment_url',
									'id' => $___________,
									'url_find' => $______________________________,
									'url_replace' => $_____________________________________,
									'content_type' => 'resource'
								],
								false
							);
							$_______________________________________ = $______->image;
							if ($____________________________->hasThumbnail() && $_______________________________________ && (strpos($_______________________________________, '.' . $____________________________________ . '/') !== false || strpos($_______________________________________, '.a' . $____________________________________ . '/') !== false)) {
								$_____________________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
								if ($_____________________________________ != $_______________________________________) {
									$________________________________________ = preg_replace('/\?hash=\w+$/i', '',  $____________________________->getThumbnailUrlFull());
									$______->set('image', $_____________________________________, ['forceSet' => true]);
									$______->set('icon', $________________________________________, ['forceSet' => true]);
								}
							}
						} else
							return $this->error(\XF::phrase('one_or_more_files_do_not_have_allowed_extension_x', ['allowed' => $________________________________]));
					}
				} else {
					if ($__________->attach_count >= $___->attachmentMaxPerMessage)
						return $this->error(\XF::phrase('you_have_reached_the_maximum_limit_for_attachment_uploads'));
					$_________________________________________ =  md5_file($_________________->getTempFile());
					$__________________________________________ = $__->service('XF:Attachment\Preparer');
					$____________________________ = $__________________________________________->insertAttachment(
						$_____________________,
						$________________________,
						$____,
						$_________________________________________
					);
					if ($____________________________) {
						$____________________________->content_type = 'resource_update';
						$____________________________->content_id = $___________;
						$____________________________->temp_hash = '';
						$____________________________->unassociated = 0;
						$____________________________->save(true, false);
						$____________________________->getHandler()->onAssociation($____________________________, $____________________________->getContainer());
						$__________->attach_count++;
						if ($____________________________->hasThumbnail()) {
							$_______________________________________ = $______->image;
							$___________________________________________ = preg_quote($this->app()->options()->boardUrl, '/') . '\/(data\/avatars|styles\/CNet)\/.+\.(jpg|png|gif|webp)$';
							if (!$_______________________________________ || preg_match("/$___________________________________________/i", $_______________________________________) || strpos($_______________________________________, 'gravatar.com/avatar/') !== false) {
								$_____________________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
								$________________________________________ = preg_replace('/\?hash=\w+$/i', '',  $____________________________->getThumbnailUrlFull());
								$______->set('image', $_____________________________________, ['forceSet' => true]);
								$______->set('icon', $________________________________________, ['forceSet' => true]);
							}
						}
					}
				}
			}
			if ($_______________) {
				$_____________________________________ = $this->filter('image_link', 'str');
				if ($_____________________________________ && $_____________________________________ != $______->image)
					$______->setImage('', '', $_____________________________________);
				if (!$___->cnet_auto_description)
					$__________________ = $this->filter('description', 'str');
				$______->setDescription($__________________);
			}
			$____________________________________________ = false;
			if ($___->cnet_uptop_time && empty($_____________)) {
				$____________________________________________ = $this->filter('uptop', 'bool');
				$_______->set('cnet_disable_uptop', !$____________________________________________);
				if ($____________________________________________)
					$______->setUptop($this->filter('reason_uptop', 'str'));
			}
			if (!$____________________________________________) {
				$_____________________________________________ = $______->CurrentVersion;
				$______________________________________________ = ($_____________________________________________ ? $_____________________________________________->version_string : '');
				$_______________________________________________ = $this->router()->buildLink('resources', $______);
				$this->repoUtility()->sentAlert('resource', $______->resource_id, $______->user_id, $_______________________________________________, $______->title, $______________________________________________, '', true);
			}
			if ($________________) {
				$________________________________________________ = trim($this->filter('language_code', 'str'));
				if (!$______->setLanguage($________________________________________________))
					throw $this->exception($this->error($______->getErrors()));
			}
			$______->save(true, false);
			$__________->save(true, false);
			return $this->redirect($this->getDynamicRedirect($this->buildLink('resources', $______), false));
		} else {
			$___________________ = $this->repository('XF:Attachment');
			$____________________ = $___________________->getDefaultAttachmentConstraints();
			$____________________['extensions'] = ['jpg', 'jpeg', 'jpe', 'png', 'gif', 'webp'];
			if ($________ && $________->canUploadVideos())
				$____________________ = $___________________->applyVideoAttachmentConstraints($____________________);
			$_________________________________________________ = $____________________['extensions'];
			foreach ($_________________________________________________ as $__________________________________________________ => $___________________________________________________) {
				$_________________________________________________[$__________________________________________________] = ".$___________________________________________________";
			}
			$____________________________________________________ = '.*';
			if ($_________________________________________________ && count($_________________________________________________))
				$____________________________________________________ = implode(',', $_________________________________________________);
			$_____________________________________________________ = $this->finder('XF:Attachment')
				->where('content_type', 'resource_update')
				->where('content_id', $___________);
			if (!$____________)
				$_____________________________________________________->where('Data.user_id', $_____);
			$______________________________________________________ = $_____________________________________________________->with('Data')->fetch();
			$_______________________________________________________ = [
				'resource' => $______,
				'attachments' => $______________________________________________________,
				'uptop_wait' => $_____________,
				'disable_uptop' => $_______->get('cnet_disable_uptop'),
				'extensions' => $____________________________________________________,
				'update_attachment' => $______________,
				'update_meta' => $_______________,
				'update_language' => $________________
			];
			return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x55\x70\x64\x61\x74\x65", 'cnet_update_content', $_______________________________________________________);
		}
	}
	public function actionDownloadedList(ParameterBag $_)
	{
		$__ = $this->app()->options();
		$___ = \XF::visitor();
		$____ = $___->user_id;
		$_____ = ($____ && $___->user_state == 'valid');
		if (!$_____ || !$__->cnet_limit_download)
			return $this->noPermission();
		$______ = $this->filterPage();
		$_______ = 20;
		$________ = [
			'mode' => '',
			'back' => 0,
			'count' => 0,
			'limitCount' => 0,
			'page' => $______,
			'perPage' => $_______
		];
		$_________ = $this->repoUtility();
		$__________ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
		$__________->setType('Resource');
		$___________ = $____________ = '';
		$_____________ = $this->filter('category_id', 'uint');
		$______________ = ($__->cnet_limit_count_type == 'content' ? \XF::phrase('xfrm_resources') : \XF::phrase('attachments'));
		if ($_____________) {
			$________['mode'] = 'all';
			$________['back'] = 1;
			$___________ = $__________->listItems($_____________, true, $______, $_______);
			if ($___________)
				$________ = array_merge($________, $___________);
		} else if ($__->cnet_limit_mode == 'each' || $__->cnet_limit_mode == 'all_each') {
			$________['mode'] = 'each';
			$_______________ = $__________->listCategories($______, $_______);
			if ($_______________) {
				$________________ = $_______________['nodes'];
				foreach ($________________ as $_________________ => $__________________) {
					if ($__________________['user_upgrade']) {
						$___________________ = $__________________['count'] . '/' . $__________________['limitCount'];
						$____________ = \XF::phrase('cnet_you_have_downloaded_x_contents', ['count' => $___________________, 'contents' => $______________]);
					} else {
						$____________________ = $_________->convertWaitTime($__________________['limit_time']);
						$___________________ = $__________________['count'] . '/' . $__________________['limitCount'];
						$____________ = \XF::phrase('cnet_you_have_downloaded_x_contents_in_time', ['count' => $___________________, 'contents' => $______________, 'time' => $____________________]);
					}
					$________________[$_________________]['headerText'] = $____________;
				}
				$________['nodes'] = $________________;
				$________['count'] = $_______________['count'];
			}
		} else {
			$________['mode'] = 'all';
			$___________ = $__________->listItems(null, true, $______, $_______);
			if ($___________)
				$________ = array_merge($________, $___________);
		}
		if ($___________) {
			if ($__________->isUserUpgrade()) {
				$___________________ = $___________['count'] . '/' . $___________['limitCount'];
				$____________ = \XF::phrase('cnet_you_have_downloaded_x_contents', ['count' => $___________________, 'contents' => $______________]);
			} else {
				$____________________ = $_________->convertWaitTime($__________->getLimitTime());
				$___________________ = $___________['count'] . '/' . $___________['limitCount'];
				$____________ = \XF::phrase('cnet_you_have_downloaded_x_contents_in_time', ['count' => $___________________, 'contents' => $______________, 'time' => $____________________]);
				if ($___________['count'] >= $___________['limitCount']) {
					$_____________________ = $_________->convertWaitTime($__________->getResetTime());
					$______________________ = \XF::phrase('cnet_please_wait_x', ['text' => $_____________________]);
					$________['textTime'] = $______________________;
				}
			}
			$________['headerText'] = $____________;
		}
		$this->assertValidPage($______, $_______, $________['count'], 'resources/download-logs');
		return $this->view('XFRM:Resource\DownloadedList', 'cnet_xfrm_downloaded_list', $________);
	}
	public function actionSchedulePublishing(ParameterBag $_)
	{
		$__ = $this->app()->options();
		$___ = \XF::visitor();
		$____ = $___->user_id;
		$_____ = ($____ && $___->user_state == 'valid');
		if (!$_____ || !$__->cnet_schedule_publishing)
			return $this->noPermission();
		$______ = $this->filterPage();
		$_______ = 20;
		$________ = $this->app()->finder('XFRM:ResourceItem')
			->where('user_id', $____)
			->where('resource_state', 'moderated')
			->where('scheduled', '>', 0)
			->order('scheduled', 'ASC')
			->limitByPage($______, $_______);
		$_________ = $________->total();
		$__________ = $________->fetch();
		if (!$__________->count())
			$__________ = false;
		$this->assertValidPage($______, $_______, $_________, 'resources/schedule-publishing');
		$___________ = [
			'type' => 'resource',
			'resources' => $__________,
			'page' => $______,
			'perPage' => $_______
		];
		return $this->view('XF:Forum\DownloadedList', 'cnet_schedule_publishing', $___________);
	}
	public function actionChangeDate(ParameterBag $_)
	{
		$__ = \XF::visitor();
		if (!$this->app()->options()->cnet_change_post || (!$__->is_admin && !$__->is_moderator))
			return $this->noPermission();
		$___ = $this->assertViewableResource($_->resource_id);
		if (!$___->canEdit())
			return $this->noPermission();
		$____ = $__->timezone;
		if (!$this->isPost()) {
			date_default_timezone_set($____);
			$_____ = date('H:i', time());
			$______ = date('Y-m-d', time());
			$_______ = [
				'resource' => $___,
				'currentTime' => $_____,
				'currentDate' => $______
			];
			return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x43\x68\x61\x6e\x67\x65\x44\x61\x74\x65", 'cnet_change_content', $_______);
		} else {
			$________ = $this->filter('new_date', 'str');
			$_________ = $this->filter('new_time', 'str');
			if (!empty($________) && !empty($_________)) {
				$________ = date_parse($________);
				$_________ = date_parse($_________);
				$__________ = (new \DateTime())->setTimezone(new \DateTimeZone($____))
					->setDate($________['year'], $________['month'], $________['day'])
					->setTime($_________['hour'], $_________['minute'])
					->getTimestamp();
				if ($__________ > \XF::$time || $__________ <= 0)
					return $this->error(\XF::phrase('please_enter_valid_time_format'));
				else if ($___->resource_date != $__________) {
					$___->resource_date = $__________;
					$___->last_update = $__________;
					$___->save(true, false);
					$___________ = $___->Description;
					if (!empty($___________->last_edit_date)) {
						$___________->last_edit_date = $__________;
						$___________->save(true, false);
					}
				}
			}
			return $this->redirect(
				$this->getDynamicRedirect($this->buildLink('resources', $___), false)
			);
		}
	}
	protected function setupResourceEdit(\XFRM\Entity\ResourceItem $_)
	{
		$__ = parent::setupResourceEdit($_);
		if (!preg_match("/\/edit$/i", $this->app->request()->getRoutePath()))
			return $__;
		$___ = $this->app()->options();
		$____ = \XF::visitor();
		$_____ = $_->Description;
		if ($___->cnet_optimal_meta_data) {
			$______ = $_____->message;
			$_______ = $_->image;
			$________ = preg_quote($this->app()->options()->boardUrl, '/') . '\/(data\/avatars|styles\/CNet)\/.+\.(jpg|png|gif|webp)$';
			if (!$_______ || preg_match("/$________/i", $_______) || strpos($_______, 'gravatar.com/avatar/') !== false) {
				$_________ = $this->filter('attachment_hash', 'str');
				if ($_________) {
					$__________ = $this->finder('XF:Attachment')->where('temp_hash', $_________)->fetch();
					if ($__________)
						$_->setImage($__________, $______);
				}
			}
			if (!$_->description || $___->cnet_auto_description)
				$_->setDescription($______);
		}
		if ($___->cnet_uptop_time && empty($_->canUptop())) {
			$___________ = $this->app['session.public'];
			$____________ = $this->filter('uptop', 'bool');
			$___________->set('cnet_disable_uptop', !$____________);
			if ($____________)
				$_->setUptop($this->filter('reason_uptop', 'str'));
		}
		if ($___->cnet_multilingual_content) {
			$_____________ = trim($this->filter('language_code', 'str'));
			if (!$_->setLanguage($_____________))
				throw $this->exception($this->error($_->getErrors()));
		}
		if ($___->cnet_schedule_publishing && $_->scheduled) {
			$______________ = $_->resource_id;
			if ($this->filter('scheduled', 'bool')) {
				$_______________ = $this->filter('scheduled_date', 'str');
				$________________ = $this->filter('scheduled_time', 'str');
				if (!$_______________ || !$________________)
					throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
				$_______________ = date_parse($_______________);
				$________________ = date_parse($________________);
				$_________________ = (new \DateTime())->setTimezone(new \DateTimeZone($____->timezone))
					->setDate($_______________['year'], $_______________['month'], $_______________['day'])
					->setTime($________________['hour'], $________________['minute'])
					->getTimestamp();
				if ($_________________ <= (\XF::$time + 1) || $_________________ <= 0)
					throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
				if ($_->scheduled != $_________________) {
					$_->set('scheduled', $_________________, ['forceSet' => true]);
					$__________________ = $this->app()->db()->update('xf_job', [
						'trigger_date' => $_________________
					], 'unique_key = ?', 'cnetResourceScheduled' . $______________);
					if (!$__________________) {
						$this->app->jobManager()->enqueueLater(
							'cnetResourceScheduled' . $______________,
							$_________________,
							"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x53\x63\x68\x65\x64\x75\x6c\x65\x64",
							['type' => 'resource', 'id' => $______________],
							false
						);
					}
				}
			} else {
				$___________________ = $_->User;
				$____________________ = 'allowed';
				if ($___________________->isSpamCheckRequired()) {
					$______ = $_____->title . "\n" . $_____->message;
					$_____________________ = $this->app->spam()->contentChecker();
					$_____________________->check($___________________, $______, [
						'permalink' => $this->app->router('public')->buildLink('canonical:resources', $_),
						'content_type' => 'resource_update',
						'content_id' => $_____->resource_update_id,
					]);
					$____________________ = $_____________________->getFinalDecision();
				}
				if ($____________________ == 'allowed') {
					$_______________ = \XF::$time;
					$_->set('resource_state', 'visible', ['forceSet' => true]);
					$_->set('resource_date', $_______________, ['forceSet' => true]);
					$_->set('last_update', $_______________, ['forceSet' => true]);
					$_->set('scheduled', 0, ['forceSet' => true]);
					$______________________ = $_->Discussion;
					if ($______________________) {
						$___________________ = $______________________->User;
						$_______________________ = $______________________->FirstPost;
						$____________________ = 'allowed';
						if ($___________________->isSpamCheckRequired()) {
							$______ = $______________________->title . "\n" . $_______________________->message;
							$_____________________ = $this->app->spam()->contentChecker();
							$_____________________->check($___________________, $______, [
								'permalink' => $this->app->router('public')->buildLink('canonical:threads', $______________________),
								'content_type' => 'thread',
								'content_id' => $______________________->thread_id,
							]);
							$____________________ = $_____________________->getFinalDecision();
						}
						if ($____________________ == 'allowed') {
							$______________________->set('discussion_state', 'visible', ['forceSet' => true]);
							$______________________->save(true, false);
						}
					}
					$________________________ = $this->service('XFRM:ResourceUpdate\Notify', $_____, 'resource');
					$________________________->notifyAndEnqueue(3);
				} else
					$_->set('scheduled', 0, ['forceSet' => true]);
				$this->app()->db()->delete('xf_job', 'unique_key = ?', 'cnetResourceScheduled' . $______________);
			}
		}
		return $__;
	}
	public function actionLanguage(ParameterBag $_)
	{
		$__ = $this->assertViewableResource($_->resource_id);
		if (!$__->canLanguage())
			return $this->error(\XF::phrase('do_not_have_permission'));
		$___ = $__->Translation;
		$____ = $this->repoUtility();
		$_____ = $____->getDefaultLanguageCode();
		$______ = $____->getLanguageList();
		$_______ = [
			'manager' => false,
			'resource' => $__,
			'translation' => $___,
			'default' => $_____,
			'languages' => $______
		];
		return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_______);
	}
	public function actionLanguageManager(ParameterBag $_)
	{
		$__ = $this->assertViewableResource($_->resource_id);
		if (!$__)
			return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
		if (!$__->canLanguage(true))
			return $this->error(\XF::phrase('do_not_have_permission'));
		$___ = $this->app()->options();
		$____ = \XF::visitor();
		$_____ = $____->user_id;
		$______ = $____->is_admin;
		$_______ = $__->Category;
		$________ = ($_______ ? $_______->getBreadcrumbs() : []);
		$________[] = [
			'href' => $this->buildLink('resources', $__),
			'value' => \XF::phrase('xfrm_resource'),
		];
		$_________ = trim($this->filter('do', 'str'));
		if ($_________ == 'change') {
			$__________ = $this->filter('id', 'int');
			if (!$__________)
				return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
			$___________ = $this->finder('XFRM:ResourceItem')->where('resource_id', $__________);
			if (!$______)
				$___________->where('user_id', $_____);
			$___________ = $___________->with('Language')->fetchOne();
			if (!$___________)
				return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
			if ($this->isPost()) {
				$this->assertValidCsrfToken();
				if ($___________->Language) {
					$____________ = trim($this->filter('language_code', 'str'));
					if (!$___________->setLanguage($____________))
						throw $this->exception($this->error($___________->getErrors()));
				}
				return $this->redirect($this->buildLink('resources/language-manager', $__), false);
			}
			$_____________ = [
				'url' => $this->buildLink('resources/language-manager', $__, ['do' => 'change', 'id' => $__________]),
				'title' => $___________->title,
				"\x6f\x76\x65\x72\x6c\x61\x79" => true,
				'content' => $___________,
				'breadcrumbs' => $________
			];
			return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
		} else if ($_________ == 'unlink') {
			$__________ = $this->filter('id', 'int');
			if (!$__________)
				return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
			$___________ = $this->finder('XFRM:ResourceItem')->where('resource_id', $__________);
			if (!$______)
				$___________->where('user_id', $_____);
			$___________ = $___________->with('Language')->fetchOne();
			if (!$___________)
				return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
			if ($this->isPost()) {
				$this->assertValidCsrfToken();
				if ($___________->Language) {
					$___________->Language->delete();
					$___________->set('translation_group', '', ['forceSet' => true]);
					$___________->save(true, false);
				}
				return $this->redirect($this->buildLink('resources/language-manager', $__), false);
			}
			$_____________ = [
				'url' => $this->buildLink('resources/language-manager', $__, ['do' => 'unlink', 'id' => $__________]),
				'title' => \XF::phrase('unlink'),
				"\x6f\x76\x65\x72\x6c\x61\x79" => \XF::phrase('unlink') . ' "' .  $___________->title . '"?',
				'breadcrumbs' => $________
			];
			return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
		} else if ($_________ == 'sync') {
			if ($this->isPost()) {
				if ($__->canSyncLanguage()) {
					$______________ = $__->Translation;
					if ($______________ && count($______________->toArray())) {
						$_______________ = $___->cnet_uptop_time;
						$________________ = '';
						$_________________ = $__->CurrentVersion;
						if ($_________________)
							$________________ = $_________________->version_string;
						foreach ($______________ as $__________________) {
							$___________________ = $__________________->ResourceItem;
							if ($___________________) {
								if (!$______ && $___________________->user_id != $_____)
									continue;
								$____________________ = $___________________->CurrentVersion;
								if ($____________________) {
									if ($____________________->version_string != $________________) {
										$____________________->set('version_string', $________________, ['forceSet' => true]);
										$____________________->save(true, false);
									}
								}
								if ($_______________ && !$___________________->canUptop()) {
									$___________________->setUptop();
									$___________________->saveIfChanged($_____________________, true, false);
								}
							}
						}
					}
				}
				return $this->redirect($this->buildLink('resources/language-manager', $__), false);
			}
			$_____________ = [
				'url' => $this->buildLink('resources/language-manager', $__, ['do' => 'sync']),
				'title' => $__->title,
				"\x6f\x76\x65\x72\x6c\x61\x79" => \XF::phrase('cnet_synchronize_to_other_languages'),
				'breadcrumbs' => $________
			];
			return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
		}
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			$______________________ = trim($this->filter('cnet_search_url', 'str'));
			$____________ = $this->filter('language_code', 'str');
			$_______________________ = intval($this->filter('group_id', 'int'));
			$__________ = intval($this->filter('content_id', 'int'));
			if (!$______________________ || !$____________ || !$_______________________)
				return $this->error(\XF::phrase('field_is_required'));
			$________________________ = preg_quote(rtrim($___->boardUrl, '/'), '/');
			if (!$__________ && preg_match('/' . $________________________ . '\/.+\.[a-z]?(\d+)\/?$/i', $______________________, $_________________________)) {
				if (isset($_________________________[1]) && $_________________________[1])
					$__________ = intval($_________________________[1]);
			}
			if (!$__________)
				return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
			$___________ = $this->finder('XFRM:ResourceItem')->where('resource_id', $__________);
			if (!$____->is_admin)
				$___________->where('user_id', $_____);
			$___________ = $___________->fetchOne();
			if (!$___________)
				return $this->error(\XF::phrase('xfrm_requested_resource_not_found'));
			$__________________________ = $___________->translation_group;
			if ($__________________________ == $_______________________)
				return $this->error(\XF::phrase('existing') . ': "' . $___________->title . '"');
			if ($__________________________)
				return $this->error(\XF::phrase('cnet_content_x_is_already_linked_to_a_different_multilingual_group', ['title' => $___________->title]));
			$___________->set('translation_group', $_______________________, ['forceSet' => true]);
			$___________->save(true, false);
			$___________________________ = $this->em()->create("CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e");
			$___________________________->group_id = $_______________________;
			$___________________________->content_id = $__________;
			$___________________________->content_type = 'resource';
			$___________________________->language_code = $____________;
			$___________________________->save(true, false);
			return $this->redirect($this->getDynamicRedirect($this->buildLink('resources/language-manager', $__), false));
		}
		$______________ = $__->Translation;
		$____________________________ = $this->repoUtility();
		$_____________________________ = $____________________________->getDefaultLanguageCode();
		$______________________________ = $____________________________->getLanguageList();
		$_______________________________ = [$__->resource_id];
		if ($______________) {
			foreach ($______________ as $__________________) {
				$_______________________________[] = $__________________->ResourceItem->resource_id;
			}
		}
		$_______________________________ = implode(',', $_______________________________);
		$_____________ = [
			"\x6f\x76\x65\x72\x6c\x61\x79" => false,
			'manager' => true,
			'resource' => $__,
			'translation' => $______________,
			'default' => $_____________________________,
			'languages' => $______________________________,
			'user_id' => $_____,
			'is_admin' => $______,
			'exclude_id' => $_______________________________,
			'breadcrumbs' => $________
		];
		return $this->view("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */