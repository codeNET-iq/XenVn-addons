<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
use XF\Pub\App;
class LostPassword extends XFCP_LostPassword
{
	public function actionConfirm(ParameterBag $_)
	{
		$__ = $this->app()->options()->cnet_demo_user;
		if ($__) {
			$___ = explode(',', $__);
			if ($___ && in_array($_->user_id, $___)) {
				return $this->noPermission();
			}
		}
		return parent::actionConfirm($_);
	}
	protected function preDispatchController($_, ParameterBag $__)
	{
		App::$allowPageCache = false;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */