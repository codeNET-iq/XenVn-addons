<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
class Forum extends XFCP_Forum
{
	protected $_;
	public function actionForum(ParameterBag $__)
	{
		$___ = parent::actionForum($__);
		if (!$___ instanceof \XF\Mvc\Reply\View)
			return $___;
		$____ = $___->getParam('forum');
		$_____ = $this->app()->options()->cnet_global_sticky_threads;
		$______ = explode(',', $_____);
		if (!$__->page && $_____ && $______) {
			$_______ = \XF::visitor();
			$________ = [];
			foreach ($______ as $_________) {
				$________[] = ['thread_id', '=', $_________];
			}
			$__________ = $this->app()->finder('XF:Thread')
				->whereOr($________)
				->where('discussion_state', 'visible')
				->where('discussion_type', '<>', 'redirect')
				->where('sticky', 1)
				->where('node_id', '<>', $____->node_id)
				->with(["Forum.Node.Permissions|{$_______->permission_combination_id}", 'full'])
				->fetch()
				->filter(function (\XF\Entity\Thread $_) {
					return ($_->canView());
				});
			if ($__________ && count($__________)) {
				$___________ = $___->getParam('stickyThreads');
				if ($___________)
					$___________ = $___________->merge($__________);
				else
					$___________ = $__________;
				$___->setParam('stickyThreads', $___________);
			}
		}
		return $___;
	}
	public function actionList(ParameterBag $__)
	{
		$___ = parent::actionList($__);
		if (!$___ instanceof \XF\Mvc\Reply\View)
			return $___;
		$____ = $this->app()->options();
		$_____ = $____->cnet_forum_statistic;
		$______ = $____->cnet_statistic_tabs;
		if ($_____ && $______ && count($______)) {
			$_______ = $this->repoUtility();
			$________ = reset($______);
			$_________ = '';
			if ((strpos($________, 'forum') !== false) || (strpos($________, 'thread') !== false)) {
				$_________ = 'forum';
			} else if (strpos($________, 'resource') !== false) {
				$_________ = 'resource';
			} else if (strpos($________, 'member') !== false) {
				$_________ = 'member';
			} else if (strpos($________, 'attachment') !== false) {
				$_________ = 'attachment';
			}
			$__________ = $_______->getStatistic($________);
			$___________ = [];
			$___________['forum-last-thread'] = \XF::phrase('cnet_last_thread_name');
			$___________['forum-most-view'] = \XF::phrase('cnet_most_view_name');
			$___________['forum-sticky-thread'] = \XF::phrase('stick_threads');
			$____________ = $this->app->addonManager()->getById('XFRM');
			if ($____________ && $____________->isActive()) {
				$___________['new-resources'] = \XF::phrase('xfrm_new_resources');
				$___________['top-resources'] = \XF::phrase('xfrm_top_resources');
			}
			$___________['top-attachments'] = \XF::phrase('cnet_top_attachment_name');
			$___________['new-members'] = \XF::phrase('cnet_new_member_name');
			$_____________ = [];
			foreach ($______ as $______________ => $_______________) {
				if (isset($___________[$_______________]))
					$_____________[$______________] = ['id' => $_______________, 'name' => $___________[$_______________]];
			}
			if ($__________)
				$___->setParam('cnetStatistics', ['type' => $_________, 'content' => $__________, 'tabs' => $_____________, 'first' => $________]);
		}
		return $___;
	}
	public function actionDownloadedList(ParameterBag $__)
	{
		$___ = $this->app()->options();
		$____ = \XF::visitor();
		$_____ = $____->user_id;
		$______ = ($_____ && $____->user_state == 'valid');
		if (!$______ || !$___->cnet_limit_download)
			return $this->noPermission();
		$_______ = $this->filterPage();
		$________ = 20;
		$_________ = [
			'mode' => '',
			'back' => 0,
			'count' => 0,
			'limitCount' => 0,
			'page' => $_______,
			'perPage' => $________
		];
		$__________ = $this->repoUtility();
		$___________ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
		$___________->setType('Thread');
		$____________ = $_____________ = '';
		$______________ = $this->filter('category_id', 'uint');
		$_______________ = ($___->cnet_limit_count_type == 'content' ? \XF::phrase('threads') : \XF::phrase('attachments'));
		if ($______________) {
			$_________['mode'] = 'all';
			$_________['back'] = 1;
			$____________ = $___________->listItems($______________, true, $_______, $________);
			if ($____________)
				$_________ = array_merge($_________, $____________);
		} else if ($___->cnet_limit_mode == 'each' || $___->cnet_limit_mode == 'each_all') {
			$_________['mode'] = 'each';
			$________________ = $___________->listCategories($_______, $________);
			if ($________________) {
				$_________________ = $________________['nodes'];
				foreach ($_________________ as $__________________ => $___________________) {
					if ($___________________['user_upgrade']) {
						$____________________ = $___________________['count'] . '/' . $___________________['limitCount'];
						$_____________ = \XF::phrase('cnet_you_have_downloaded_x_contents', ['count' => $____________________, 'contents' => $_______________]);
					} else {
						$_____________________ = $__________->convertWaitTime($___________________['limit_time']);
						$____________________ = $___________________['count'] . '/' . $___________________['limitCount'];
						$_____________ = \XF::phrase('cnet_you_have_downloaded_x_contents_in_time', ['count' => $____________________, 'contents' => $_______________, 'time' => $_____________________]);
					}
					$_________________[$__________________]['headerText'] = $_____________;
				}
				$_________['nodes'] = $_________________;
				$_________['count'] = $________________['count'];
			}
		} else {
			$_________['mode'] = 'all';
			$____________ = $___________->listItems(null, true, $_______, $________);
			if ($____________)
				$_________ = array_merge($_________, $____________);
		}
		if ($____________) {
			if ($___________->isUserUpgrade()) {
				$____________________ = $____________['count'] . '/' . $____________['limitCount'];
				$_____________ = \XF::phrase('cnet_you_have_downloaded_x_contents', ['count' => $____________________, 'contents' => $_______________]);
			} else {
				$_____________________ = $__________->convertWaitTime($___________->getLimitTime());
				$____________________ = $____________['count'] . '/' . $____________['limitCount'];
				$_____________ = \XF::phrase('cnet_you_have_downloaded_x_contents_in_time', ['count' => $____________________, 'contents' => $_______________, 'time' => $_____________________]);
				if ($____________['count'] >= $____________['limitCount']) {
					$______________________ = $__________->convertWaitTime($___________->getResetTime());
					$_______________________ = \XF::phrase('cnet_please_wait_x', ['text' => $______________________]);
					$_________['textTime'] = $_______________________;
				}
			}
			$_________['headerText'] = $_____________;
		}
		$this->assertValidPage($_______, $________, $_________['count'], 'forums/downloaded-list');
		return $this->view('XF:Forum\DownloadedList', 'cnet_downloaded_list', $_________);
	}
	public function actionSchedulePublishing(ParameterBag $__)
	{
		$___ = $this->app()->options();
		$____ = \XF::visitor();
		$_____ = $____->user_id;
		$______ = ($_____ && $____->user_state == 'valid');
		if (!$______ || !$___->cnet_schedule_publishing)
			return $this->noPermission();
		$_______ = $this->filterPage();
		$________ = 20;
		$_________ = $this->app()->finder('XF:Thread')
			->where('user_id', $_____)
			->where('discussion_state', 'moderated')
			->where('discussion_type', '<>', 'redirect')
			->where('scheduled', '>', 0)
			->order('scheduled', 'ASC')
			->limitByPage($_______, $________);
		$__________ = $_________->total();
		$___________ = $_________->fetch();
		if (!$___________->count())
			$___________ = false;
		$this->assertValidPage($_______, $________, $__________, 'threads/schedule-publishing');
		$____________ = [
			'type' => 'thread',
			'threads' => $___________,
			'page' => $_______,
			'perPage' => $________
		];
		return $this->view('XF:Forum\DownloadedList', 'cnet_schedule_publishing', $____________);
	}
	public function actionPostThread(ParameterBag $__)
	{
		if (!$__->node_id && !$__->node_name) {
			if (\XF::$versionId >= 2030035)
				return $this->rerouteController(self::class, 'postThreadChooser');
			else
				return $this->rerouteController('XF:Forum', 'postThreadChooser');
		}
		$___ = \XF::visitor();
		$____ = $this->app()->options();
		$_____ = $___->user_id;
		$______ = $this->assertViewableForum($__->node_id ?: $__->node_name, ['DraftThreads|' . $_____]);
		$_______ = $____->cnet_limit_create_new;
		if ($_______ == 'each') {
			$________ = $______->node_id;
			$_________ = $___->hasNodePermission($________, 'limit_create_new');
			if ($_________ != -1) {
				$__________ = 0;
				if ($_________ > 0) {
					$__________ = $this->app()->finder('XF:Thread')
						->where('user_id', $_____)
						->where('node_id', $________)
						->where('post_date', '>', \XF::$time - 86400)
						->total();
				}
				if ($__________ >= $_________)
					throw $this->exception($this->error($______->title . ': ' . \XF::phrase('cnet_you_can_only_create_x_item_in_24_hours', ['count' => $_________, 'item' => \XF::phrase('threads')])));
			}
		} else if ($_______ == 'all') {
			$_________ = $___->hasPermission('forum', 'limit_create_new');
			if ($_________ != -1) {
				$__________ = 0;
				if ($_________ > 0) {
					$__________ = $this->app()->finder('XF:Thread')
						->where('user_id', $_____)
						->where('post_date', '>', \XF::$time - 86400)
						->total();
				}
				if ($__________ >= $_________)
					throw $this->exception($this->error(\XF::phrase('cnet_you_can_only_create_x_item_in_24_hours', ['count' => $_________, 'item' => \XF::phrase('threads')])));
			}
		}
		$___________ = parent::actionPostThread($__);
		$_ = $this->_;
		if ($_) {
			$____________ = $_->thread_id;
			if ($____->cnet_multilingual_content) {
				$_____________ = trim($this->filter('language_code', 'str'));
				if (!$_->setLanguage($_____________))
					throw $this->exception($this->error($_->getErrors()));
			}
			if ($_->scheduled) {
				$this->app->jobManager()->enqueueLater(
					'cnetThreadScheduled' . $____________,
					$_->scheduled,
					"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x53\x63\x68\x65\x64\x75\x6c\x65\x64",
					['type' => 'thread', 'id' => $____________],
					false
				);
			}
			$_->saveIfChanged($______________, true, false);
		}
		return $___________;
	}
	protected function setupThreadCreate(\XF\Entity\Forum $__)
	{
		$___ = parent::setupThreadCreate($__);
		if (!preg_match("/\/post-thread$/i", $this->app->request()->getRoutePath()))
			return $___;
		$____ = $this->app()->options();
		$_____ = \XF::visitor();
		$______ = $_____->user_id;
		$_ = $___->getThread();
		$_______ = $___->getPost();
		$________ = $_______->message;
		if ($____->cnet_optimal_meta_data || $____->cnet_thread_detail) {
			$_________ = false;
			$__________ = $this->filter('attachment_hash', 'str');
			if ($__________ && $_->Forum->canUploadAndManageAttachments())
				$_________ = $this->finder('XF:Attachment')->where('temp_hash', $__________)->fetch();
			$_->setImage($_________, $________);
		}
		if (($____->cnet_optimal_meta_data || $____->cnet_thread_detail) && $________)
			$_->setDescription($________);
		if ($____->cnet_thread_suffix)
			$_->setSuffix($this->filter('suffix', 'str'));
		$___________ = false;
		if ($____->cnet_multilingual_content && $this->filter('language_code', 'str'))
			$___________ = true;
		if ($____->cnet_schedule_publishing && $______ && $this->filter('scheduled', 'bool')) {
			$____________ = $this->filter('scheduled_date', 'str');
			$_____________ = $this->filter('scheduled_time', 'str');
			if (!$____________ || !$_____________)
				throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
			$____________ = date_parse($____________);
			$_____________ = date_parse($_____________);
			$______________ = (new \DateTime())->setTimezone(new \DateTimeZone($_____->timezone))
				->setDate($____________['year'], $____________['month'], $____________['day'])
				->setTime($_____________['hour'], $_____________['minute'])
				->getTimestamp();
			if ($______________ <= (\XF::$time + 1) || $______________ <= 0)
				throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
			$_->set('discussion_state', 'moderated', ['forceSet' => true]);
			$_->set('scheduled', $______________, ['forceSet' => true]);
			$___________ = true;
		}
		if ($___________)
			$this->_ = $_;
		return $___;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */