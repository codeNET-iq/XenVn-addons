<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
class ExtendLogin extends XFCP_Login
{
	protected $_ = false;
	protected function actionIndexExtend($__)
	{
		$___ = $this->app()->options()->cnet_login_security ?? false;
		if (!$___ || !$__ instanceof \XF\Mvc\Reply\View)
			return $__;
		$____ = $this->limitLoginAttempts();
		if ($____ && \XF::$versionId >= 2021270)
			$this->assertCaptchaCookieConsent(null, true);
		$__->setParam('captcha', $____);
		return $__;
	}
	protected function actionLoginExtend()
	{
		$__ = $this->app()->options()->cnet_login_security ?? false;
		if ($__) {
			$this->_ = $___ = $this->limitLoginAttempts();
			if ($___ && \XF::$versionId >= 2021270)
				$this->assertCaptchaCookieConsent(null, true);
			if ($this->isPost()) {
				$____ = $this->getDynamicRedirectIfNot($this->buildLink('index'));
				if ($this->filter('keeplogin', 'bool'))
					return $this->redirect($____);
				$_____ = $this->filter('login', 'str');
				$______ = $this->repository('XF:ConnectedAccount');
				$_______ = $______->getUsableProviders(false);
				if ($___ && !$this->captchaIsValid(true)) {
					if (\XF::$versionId >= 2030035) {
						$________ = $this->service('XF:Passkey\Manager');
						$________->saveStateToSession($this->session());
					} else
						$________ = false;
					$_________ = [
						'captcha' => $___,
						'login' => $_____,
						'error' => \XF::phrase('did_not_complete_the_captcha_verification_properly'),
						'redirect' => $____,
						'providers' => $_______,
						'passkey' => $________
					];
					return $this->view('XF:Login\Form', 'login', $_________);
				}
			}
		}
		return false;
	}
	protected function limitLoginAttempts()
	{
		$__ = $this->request->getIp();
		if (!$__)
			return false;
		$___ = [
			['type' => 'ip',   'time' => 60 * 5, 'count' => 2],
			['type' => 'ip',   'time' => 60 * 30, 'count' => 4]
		];
		$____ = $this->repository('XF:LoginAttempt');
		foreach ($___ as $_____) {
			$______ = \XF::$time - $_____['time'];
			$_______ = $_____['count'];
			if ($____->countLoginAttemptsSince($______, $__) >= $_______)
				return true;
		}
		return false;
	}
}
if (\XF::$versionId >= 2030035) {
	class Login extends ExtendLogin
	{
		public function actionIndex()
		{
			return $this->actionIndexExtend(parent::actionIndex());
		}
		public function actionLogin(ParameterBag $__)
		{
			$___ = $this->actionLoginExtend();
			if ($___ !== false)
				return $___;
			$___ = parent::actionLogin($__);
			if (!$___ instanceof \XF\Mvc\Reply\View)
				return $___;
			$____ = $this->_;
			$___->setParam('captcha', $____);
			return $___;
		}
	}
} else {
	class Login extends ExtendLogin
	{
		public function actionIndex()
		{
			return $this->actionIndexExtend(parent::actionIndex());
		}
		public function actionLogin()
		{
			$__ = $this->actionLoginExtend();
			if ($__ !== false)
				return $__;
			$__ = parent::actionLogin();
			if (!$__ instanceof \XF\Mvc\Reply\View)
				return $__;
			$___ = $this->_;
			$__->setParam('captcha', $___);
			return $__;
		}
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */