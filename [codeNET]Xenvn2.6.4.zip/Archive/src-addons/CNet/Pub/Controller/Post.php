<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
class Post extends XFCP_Post
{
	public function actionChange(ParameterBag $_)
	{
		$__ = \XF::visitor();
		if (!$this->app()->options()->cnet_change_post || (!$__->is_admin && !$__->is_moderator))
			return $this->noPermission();
		$___ = $this->assertViewablePost($_->post_id);
		if (!$___->canEdit())
			return $this->noPermission();
		$____ = $__->timezone;
		if (!$this->isPost()) {
			date_default_timezone_set($____);
			$_____ = date('H:i', time());
			$______ = date('Y-m-d', time());
			$_______ = [
				'post' => $___,
				'currentTime' => $_____,
				'currentDate' => $______
			];
			return $this->view("CNet\x3a\x50\x6f\x73\x74\x5c\x43\x68\x61\x6e\x67\x65", 'cnet_change_content', $_______);
		} else {
			$________ = $this->service("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x43\x68\x61\x6e\x67\x65");
			$_________ = $___->username;
			$__________ = trim($this->filter('new_author', 'str'));
			if (!empty($__________) && $_________ != $__________) {
				$___________ = $this->app()->em()->findOne('XF:User', ['username' => $__________]);
				if (!$___________)
					return $this->error(\XF::phrase('requested_user_not_found'));
				$________->updateAuthor($___, $___________);
			}
			$____________ = $this->filter('new_date', 'str');
			$_____________ = $this->filter('new_time', 'str');
			if (!empty($____________) && !empty($_____________)) {
				$____________ = date_parse($____________);
				$_____________ = date_parse($_____________);
				$______________ = (new \DateTime())->setTimezone(new \DateTimeZone($____))
					->setDate($____________['year'], $____________['month'], $____________['day'])
					->setTime($_____________['hour'], $_____________['minute'])
					->getTimestamp();
				if ($______________ > \XF::$time || $______________ <= 0)
					return $this->error(\XF::phrase('please_enter_valid_time_format'));
				else if ($___->post_date != $______________)
					$________->updateDate($___, $______________);
			}
			return $this->redirect(
				$this->getDynamicRedirect($this->buildLink('posts', $___), false)
			);
		}
	}
	protected function setupFirstPostThreadEdit(\XF\Entity\Thread $_, &$__)
	{
		$___ = parent::setupFirstPostThreadEdit($_, $__);
		if (!$__['title'])
			$__['title'] = $_->isChanged('suffix');
		return $___;
	}
	protected function setupPostEdit(\XF\Entity\Post $_)
	{
		$__ = parent::setupPostEdit($_);
		$___ = $_->Thread;
		if (!$_->isFirstPost() || !$___->canEdit())
			return $__;
		if (!preg_match("/\/edit$/i", $this->app->request()->getRoutePath()))
			return $__;
		$____ = $this->app()->options();
		$_____ = \XF::visitor();
		if ($____->cnet_optimal_meta_data || $____->cnet_thread_detail) {
			$______ = $_->message;
			$_______ = $___->image;
			$________ = preg_quote($this->app()->options()->boardUrl, '/') . '\/(data\/avatars|styles\/CNet)\/.+\.(jpg|png|gif|webp)$';
			if (!$_______ || preg_match("/$________/i", $_______) || strpos($_______, 'gravatar.com/avatar/') !== false) {
				$_________ = $this->filter('attachment_hash', 'str');
				if ($_________) {
					$__________ = $this->finder('XF:Attachment')->where('temp_hash', $_________)->fetch();
					if ($__________)
						$___->setImage($__________, $______);
				}
			}
			if (!$___->description || $____->cnet_auto_description)
				$___->setDescription($______);
		}
		if ($____->cnet_uptop_time && empty($___->canUptop())) {
			$___________ = $this->app['session.public'];
			$____________ = $this->filter('uptop', 'bool');
			$___________->set('cnet_disable_uptop', !$____________);
			if ($____________)
				$___->setUptop($this->filter('reason_uptop', 'str'));
		}
		if ($____->cnet_thread_suffix)
			$___->setSuffix($this->filter('suffix', 'str'));
		if ($____->cnet_multilingual_content) {
			$_____________ = trim($this->filter('language_code', 'str'));
			if (!$___->setLanguage($_____________))
				throw $this->exception($this->error($___->getErrors()));
		}
		if ($____->cnet_schedule_publishing && $___->scheduled) {
			$______________ = $___->thread_id;
			if ($this->filter('scheduled', 'bool')) {
				$_______________ = $this->filter('scheduled_date', 'str');
				$________________ = $this->filter('scheduled_time', 'str');
				if (!$_______________ || !$________________)
					throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
				$_______________ = date_parse($_______________);
				$________________ = date_parse($________________);
				$_________________ = (new \DateTime())->setTimezone(new \DateTimeZone($_____->timezone))
					->setDate($_______________['year'], $_______________['month'], $_______________['day'])
					->setTime($________________['hour'], $________________['minute'])
					->getTimestamp();
				if ($_________________ <= (\XF::$time + 1) || $_________________ <= 0)
					throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
				if ($___->scheduled != $_________________) {
					$___->set('scheduled', $_________________, ['forceSet' => true]);
					$__________________ = $this->app()->db()->update('xf_job', [
						'trigger_date' => $_________________
					], 'unique_key = ?', 'cnetThreadScheduled' . $______________);
					if (!$__________________) {
						$this->app->jobManager()->enqueueLater(
							'cnetThreadScheduled' . $______________,
							$_________________,
							"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x53\x63\x68\x65\x64\x75\x6c\x65\x64",
							['type' => 'thread', 'id' => $______________],
							false
						);
					}
				}
			} else {
				$___________________ = $_->User;
				$____________________ = 'allowed';
				if ($___________________->isSpamCheckRequired()) {
					$______ = $___->title . "\n" . $_->message;
					$_____________________ = $this->app->spam()->contentChecker();
					$_____________________->check($___________________, $______, [
						'permalink' => $this->app->router('public')->buildLink('canonical:threads', $___),
						'content_type' => 'thread',
						'content_id' => $______________,
					]);
					$____________________ = $_____________________->getFinalDecision();
				}
				if ($____________________ == 'allowed') {
					$_______________ = \XF::$time;
					$___->set('discussion_state', 'visible', ['forceSet' => true]);
					$___->set('post_date', $_______________, ['forceSet' => true]);
					$___->set('last_post_date', $_______________, ['forceSet' => true]);
					$___->set('scheduled', 0, ['forceSet' => true]);
					$______________________ = $this->service('XF:Post\Notifier', $_, 'thread');
					$______________________->notifyAndEnqueue(3);
				} else
					$___->set('scheduled', 0, ['forceSet' => true]);
				$this->app()->db()->delete('xf_job', 'unique_key = ?', 'cnetThreadScheduled' . $______________);
			}
		}
		return $__;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */