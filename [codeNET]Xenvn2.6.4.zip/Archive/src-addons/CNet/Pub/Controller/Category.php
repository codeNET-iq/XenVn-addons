<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
class Category extends XFCP_Category
{
	protected $_;
	public function actionAdd(ParameterBag $__)
	{
		$___ = \XF::visitor();
		$____ = $this->app()->options();
		$_____ = $___->user_id;
		$______ = $this->assertViewableCategory($__->resource_category_id);
		$_______ = $____->cnet_limit_create_new;
		if ($_______ == 'each') {
			$________ = $______->resource_category_id;
			$_________ = $___->hasResourceCategoryPermission($________, 'limit_create_new');
			if ($_________ != -1) {
				$__________ = 0;
				if ($_________ > 0) {
					$__________ = $this->app()->finder('XFRM:ResourceItem')
						->where('user_id', $_____)
						->where('resource_category_id', $________)
						->where('resource_date', '>', \XF::$time - 86400)
						->total();
				}
				if ($__________ >= $_________)
					throw $this->exception($this->error($______->title . ': ' . \XF::phrase('cnet_you_can_only_create_x_item_in_24_hours', ['count' => $_________, 'item' => \XF::phrase('xfrm_resources')])));
			}
		} else if ($_______ == 'all') {
			$_________ = $___->hasPermission('resource', 'limit_create_new');
			if ($_________ != -1) {
				$__________ = 0;
				if ($_________ > 0) {
					$__________ = $this->app()->finder('XFRM:ResourceItem')
						->where('user_id', $_____)
						->where('resource_date', '>', \XF::$time - 86400)
						->total();
				}
				if ($__________ >= $_________)
					throw $this->exception($this->error(\XF::phrase('cnet_you_can_only_create_x_item_in_24_hours', ['count' => $_________, 'item' => \XF::phrase('xfrm_resources')])));
			}
		}
		$___________ = parent::actionAdd($__);
		$_ = $this->_;
		if ($_) {
			$____________ = $_->resource_id;
			if ($____->cnet_multilingual_content) {
				$_____________ = trim($this->filter('language_code', 'str'));
				if (!$_->setLanguage($_____________))
					throw $this->exception($this->error($_->getErrors()));
			}
			if ($_->scheduled) {
				$this->app->jobManager()->enqueueLater(
					'cnetResourceScheduled' . $____________,
					$_->scheduled,
					"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x53\x63\x68\x65\x64\x75\x6c\x65\x64",
					['type' => 'resource', 'id' => $____________],
					false
				);
			}
			$_->saveIfChanged($______________, true, false);
		}
		return $___________;
	}
	protected function setupResourceCreate(\XFRM\Entity\Category $__)
	{
		$___ = parent::setupResourceCreate($__);
		if (!preg_match("/\/add$/i", $this->app->request()->getRoutePath()))
			return $___;
		$____ = $this->app()->options();
		$_____ = \XF::visitor();
		$______ = $_____->user_id;
		$_ = $___->getResource();
		$_______ = $___->getDescription();
		$________ = $_______->message;
		if ($____->cnet_optimal_meta_data) {
			$_________ = false;
			$__________ = $this->filter('attachment_hash', 'str');
			if ($__________ && $_->Category->canUploadAndManageUpdateImages())
				$_________ = $this->finder('XF:Attachment')->where('temp_hash', $__________)->fetch();
			$_->setImage($_________, $________);
		}
		if ($____->cnet_optimal_meta_data && $________)
			$_->setDescription($________);
		$___________ = false;
		if ($____->cnet_multilingual_content && $this->filter('language_code', 'str'))
			$___________ = true;
		if ($____->cnet_schedule_publishing && $______ && $this->filter('scheduled', 'bool')) {
			$____________ = $this->filter('scheduled_date', 'str');
			$_____________ = $this->filter('scheduled_time', 'str');
			if (!$____________ || !$_____________)
				throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
			$____________ = date_parse($____________);
			$_____________ = date_parse($_____________);
			$______________ = (new \DateTime())->setTimezone(new \DateTimeZone($_____->timezone))
				->setDate($____________['year'], $____________['month'], $____________['day'])
				->setTime($_____________['hour'], $_____________['minute'])
				->getTimestamp();
			if ($______________ <= (\XF::$time + 1) || $______________ <= 0)
				throw $this->exception($this->error(\XF::phrase('cnet_schedule_publishing') . ': ' . \XF::phrase('please_enter_valid_time_format')));
			$_->set('resource_state', 'moderated', ['forceSet' => true]);
			$_->set('scheduled', $______________, ['forceSet' => true]);
			$___________ = false;
		}
		if ($___________)
			$this->_ = $_;
		return $___;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */