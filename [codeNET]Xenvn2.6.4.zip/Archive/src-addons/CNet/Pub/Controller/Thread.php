<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
use XF\Mvc\Entity\AbstractCollection;
class Thread extends XFCP_Thread
{
	protected function getThreadViewExtraWith()
	{
		$_ = parent::getThreadViewExtraWith();
		$__ = $this->app()->options();
		if ($__->cnet_multilingual_content)
			$_[] = 'Language';
		return $_;
	}
	protected function getNewPostsReplyInternal(\XF\Entity\Thread $_, AbstractCollection $__, ?\XF\Entity\Post $___ = null)
	{
		$____ = parent::getNewPostsReplyInternal($_, $__,  $___);
		$_____ = $this->app()->options();
		$______ = \XF::visitor();
		if ($_____->cnet_limit_download && $_____->cnet_force_like == 'all' && $_->user_id != $______->user_id) {
			$_______ = $_->node_id;
			$________ = $_->FirstPost;
			if ($_______ && $________ && $this->repoUtility()->isLimitCategory($_______, 'post') && !$______->hasNodePermission($_______, 'cnet_bypass_like_view')) {
				$_________ = $________->message;
				if ($_________ && preg_match('/\[code[^\]]*\].+\[\/code\]/is', $_________)) {
					$this->app->templater()->addDefaultParam('xf',  ['visitor' => $______, 'options' => $_____]);
					$__________ = $this->app->bbCode()->render($_________, 'html', 'post', $________, []);
					$____->setJsonParams(['message' => $__________, 'id' => 'js-post-' . $________->post_id]);
				}
			}
		}
		return $____;
	}
	public function actionAddReply(ParameterBag $_)
	{
		if ($this->app()->options()->cnet_schedule_publishing) {
			$__ = $this->assertViewableThread($_->thread_id, ['Watch|' . \XF::visitor()->user_id]);
			if ($__->scheduled)
				return $this->error(\XF::phrase('cnet_you_cannot_reply_to_content_scheduled_for_publishing'));
			if ($__->discussion_type == 'resource') {
				$___ = $this->app()->addonManager()->getById('XFRM');
				if ($___ && $___->isActive()) {
					$____ = $this->app()->em()->findOne('XFRM:ResourceItem', ['discussion_thread_id', '=', $__->thread_id]);
					if ($____ && $____->scheduled)
						return $this->error(\XF::phrase('cnet_you_cannot_reply_to_content_scheduled_for_publishing'));
				}
			}
		}
		return parent::actionAddReply($_);
	}
	public function actionDownloadLogs(ParameterBag $_)
	{
		$this->assertRegistrationRequired();
		$__ = $this->app()->options();
		$___ = \XF::visitor();
		$____ = $___->user_id;
		$_____ = $this->assertViewableThread($_->thread_id, ['FirstPost']);
		if (!$__->cnet_limit_download || !$____ || $___->user_state != 'valid' || !in_array($_____->node_id, (array)$__->cnet_limit_category))
			return $this->error(\XF::phrase('do_not_have_permission'));
		if ($_____->user_id == $____ || $___->is_admin) {
			$______ = $this->filterPage();
			$_______ = 20;
			$________ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
			$________->setType('Thread');
			$_________ = $________->downloadLogs($_____->thread_id, true, $______, $_______);
			if ($_________) {
				$__________ = $_________['count'];
				$this->assertValidPage($______, $_______, $__________, 'threads/download-logs', $_____);
				$___________ = $_____->Forum;
				$____________ = ($___________ ? $___________->getBreadcrumbs() : []);
				$____________[] = [
					'href' => $this->buildLink('threads', $_____),
					'value' => \XF::phrase('thread'),
				];
				$_____________ = [
					'downloadLogs' => true,
					'thread' => $_____,
					'logs' => $_________['logs'],
					'count' => $__________,
					'page' => $______,
					'perPage' => $_______,
					'breadcrumbs' => $____________
				];
				return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x4c\x6f\x67\x73", 'cnet_downloaded_list', $_____________);
			}
		}
		return $this->error(\XF::phrase('do_not_have_permission'));
	}
	public function actionUpdate(ParameterBag $_)
	{
		$this->assertRegistrationRequired();
		$__ = $this->app();
		$___ = $__->options();
		$____ = \XF::visitor();
		$_____ = $____->user_id;
		$______ = $this->assertViewableThread($_->thread_id, ['FirstPost']);
		if (!$______->canUpdate())
			return $this->error(\XF::phrase('do_not_have_permission'));
		$_______ = $__['session.public'];
		$________ = $______->Forum;
		$_________ = $________->node_id;
		$__________ = $______->FirstPost;
		$___________ = $__________->post_id;
		$____________ = ($____->is_admin || $____->is_moderator);
		$_____________ = $______->canUptop();
		$______________ = ($___->cnet_update_attachment && ($____->hasNodePermission($_________, 'uploadAttachment') || $____->hasNodePermission($_________, 'uploadVideo') || $____________));
		$_______________ = (($___->cnet_optimal_meta_data || $___->cnet_thread_detail) && ($_____ == $______->user_id || $____________));
		$________________ = $___->cnet_multilingual_content && ($_____ == $______->user_id || $____________);
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			$this->setResponseType('json');
			$_________________ = $this->request->getFile('upload', false, false);
			$__________________ = $__________->message;
			if ($______________ && $_________________) {
				$___________________ = $this->repository('XF:Attachment');
				$____________________ = $___________________->getDefaultAttachmentConstraints();
				$_____________________ = $___________________->getAttachmentHandler('post');
				if ($___->allowVideoUploads['enabled'])
					$____________________ = $___________________->applyVideoAttachmentConstraints($____________________);
				$_________________->applyConstraints($____________________);
				$______________________ = [];
				if (!$_________________->isValid($______________________)) {
					$_______________________ = reset($______________________);
					return $this->error($_______________________);
				}
				$________________________ = $_________________->getFileWrapper();
				$_________________________ = $this->filter('data_id', 'int');
				if ($_________________________) {
					$__________________________ = \XF::$time;
					$___________________________ = ['gif', 'jpg', 'jpeg', 'png', 'webp'];
					$________________________ = $_________________->getFileWrapper();
					$____________________________ = $this->finder('XF:Attachment')->where('data_id', $_________________________)->fetchOne();
					$_____________________________ = $____________________________->Data;
					if ($_____________________________) {
						$______________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
						$_______________________________ = $_____________________________->filename;
						$________________________________ = $_____________________________->getExtension();
						$_________________________________ = $________________________->getExtension();
						$__________________________________ = $________________________->getFileName();
						if ($________________________________ = $_________________________________ || (in_array($________________________________, $___________________________) && in_array($_________________________________, $___________________________))) {
							$_____________________________->user_id = $_____;
							$_____________________________->filename = $__________________________________;
							$_____________________________->upload_date = $__________________________;
							$___________________________________ = $__->service('XF:Attachment\Preparer');
							$___________________________________->updateDataFromFile($_____________________________, $________________________);
							$____________________________->attach_date = $__________________________;
							$____________________________->save(true, false);
							$____________________________________ = $____________________________->attachment_id;
							$_____________________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
							$__________________ = str_replace([$______________________________, $_______________________________], [$_____________________________________, $__________________________________], $__________________, $______________________________________);
							if ($______________________________________)
								$__________->message = $__________________;
							$__->jobManager()->enqueueUnique(
								'cnetAttachmentUrlPost' . $___________,
								"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
								[
									'job_type' => 'attachment_url',
									'id' => $___________,
									'url_find' => $______________________________,
									'url_replace' => $_____________________________________,
									'content_type' => 'post'
								],
								false
							);
							$_______________________________________ = $______->image;
							if ($____________________________->hasThumbnail() && $_______________________________________ && (strpos($_______________________________________, '.' . $____________________________________ . '/') !== false || strpos($_______________________________________, '.a' . $____________________________________ . '/') !== false)) {
								if ($_____________________________________ != $_______________________________________) {
									$________________________________________ = preg_replace('/\?hash=\w+$/i', '',  $____________________________->getThumbnailUrlFull());
									$______->set('image', $_____________________________________, ['forceSet' => true]);
									$______->set('icon', $________________________________________, ['forceSet' => true]);
								}
							}
						} else
							return $this->error(\XF::phrase('one_or_more_files_do_not_have_allowed_extension_x', ['allowed' => $________________________________]));
					}
				} else {
					if ($__________->attach_count >= $___->attachmentMaxPerMessage)
						return $this->error(\XF::phrase('you_have_reached_the_maximum_limit_for_attachment_uploads'));
					$_________________________________________ =  md5_file($_________________->getTempFile());
					$__________________________________________ = $__->service('XF:Attachment\Preparer');
					$____________________________ = $__________________________________________->insertAttachment(
						$_____________________,
						$________________________,
						$____,
						$_________________________________________
					);
					if ($____________________________) {
						$____________________________->content_type = 'post';
						$____________________________->content_id = $___________;
						$____________________________->temp_hash = '';
						$____________________________->unassociated = 0;
						$____________________________->save(true, false);
						$____________________________->getHandler()->onAssociation($____________________________, $____________________________->getContainer());
						$__________->attach_count++;
						if ($____________________________->hasThumbnail()) {
							$_______________________________________ = $______->image;
							$___________________________________________ = preg_quote($this->app()->options()->boardUrl, '/') . '\/(data\/avatars|styles\/CNet)\/.+\.(jpg|png|gif|webp)$';
							if (!$_______________________________________ || preg_match("/$___________________________________________/i", $_______________________________________) || strpos($_______________________________________, 'gravatar.com/avatar/') !== false) {
								$_____________________________________ = $__->router('public')->buildLink('full:attachments', $____________________________);
								$________________________________________ = preg_replace('/\?hash=\w+$/i', '',  $____________________________->getThumbnailUrlFull());
								$______->set('image', $_____________________________________, ['forceSet' => true]);
								$______->set('icon', $________________________________________, ['forceSet' => true]);
							}
						}
					}
				}
			}
			if ($___->cnet_thread_suffix)
				$______->setSuffix($this->filter('suffix', 'str'));
			if ($_______________) {
				$_____________________________________ = $this->filter('image_link', 'str');
				if ($_____________________________________ && $_____________________________________ != $______->image)
					$______->setImage('', '', $_____________________________________);
				if (!$___->cnet_auto_description)
					$__________________ = $this->filter('description', 'str');
				$______->setDescription($__________________);
			}
			$____________________________________________ = false;
			if ($___->cnet_uptop_time && empty($_____________)) {
				$____________________________________________ = $this->filter('uptop', 'bool');
				$_______->set('cnet_disable_uptop', !$____________________________________________);
				if ($____________________________________________)
					$______->setUptop($this->filter('reason_uptop', 'str'));
			}
			if (!$____________________________________________) {
				$_____________________________________________ = $this->router()->buildLink('threads', $______);
				$this->repoUtility()->sentAlert('thread', $______->thread_id, $______->user_id, $_____________________________________________, $______->title, $______->suffix, '', true);
			}
			if ($________________) {
				$______________________________________________ = trim($this->filter('language_code', 'str'));
				if (!$______->setLanguage($______________________________________________))
					throw $this->exception($this->error($______->getErrors()));
			}
			$______->save(true, false);
			$__________->save(true, false);
			return $this->redirect($this->getDynamicRedirect($this->buildLink('threads', $______), false));
		} else {
			$___________________ = $this->repository('XF:Attachment');
			$____________________ = $___________________->getDefaultAttachmentConstraints();
			if ($________ && $________->canUploadVideos())
				$____________________ = $___________________->applyVideoAttachmentConstraints($____________________);
			$_______________________________________________ = $____________________['extensions'];
			foreach ($_______________________________________________ as $________________________________________________ => $_________________________________________________) {
				$_______________________________________________[$________________________________________________] = ".$_________________________________________________";
			}
			$__________________________________________________ = '.*';
			if ($_______________________________________________ && count($_______________________________________________))
				$__________________________________________________ = implode(',', $_______________________________________________);
			$___________________________________________________ = $this->finder('XF:Attachment')
				->where('content_type', 'post')
				->where('content_id', $___________);
			if (!$____________)
				$___________________________________________________->where('Data.user_id', $_____);
			$____________________________________________________ = $___________________________________________________->with('Data')->fetch();
			$_____________________________________________________ = [
				'thread' => $______,
				'attachments' => $____________________________________________________,
				'uptop_wait' => $_____________,
				'disable_uptop' => $_______->get('cnet_disable_uptop'),
				'extensions' => $__________________________________________________,
				'update_attachment' => $______________,
				'update_meta' => $_______________,
				'update_language' => $________________
			];
			return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x55\x70\x64\x61\x74\x65", 'cnet_update_content', $_____________________________________________________);
		}
	}
	public function actionLanguage(ParameterBag $_)
	{
		$__ = $this->assertViewableThread($_->thread_id);
		if (!$__->canLanguage())
			return $this->error(\XF::phrase('do_not_have_permission'));
		$___ = $__->Translation;
		$____ = $this->repoUtility();
		$_____ = $____->getDefaultLanguageCode();
		$______ = $____->getLanguageList();
		$_______ = [
			'manager' => false,
			'thread' => $__,
			'translation' => $___,
			'default' => $_____,
			'languages' => $______
		];
		return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_______);
	}
	public function actionLanguageManager(ParameterBag $_)
	{
		$__ = $this->assertViewableThread($_->thread_id);
		if (!$__)
			return $this->error(\XF::phrase('requested_thread_not_found'));
		if (!$__->canLanguage(true))
			return $this->error(\XF::phrase('do_not_have_permission'));
		$___ = $this->app()->options();
		$____ = \XF::visitor();
		$_____ = $____->user_id;
		$______ = $____->is_admin;
		$_______ = $__->Forum;
		$________ = ($_______ ? $_______->getBreadcrumbs() : []);
		$________[] = [
			'href' => $this->buildLink('threads', $__),
			'value' => \XF::phrase('thread'),
		];
		$_________ = trim($this->filter('do', 'str'));
		if ($_________ == 'change') {
			$__________ = $this->filter('id', 'int');
			if (!$__________)
				return $this->error(\XF::phrase('requested_thread_not_found'));
			$___________ = $this->finder('XF:Thread')->where('thread_id', $__________);
			if (!$______)
				$___________->where('user_id', $_____);
			$___________ = $___________->with('Language')->fetchOne();
			if (!$___________)
				return $this->error(\XF::phrase('requested_thread_not_found'));
			if ($this->isPost()) {
				$this->assertValidCsrfToken();
				if ($___________->Language) {
					$____________ = trim($this->filter('language_code', 'str'));
					if (!$___________->setLanguage($____________))
						throw $this->exception($this->error($___________->getErrors()));
				}
				return $this->redirect($this->buildLink('threads/language-manager', $__), false);
			}
			$_____________ = [
				'url' => $this->buildLink('threads/language-manager', $__, ['do' => 'change', 'id' => $__________]),
				'title' => $___________->title,
				"\x6f\x76\x65\x72\x6c\x61\x79" => true,
				'content' => $___________,
				'breadcrumbs' => $________
			];
			return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
		} else if ($_________ == 'unlink') {
			$__________ = $this->filter('id', 'int');
			if (!$__________)
				return $this->error(\XF::phrase('requested_thread_not_found'));
			$___________ = $this->finder('XF:Thread')->where('thread_id', $__________);
			if (!$______)
				$___________->where('user_id', $_____);
			$___________ = $___________->with('Language')->fetchOne();
			if (!$___________)
				return $this->error(\XF::phrase('requested_thread_not_found'));
			if ($this->isPost()) {
				$this->assertValidCsrfToken();
				if ($___________->Language) {
					$___________->Language->delete();
					$___________->set('translation_group', '', ['forceSet' => true]);
					$___________->save(true, false);
				}
				return $this->redirect($this->buildLink('threads/language-manager', $__), false);
			}
			$_____________ = [
				'url' => $this->buildLink('threads/language-manager', $__, ['do' => 'unlink', 'id' => $__________]),
				'title' => \XF::phrase('unlink'),
				"\x6f\x76\x65\x72\x6c\x61\x79" => \XF::phrase('unlink') . ' "' .  $___________->title . '"?',
				'breadcrumbs' => $________
			];
			return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
		} else if ($_________ == 'sync') {
			if ($this->isPost()) {
				$this->assertValidCsrfToken();
				if ($__->canSyncLanguage()) {
					$______________ = $__->Translation;
					if ($______________ && count($______________->toArray())) {
						$_______________ = $___->cnet_uptop_time;
						$________________ = $___->cnet_thread_suffix;
						$_________________ = $__->suffix;
						foreach ($______________ as $__________________) {
							$___________________ = $__________________->Thread;
							if ($___________________) {
								if (!$______ && $___________________->user_id != $_____)
									continue;
								if ($________________)
									$___________________->setSuffix($_________________);
								if ($_______________ && !$___________________->canUptop())
									$___________________->setUptop();
								if ($_______________ || $________________)
									$___________________->saveIfChanged($____________________, true, false);
							}
						}
					}
				}
				return $this->redirect($this->buildLink('threads/language-manager', $__), false);
			}
			$_____________ = [
				'url' => $this->buildLink('threads/language-manager', $__, ['do' => 'sync']),
				'title' => $__->title,
				"\x6f\x76\x65\x72\x6c\x61\x79" => \XF::phrase('cnet_synchronize_to_other_languages'),
				'breadcrumbs' => $________
			];
			return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
		}
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			$_____________________ = trim($this->filter('cnet_search_url', 'str'));
			$____________ = $this->filter('language_code', 'str');
			$______________________ = intval($this->filter('group_id', 'int'));
			$__________ = intval($this->filter('content_id', 'int'));
			if (!$_____________________ || !$____________ || !$______________________)
				return $this->error(\XF::phrase('field_is_required'));
			$_______________________ = preg_quote(rtrim($___->boardUrl, '/'), '/');
			if (!$__________ && preg_match('/' . $_______________________ . '\/.+\.[a-z]?(\d+)\/?$/i', $_____________________, $________________________)) {
				if (isset($________________________[1]) && $________________________[1])
					$__________ = intval($________________________[1]);
			}
			if (!$__________)
				return $this->error(\XF::phrase('requested_thread_not_found'));
			$___________ = $this->finder('XF:Thread')->where('thread_id', $__________);
			if (!$______)
				$___________->where('user_id', $_____);
			$___________ = $___________->fetchOne();
			if (!$___________)
				return $this->error(\XF::phrase('requested_thread_not_found'));
			$_________________________ = $___________->translation_group;
			if ($_________________________ == $______________________)
				return $this->error(\XF::phrase('existing') . ': "' . $___________->title . '"');
			if ($_________________________)
				return $this->error(\XF::phrase('cnet_content_x_is_already_linked_to_a_different_multilingual_group', ['title' => $___________->title]));
			$___________->set('translation_group', $______________________, ['forceSet' => true]);
			$___________->save(true, false);
			$__________________________ = $this->em()->create("CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e");
			$__________________________->group_id = $______________________;
			$__________________________->content_id = $__________;
			$__________________________->content_type = 'thread';
			$__________________________->language_code = $____________;
			$__________________________->save(true, false);
			return $this->redirect($this->getDynamicRedirect($this->buildLink('threads/language-manager', $__), false));
		}
		$______________ = $__->Translation;
		$___________________________ = $this->repoUtility();
		$____________________________ = $___________________________->getDefaultLanguageCode();
		$_____________________________ = $___________________________->getLanguageList();
		$______________________________ = [$__->thread_id];
		if ($______________) {
			foreach ($______________ as $__________________) {
				$______________________________[] = $__________________->Thread->thread_id;
			}
		}
		$______________________________ = implode(',', $______________________________);
		$_____________ = [
			"\x6f\x76\x65\x72\x6c\x61\x79" => false,
			'manager' => true,
			'thread' => $__,
			'translation' => $______________,
			'default' => $____________________________,
			'languages' => $_____________________________,
			'user_id' => $_____,
			'is_admin' => $______,
			'exclude_id' => $______________________________,
			'breadcrumbs' => $________
		];
		return $this->view("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x4c\x61\x6e\x67\x75\x61\x67\x65", 'cnet_multilingual', $_____________);
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */