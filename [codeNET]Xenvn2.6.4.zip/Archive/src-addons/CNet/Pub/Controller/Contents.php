<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Pub\Controller\AbstractController;
use XF\Mvc\ParameterBag;
class Contents extends AbstractController
{
	public function actionIndex(ParameterBag $_)
	{
		$__ = $this->app();
		if (!$__->options()->cnet_seo_keywords)
			return $this->noPermission();
		$___ = $_->content_url;
		if (!$___)
			return $this->redirect($__->router('public')->buildLink('index'));
		$____ = $this->repoUtility()->getSeoUrl($___);
		if (!$____)
			return $this->notFound();
		[$___, $_____, $______] = $____;
		$_______ = $this->buildLink('canonical:contents/' . $_____ . '/');
		$this->assertCanonicalUrl($_______);
		$________ = $__->options();
		$_________ = [];
		$__________ = $________->discussionsPerPage;
		if ($__________ % 3 != 0)
			$__________ += 3 - ($__________ % 3);
		$___________ = $this->repoUtility()->get_similar_threads($___, 0, 0, $__________);
		$____________ = $_____________ = 0;
		if ($___________)
			$____________ = $___________->count();
		$______________ = $this->app()->addonManager()->getById('XFRM');
		$_______________ = '';
		if ($______________ && $______________->isActive()) {
			$_______________ = $this->repoUtility()->get_similar_resources($___, 0, 0, $__________);
			if ($_______________) {
				$________________ = round($__________ / 2);
				if ($________________ % 3 != 0)
					$________________ += 3 - ($________________ % 3);
				$_____________ = $_______________->count();
				if ($____________ >= $________________ && $_____________ >= $________________) {
					$___________ = $___________->slice(0, $________________);
					$_______________ = $_______________->slice(0, $________________);
				} else if ($____________ >= $________________) {
					$___________ = $___________->slice(0, min(($__________ - $_____________), $____________));
				} else if ($_____________ >= $________________) {
					$_______________ = $_______________->slice(0, min(($__________ - $____________), $_____________));
				}
			}
		}
		$_________________ = str_ireplace('www.', '', parse_url($________->boardUrl, PHP_URL_HOST));
		$__________________ = \XF::phrase('cnet_content_related_to_keyword', ['keyword' => $___, 'domain' => $_________________]);
		$___________________ = \XF::phrase('cnet_view_content') . ': ' . $___;
		$____________________ = 0;
		$_____________________ = [];
		$______________________ = 1;
		if ($___________) {
			foreach ($___________ as $_______________________) {
				$_____________________[] = [
					"@type" => "ListItem",
					"position" => $______________________++,
					"url" => $this->buildLink('full:threads', $_______________________),
					"name" => $_______________________->title
				];
				if ($_______________________->post_date > $____________________)
					$____________________ = $_______________________->post_date;
			}
		}
		if ($_______________) {
			foreach ($_______________ as $________________________) {
				$_____________________[] = [
					"@type" => "ListItem",
					"position" => $______________________++,
					"url" => $this->buildLink('full:resources', $________________________),
					"name" => $________________________->title
				];
				if ($________________________->resource_date > $____________________)
					$____________________ = $________________________->resource_date;
			}
		}
		if ($____________________ && $____________________ > $______)
			$this->repoUtility()->updateSeoUrlLastmod($_____, $____________________);
		$_________________________ = '';
		if (count($_____________________)) {
			$_________________________ = [
				"@context" => "https://schema.org",
				"@type" => "ItemList",
				"name" => $___________________,
				"description" => $__________________,
				"url" => $_______,
				"numberOfItems" => count($_____________________),
				"itemListOrder" => "https://schema.org/ItemListOrderDescending",
				"itemListElement" => $_____________________
			];
		}
		$_________ = [
			'query' => $___,
			'threads' => $___________,
			'resources' => $_______________,
			'description' => $__________________,
			'title' => $___________________,
			'url' => $_______,
			'ldJson' => $_________________________,
			'lastmod' => $____________________
		];
		return $this->view("CNet\x3a\x43\x6f\x6e\x74\x65\x6e\x74\x73", 'cnet_contents', $_________);
	}
	public static function getActivityDetails(array $_)
	{
		return \XF::phrase('cnet_view_content');
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */