<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
class Search extends XFCP_Search
{
	protected function canUpdateSessionActivity($_, ParameterBag $__, AbstractReply &$___, &$____)
	{
		$_____ = ['updatestatistics', 'updatenotice', 'viewalert', 'imagecaptcha', "cnet\x63\x61\x63\x68\x65", 'scan', 'verifysms'];
		if (in_array(strtolower($_), $_____))
			return false;
		return parent::canUpdateSessionActivity($_, $__, $___, $____);
	}
	public function assertViewingPermissions($_)
	{
		if (in_array(strtolower($_), ['imagecaptcha', 'verifysms']))
			return true;
		return parent::assertViewingPermissions($_);
	}
	public function checkCsrfIfNeeded($_, ParameterBag $__)
	{
		if (in_array(strtolower($_), ['imagecaptcha', 'verifysms']))
			return;
	}
	protected function getGlobalTemplateData()
	{
		return ['visitor' => \XF::visitor(), 'options' => $this->app()->options()];
	}
	protected function searchThreads($_, $__ = 5, $___ = 0, $____ = [])
	{
		$_____ = $this->repoUtility()->get_similar_threads($_, 0, $___, $__, $____);
		$______ = $this->app()->templater();
		$______->addDefaultParam('xf',  $this->getGlobalTemplateData());
		$_______ = false;
		$________ = [];
		$_ = preg_replace('/[\p{P}]/u', ' ', $_);
		if ($_____) {
			foreach ($_____ as $_________) {
				$__________ = $______->fnPrefix($______, $_______, 'thread', $_________->prefix_id, 'html', null);
				$___________ = $______->fnSuffix($______, $_______, $_________->suffix);
				$____________ = $______->fnHighlight($______, $_______, $_________->title, $_, 'textHighlight');
				$________[] = [
					'text' => $__________ . ' ' . $____________ . ' ' . $___________,
					'link' => $this->buildLink('threads', $_________),
					'title' => $______->fnPrefix($______, $_______, 'thread', $_________->prefix_id, 'plain', null) . $_________->title . ($_________->suffix ? ' - ' . $_________->suffix : ''),
					'icon' => '<img src="' . $_________->getIcon() . '">',
					'type' => $_________->Forum->Node->title,
					'desc' => $_________->getDescription(),
					'id' => $_________->thread_id
				];
			}
		}
		return $________;
	}
	protected function searchResources($_, $__ = 5, $___ = 0, $____ = [])
	{
		$_____ = $this->repoUtility()->get_similar_resources($_, 0, $___, $__, $____);
		$______ = $this->app()->templater();
		$______->addDefaultParam('xf',  $this->getGlobalTemplateData());
		$_______ = false;
		$________ = [];
		$_ = preg_replace('/[\p{P}]/u', ' ', $_);
		if ($_____) {
			foreach ($_____ as $_________) {
				$__________ = $_________->CurrentVersion;
				$___________ = ($__________ ? $__________->version_string : '');
				$____________ = $______->fnPrefix($______, $_______, 'resource', $_________->prefix_id, 'html', null);
				$_____________ = $______->fnSuffix($______, $_______, $___________, 2);
				$______________ = $______->fnHighlight($______, $_______, $_________->title, $_, 'textHighlight');
				$________[] = [
					'text' => $____________ . ' ' . $______________ . ' ' . $_____________,
					'link' => $this->buildLink('resources', $_________),
					'title' => $______->fnPrefix($______, $_______, 'resource', $_________->prefix_id, 'plain', null) . $_________->title . ($___________ ? ' - ' . $___________ : ''),
					'icon' => '<img src="' . $_________->getIcon() . '">',
					'type' => $_________->Category->title,
					'desc' => $_________->getDescription(),
					'id' => $_________->resource_id
				];
			}
		}
		return $________;
	}
	protected function sortUnique($_, $__, $___)
	{
		if (!is_array($_) || !is_array($__) || count($__) == 0)
			return $_;
		foreach ($_ as $____ => $_____) {
			foreach ($__ as $______ => $_______) {
				if ($_____['text'] == $_______['text'])
					unset($__[$______]);
			}
		}
		if ($__ && count($__) > 0)
			$_ = array_merge($_, $__);
		$_ = array_slice($_, 0, $___);
		return $_;
	}
	public function actionFind()
	{
		$this->assertValidCsrfToken();
		$this->setResponseType('json');
		if (!\XF::visitor()->canSearch())
			return $this->view("CNet\x3a\x53\x65\x61\x72\x63\x68\x5c\x46\x69\x6e\x64", '', ['results' => '']);
		$_ = $this->app()->options();
		$__ = $___ = false;
		$____ = $_____ = [];
		$______ = $this->app->addonManager()->getById('XFRM');
		if ($______ && $______->isActive())
			$___ = true;
		if ($___)
			$__ = $this->filter('resource', 'int');
		$_______ = trim($this->filter('query', 'str'));
		$________ = $this->filter('nodeid', 'int');
		$_________ = trim($this->filter('name', 'str'));
		$__________ = trim($this->filter('exclude', 'str'));
		$___________ = 0;
		$____________ = false;
		if ($_________ == 'keywords')
			$___________ = $_->cnet_ajax_default_search;
		else if ($_________ == 'cnet_quick_search')
			$___________ = $_->cnet_ajax_quick_search;
		else if ($_________ == 'title')
			$___________ = $_->cnet_ajax_title_search;
		else if ($_________ == 'cnet_search_url') {
			$___________ = max(10, $_->cnet_ajax_default_search, $_->cnet_ajax_quick_search, $_->cnet_ajax_title_search);
			$____________ = true;
		}
		if (!$___________ || strlen($_______) < 3)
			return $this->view("CNet\x3a\x53\x65\x61\x72\x63\x68\x5c\x46\x69\x6e\x64", '', ['results' => '']);
		if (function_exists('mb_substr'))
			$_______ = mb_substr($_______, 0, 150);
		else
			$_______ = substr($_______, 0, 150);
		$_____________ = [];
		if ($__________ && $__________ != '0')
			$_____________ = explode(',', $__________);
		if (!$__) {
			$____ = $this->searchThreads($_______, $___________, $________, $_____________);
			if (!$____________ && $___ && !$________) {
				$______________ = max($___________ - count($____), 0);
				if ($______________) {
					$_____ = $this->searchResources($_______, $______________);
					if ($_____)
						$____ = $this->sortUnique($____, $_____, $___________);
				}
			}
		} else {
			$____ = $this->searchResources($_______, $___________, $________, $_____________);
			if (!$____________ && !$________ && $__ != 2) {
				$______________ = max($___________ - count($____), 0);
				if ($______________) {
					$_____ = $this->searchThreads($_______, $___________);
					if ($_____)
						$____ = $this->sortUnique($____, $_____, $___________);
				}
			}
		}
		$_______________ = $this->view("CNet\x3a\x53\x65\x61\x72\x63\x68\x5c\x46\x69\x6e\x64");
		$_______________->setJsonParams([
			'results' => $____
		]);
		return $_______________;
	}
	public function actionUpdateStatistics()
	{
		$this->assertValidCsrfToken();
		$this->setResponseType('json');
		$_ = $this->app()->options();
		$__ = \XF::visitor();
		$___ = $this->repoUtility();
		$____ = false;
		$_____ = $this->filter('type', 'str');
		$______ = $this->filter('data1', 'int');
		$_______ = $this->filter('data2', 'int');
		if ($_____ == 'forum-last-thread') {
			$____ = $___->getStatistic($_____);
		} else if ($_____ == 'forum-most-view') {
			$____ = $___->getStatistic($_____);
		} else if ($_____ == 'forum-sticky-thread') {
			$____ = $___->getStatistic($_____);
		} else if ($_____ == 'thread-most-view') {
			$________ = $_->cnet_related_statistic;
			if ($______ > 0 && $_______ > 0 && $________) {
				$____ = $this->app()->finder('XF:Thread')
					->where('discussion_state', 'visible')
					->where('discussion_type', '<>', 'redirect')
					->where('view_count', '>', 1)
					->where('thread_id', '<>', $______)
					->where('node_id', '=', $_______)
					->with('Statistic')
					->order('view_count', 'DESC')
					->limit($________ * 3)
					->fetch()
					->filter(function (\XF\Entity\Thread $_________) {
						return ($_________->canView());
					})
					->slice(0, $________);
			}
		} else if ($_____ == 'thread-view-more') {
			$________ = $_->cnet_related_statistic;
			if ($______ > 0 && $_______ > 0 && $________) {
				$____ = $this->app()->finder('XF:Thread')
					->where('discussion_state', 'visible')
					->where('discussion_type', '<>', 'redirect')
					->where('view_count', '>', 1)
					->where('thread_id', '<>', $______)
					->where('node_id', '=', $_______)
					->with('Statistic')
					->order('RAND()')
					->limit($________ * 3)
					->fetch()
					->filter(function (\XF\Entity\Thread $_________) {
						return ($_________->canView());
					})
					->slice(0, $________);
			}
		} else if ($_____ == 'attachments-related') {
			$________ = $_->cnet_related_statistic;
			if ($______ > 0 && $_______ > 0 && $________) {
				$____ = $this->app()->finder('XF:Attachment')
					->where(['attachment_id', '<>', $______])
					->where(['content_type', '=', 'post'])
					->where(['temp_hash', '=', ''])
					->where(['unassociated', '<>', true])
					->where(['content_id', '=', $_______])
					->where(['Data.width', '=', ''])
					->where(['Data.height', '=', ''])
					->limit($________ * 3)
					->fetch()
					->filter(function (\XF\Entity\Attachment $__________) {
						return ($__________->canView());
					})
					->slice(0, $________);
			}
		} else if ($_____ == 'new-resources') {
			$____ = $___->getStatistic($_____);
		} else if ($_____ == 'top-resources') {
			$____ = $___->getStatistic($_____);
		} else if ($_____ == 'resource-most-view') {
			$________ = $_->cnet_related_statistic;
			if ($______ > 0 && $_______ > 0 && $________) {
				$____ = $this->app()->finder('XFRM:ResourceItem')
					->where('resource_state', 'visible')
					->where('view_count', '>', 1)
					->where('resource_id', '<>', $______)
					->where('resource_category_id', '=', $_______)
					->with(['User', 'Category', 'CurrentVersion'])
					->with('Category.Permissions|' . $__->permission_combination_id)
					->order('view_count', 'DESC')
					->limit($________ * 3)
					->fetch()
					->filter(function (\XFRM\Entity\ResourceItem $___________) {
						return ($___________->canView());
					})
					->slice(0, $________);
			}
		} else if ($_____ == 'resource-view-more') {
			$________ = $_->cnet_related_statistic;
			if ($______ > 0 && $_______ > 0 && $________) {
				$____ = $this->app()->finder('XFRM:ResourceItem')
					->where('resource_state', 'visible')
					->where('view_count', '>', 1)
					->where('resource_id', '<>', $______)
					->where('resource_category_id', '=', $_______)
					->with(['User', 'Category', 'CurrentVersion'])
					->with('Category.Permissions|' . $__->permission_combination_id)
					->order('RAND()')
					->limit($________ * 3)
					->fetch()
					->filter(function (\XFRM\Entity\ResourceItem $___________) {
						return ($___________->canView());
					})
					->slice(0, $________);
			}
		} else if ($_____ == 'version-resource') {
			if ($______ > 0 && $_______ > 0 && $_->cnet_related_statistic) {
				$____ = $this->app()->finder('XFRM:ResourceVersion')
					->where(['resource_id', '=', $______])
					->where(['resource_version_id', '<>', $_______])
					->where(['version_state', '<>', 'deleted'])
					->where(['file_count', '>', 0])
					->fetch();
			}
		} else if ($_____ == 'top-attachments') {
			$____ = $___->getStatistic($_____);
		} else if ($_____ == 'new-members') {
			$____ = $___->getStatistic($_____);
		}
		if ($____ && count($____) > 0) {
			$____________ = $this->app()->templater();
			$_____________ = $__->style_id ?: $_->defaultStyleId;
			$______________ = $this->app()->style($_____________);
			$____________->setStyle($______________);
			$____________->addDefaultParam('xf', $this->getGlobalTemplateData());
			if (strpos($_____, 'attachment') !== false)
				$_______________ = $____________->renderMacro('public:cnet_macros', 'attachmentlist', ['attachments' => $____]);
			else if ($_____ == "version-resource")
				$_______________ = $____________->renderMacro('public:cnet_macros', 'versionlist', ['versions' => $____]);
			else if (strpos($_____, 'resource') !== false)
				$_______________ = $____________->renderMacro('public:cnet_macros', 'resourcelist', ['resources' => $____]);
			else if ((strpos($_____, 'forum') !== false) || (strpos($_____, 'thread') !== false))
				$_______________ = $____________->renderMacro('public:cnet_macros', 'datalist', ['threads' => $____]);
			else if (strpos($_____, 'member') !== false)
				$_______________ = $____________->renderMacro('public:cnet_macros', 'userlist', ['users' => $____]);
			else
				$_______________ = '<div class="block-row u-muted">' . \XF::phrase('there_is_nothing_to_display') . '</div>';
		} else
			$_______________ = '<div class="block-row u-muted">' . \XF::phrase('there_is_nothing_to_display') . '</div>';
		$________________ = $this->view();
		$________________->setJsonParams([
			'results' => $_______________,
			'type' => $_____
		]);
		return $________________;
	}
	protected function findAlertsForUser()
	{
		$_ = \XF::visitor();
		$__ = $_->user_id;
		$___ = $this->app()->finder('XF:UserAlert');
		$____ = $___->where('alerted_user_id', $__)
			->where(['view_date', '=', 0])
			->order('event_date', 'desc')
			->with('User')
			->limit(5)
			->fetch();
		$_____ = $this->repository('XF:UserAlert');
		$_____->addContentToAlerts($____);
		$____ = $____->filterViewable();
		$______ = [];
		foreach ($____ as $_______) {
			$________ = preg_replace('/\s(dir|data-\S+)=\".*?\"/i', '', $_______->render());
			$______[] = ['html' => trim($________), 'time' => $_______->event_date, 'id' => 'alert-' . $_______->alert_id];
		}
		$___ = $this->app()->finder('XF:ConversationUser');
		$____ = $___->forUser($_, true)
			->setDefaultOrder('last_message_date', 'desc')
			->where('is_unread', 1)
			->limit(5)
			->fetch();
		$_________ = $____->toArray();
		$__________ = [];
		foreach ($_________ as $___________) {
			$____________ = '<a href="' . $this->buildLink('conversations/unread', $___________) . '">' . $___________->Master->title . '</a>';
			$_____________ = '<a href="' . $this->buildLink('members', $___________->Master->Starter) . '">' . $___________->Master->username . '</a>';
			foreach ($___________->Master->recipients as $______________) {
				if ($______________['user_id'] && $______________['user_id'] != $___________->Master->user_id)
					$_____________ .= ', ' . '<a href="' . $this->buildLink('members', $______________) . '">' . $______________['username'] . '</a>';
			}
			$__________[] = ['html' => html_entity_decode(\XF::phrase('cnet_you_have_received_a_new_conversation_x', ['title' => $____________, 'user' => $_____________])), 'time' => $___________->last_message_date, 'id' => 'cons-' . $___________->conversation_id];
		}
		$____ = array_merge($______, $__________);
		usort($____, fn($_______________, $________________) => $________________['time'] <=> $_______________['time']);
		$____ = array_slice($____, 0, 5);
		$____ = array_reverse($____);
		return $____;
	}
	public function actionUpdateNotice()
	{
		$this->setResponseType('json');
		$this->assertValidCsrfToken();
		if (!\XF::visitor()->user_id)
			return $this->noPermission();
		$_ = false;
		if ($this->app()->options()->cnet_snackbar)
			$_ = $this->findAlertsForUser();
		$__ = $this->view();
		$__->setJsonParams([
			'alerts' => $_,
			'time' => \XF::$time
		]);
		return $__;
	}
	public function actionViewAlert()
	{
		$this->setResponseType('json');
		$this->assertValidCsrfToken();
		$_ = \XF::visitor();
		$__ = $this->filter('ids', 'str');
		if ($_->user_id && $__) {
			$___ = [];
			$__ = explode('_', $__);
			foreach ($__ as $____) {
				if (is_numeric($____))
					$___[] = ['alert_id', '=', $____];
			}
			if (count($___)) {
				$_____ = $this->app()->finder('XF:UserAlert')->whereOr($___)->fetch();
				if ($_____ && count($_____)) {
					$______ = $this->repository('XF:UserAlert');
					foreach ($_____ as $_______) {
						$______->markUserAlertRead($_______);
					}
				}
			}
		}
		$________ = $this->view();
		return $________;
	}
	public function actionCNetCache()
	{
		$this->setResponseType('json');
		if (!\XF::visitor()->is_admin)
			return $this->noPermission();
		$_ = $this->app;
		$__ = $_->registry()->get("cnet\x43\x61\x63\x68\x65");
		if (!$__)
			$__ = [];
		$___ = $this->view();
		$___->setJsonParams([
			$__
		]);
		return $___;
	}
	public function actionImageCaptcha()
	{
		$this->assertValidCsrfToken();
		$_ = $this->repoUtility();
		if ($this->filter('get-url', 'int')) {
			$this->setResponseType('json');
			$__ = $this->view();
			$__->setJsonParams(
				$_->getImageCaptchaData()
			);
			return $__;
		}
		$___ = $this->filter('data', 'str');
		$___ = $_->decryptKey($___);
		if ($___)
			$___ = explode('|', $___);
		$____ = 60;
		$_____ = 600;
		$______ = imagecreatetruecolor($_____, $____);
		imagealphablending($______, false);
		imagesavealpha($______, true);
		$_______ = imagecolorallocatealpha($______, 0, 0, 0, 127);
		imagefill($______, 0, 0, $_______);
		imagealphablending($______, true);
		$________ = str_replace('\\', '/', \XF::getRootDirectory());
		$_________ = $________ . "\x2f\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x53\x65\x72\x76\x69\x63\x65\x2f\x44\x65\x66\x69\x6e\x69\x74\x69\x6f\x6e\x73\x2f\x66\x6f\x6e\x74\x2e\x74\x74\x66";
		$__________ = false;
		if (is_array($___) && count($___) == 3) {
			$___________ = $___[0];
			$____________ = $___[1];
			$_____________ = $___[2];
			if ($___________ && $_____________) {
				$______________ = \XF::$time;
				if (strlen($___________) == 9 &&  $____________ == \XF::visitor()->user_id && $_____________ >= ($______________ - 120) && $_____________ <= $______________) {
					$_______________ = round($____ / 1.5);
					$________________ = round($_______________ / 20);
					$_________________ = imagecolorallocatealpha($______, 250, 250, 250, 20);
					$__________________ = round($____ / 1.2);
					for ($___________________ = 0; $___________________ < 9; $___________________++) {
						$____________________ = round(rand(10, 200), -1);
						$_____________________ = round(rand(10, 200), -1);
						$______________________ = round(rand(10, 200), -1);
						$_______________________ = round($____ / 2) + (($____ + 3) * $___________________);
						$________________________ = rand(-30, 30);
						$_________________________ = imagecolorallocate($______, $____________________, $_____________________, $______________________);
						imagettftext($______, $_______________, $________________________, $_______________________ - $________________, $__________________ - $________________,  $_________________, $_________, $___________[$___________________]);
						imagettftext($______, $_______________, $________________________, $_______________________ + $________________, $__________________ + $________________,  $_________________, $_________, $___________[$___________________]);
						imagettftext($______, $_______________, $________________________, $_______________________ + $________________, $__________________ - $________________,  $_________________, $_________, $___________[$___________________]);
						imagettftext($______, $_______________, $________________________, $_______________________ - $________________, $__________________ + $________________,  $_________________, $_________, $___________[$___________________]);
						imagettftext($______, $_______________, $________________________, $_______________________, $__________________,  $_________________________, $_________, $___________[$___________________]);
					}
					for ($___________________ = 1; $___________________ <= 10; $___________________++) {
						$__________________________ = rand(1, round($_____ / 3));
						$___________________________ = rand(1, $____);
						$____________________________ = rand(round($_____ / 2), $_____);
						$_____________________________ = rand(1, $____);
						$____________________ = round(rand(10, 250), -1);
						$_____________________ = round(rand(10, 250), -1);
						$______________________ = round(rand(10, 250), -1);
						$_________________________ = imagecolorallocate($______, $____________________, $_____________________, $______________________);
						for ($______________________________ = 0; $______________________________ < $________________; $______________________________++) {
							imageline($______, $__________________________, $___________________________ + $______________________________, $____________________________, $_____________________________ + $______________________________, $_________________________);
						}
					}
					$__________ = true;
				}
			}
		}
		if (!$__________) {
			$_______________ = round($____ / 1.6);
			$_______________________ = round($____ / 3);
			$__________________ = round($____ / 1.2);
			$_________________________ = imagecolorallocate($______, 100, 100, 100);
			imagettftext($______, $_______________, 0, $_______________________, $__________________,  $_________________________, $_________, 'ERROR / FLOOD / BOT');
		}
		$this->setResponseType('raw');
		return $this->view("CNet\x3a\x52\x61\x77", '', ['image' => $______, 'fileName' => 'image-captcha.png']);
	}
	public function actionScan()
	{
		$this->setResponseType('json');
		$this->assertValidCsrfToken();
		$_ = $this->filter('id', 'int');
		if (!$this->app()->options()->cnet_malware_scanner || !$_)
			return $this->noPermission();
		$__ = $this->em()->find('XF:Attachment', $_);
		if (!$__)
			return $this->notFound();
		if (!$__->canView())
			return $this->noPermission();
		$___ = [];
		if ($__) {
			$____ = $__->scan;
			if ($____ == 'clean')
				$____ = '<b>' . \XF::phrase('results') . '</b>: <span class="cnet-scan cnet-file">' . \XF::phrase('clean') . '</span>';
			else if (!$____)
				$____ = '<b>' . \XF::phrase('results') . '</b>: <span class="cnet-scan cnet-detect">' . \XF::phrase('unknown') . '</span>';
			else {
				$____ = unserialize($____);
				$____ = \XF::phrase('cnet_scan_result_x', $____);
				$____ = preg_replace('/' . $__->data_id . '-[a-z0-9]+\.data/', $__->filename, $____);
			}
			$___ = [
				'result' => $____,
				'filename' => $__->filename
			];
		}
		$_____ = $this->view();
		$_____->setJsonParams($___);
		return $_____;
	}
	public function actionVerifySMS()
	{
		$this->setResponseType('json');
		$_ = \XF::visitor();
		$__ = $this->app()->options();
		if (!$__->cnet_sms_verify)
			return $this->noPermission();
		$___ = \XF::$time;
		$____ = $__->cnet_sms_key;
		$_____ = 'empty';
		$______ = trim($this->filter('check', 'str'));
		if ($______) {
			$this->assertValidCsrfToken();
			if (!$_->user_id)
				return $this->noPermission();
			$_______ = $_->phone;
			if ($_______ && preg_match('/^\+[0-9]{7,15}$/', $_______))
				$_____ = 'ok';
		} else {
			$________ = trim($this->filter('text', 'str'));
			$_______ = trim($this->filter('phone', 'str'));
			if ($________ && $_______) {
				$_________ = $this->repoUtility();
				if ($____) {
					$__________ = $_________->processKey(md5($____));
					$________ = $_________->decryptKey($________, $__________);
					$_______ = $_________->decryptKey($_______, $__________);
				}
				if ($________ && $_______ && preg_match('/^\+[0-9]{7,15}$/', $_______)) {
					$___________ = explode(' ', $________);
					if (count($___________) == 3) {
						$____________ = $___________[0] ?? '';
						$_____________ = intval($___________[1]) ?? 0;
						$______________ = intval($___________[2]) ?? 0;
					} else {
						$____________ = $___________[0] ?? '';
						$_______________ = intval($___________[1]) ?? '';
						if ($_______________ == $_________->getCache('cnetSMSId')) {
							$_____________ = intval($___________[2]) ?? 0;
							$______________ = intval($___________[3]) ?? 0;
						} else
							$_____________ = $______________ = 0;
					}
					if ($____________ && $_____________ && $______________) {
						$____________ = strtolower($____________);
						if ($____________ == "\x61\x63\x74\x69\x76\x65") {
							$________________ = $this->finder('XF:User')->where('user_id', $_____________)->fetchOne();
							if ($________________) {
								$_________________ = $________________->phone;
								if ($_________________ && !preg_match('/^\+[0-9]{7,15}$/', $_________________)) {
									$___________ = explode('|', $_________________);
									$__________________ = $___________[0] ?? '';
									$___________________ = intval($___________[1]) ?? 0;
									if (!$__________________ || !$___________________ || $___________________ < ($___ - 900)) {
										$________________->set('phone', '', ['forceSet' => true]);
										$________________->save(true, false);
										$_____ = 'expired';
									} else {
										if ($______________ == $__________________) {
											$________________->set('phone', $_______, ['forceSet' => true]);
											$________________->save(true, false);
											$_____ = 'ok';
											$____________________ = (array) $__->cnet_sms_groups;
											if ($____________________ && count($____________________)) {
												$_____________________ = $this->service('XF:User\UserGroupChange');
												$_____________________->addUserGroupChange(
													$________________->user_id,
													'userPhone-' . $________________->user_id,
													$____________________
												);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		$______________________ = $this->view();
		$______________________->setJsonParams([
			'result' => $_____
		]);
		return $______________________;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */