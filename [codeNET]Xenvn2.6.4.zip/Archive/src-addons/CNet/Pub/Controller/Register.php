<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
class Register extends XFCP_Register
{
	protected function limitIPs()
	{
		$_ = @inet_pton($this->app->request()->getIp());
		if (!$_)
			return true;
		$__ = $this->finder('XF:Ip')
			->where('ip', '=', $_)
			->where('log_date', '>=', \XF::$time - 86400)
			->where('log_date', '<=', \XF::$time)
			->fetch();
		$___ = [];
		foreach ($__ as $____) {
			if ($____->user_id) {
				if ($____->action == 'register')
					$___[$____->user_id] =  1;
				else
					unset($___[$____->user_id]);
			}
		}
		if (count($___) > 3)
			return true;
		return false;
	}
	public function actionRegister()
	{
		$this->assertPostOnly();
		$this->assertRegistrationActive();
		$_ = $this->app()->options()->cnet_login_security ?? false;
		if ($_) {
			$__ = $this->getDynamicRedirectIfNot($this->buildLink('index'));
			if ($this->filter('keeplogin', 'bool'))
				return $this->redirect($__);
			if ($this->limitIPs())
				return $this->error(\XF::phrase('cnet_your_ip_address_has_reached_the_new_registration_limit_within_24_hours'));
		}
		return parent::actionRegister();
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */