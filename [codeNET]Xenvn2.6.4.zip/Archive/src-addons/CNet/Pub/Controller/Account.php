<?php
/* Developed by CNet Tools */
namespace CNet\Pub\Controller;
use XF\Mvc\ParameterBag;
class Account extends XFCP_Account
{
	protected function preDispatchController($_, ParameterBag $__)
	{
		$___ = $this->app()->options()->cnet_demo_user;
		if ($___) {
			$____ = explode(',', $___);
			$_____ = $this->app()->request()->getRoutePath();
			$______ = ['account/visitor-menu', 'account/bookmarks-popup', 'account/alerts-popup', 'account/phone'];
			if ($____ && in_array(\XF::visitor()->user_id, $____) && !in_array($_____, $______)) {
				throw $this->exception(
					$this->plugin('XF:Error')->actionNoPermission(\XF::phrase('do_not_have_permission') . " ($_____)")
				);
			}
		}
		return parent::preDispatchController($_, $__);
	}
	public function actionPhone()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_sms_verify)
			return $this->noPermission();
		$__ = \XF::$time;
		$___ = \XF::visitor();
		$____ = $___->user_id;
		$_____ = $___->phone;
		if ($this->isPost()) {
			$this->assertValidCsrfToken();
			if (!$_____ && $this->filter('enable', 'str')) {
				$______ = rand(1000, 9999) . '|' . $__;
				$___->set('phone', $______, ['forceSet' => true]);
			} else if ($this->filter('delete', 'str')) {
				$___->set('phone', '', ['forceSet' => true]);
				$_______ = (array) $_->cnet_sms_groups;
				if ($_______ && count($_______)) {
					$________ = $this->service('XF:User\UserGroupChange');
					$________->removeUserGroupChange(
						$___->user_id,
						'userPhone-' . $___->user_id
					);
				}
			}
			$___->save(true, false);
			return $this->redirect($this->buildLink('account/phone'));
		}
		$_________ = $_->cnet_sms_phone;
		$______ = '';
		$__________ = 0;
		$___________ = 120;
		if ($_____ && !preg_match('/^\+[0-9]{7,15}$/', $_____) && $_________ && preg_match('/^\+[0-9]{7,15}$/', $_________)) {
			$____________ = explode('|', $_____);
			$______ = $____________[0] ?? '';
			$_____________ = intval($____________[1]) ?? 0;
			$__________ = $___________ - ($__ - $_____________);
			if (!$______ || !$_____________ || $_____________ < ($__ - $___________) || $_____________ > ($__ + 10)) {
				$___->set('phone', '', ['forceSet' => true]);
				$___->save(true, false);
				$_____ = $______ = '';
			} else {
				if ($_->cnet_sms_server == 'self')
					$______ = "ACTIVE $____ $______";
				else if ($_->cnet_sms_server == 'cnettools') {
					$______________ = $this->repoUtility()->getCache('cnetSMSId');
					if ($______________ && $______________ > 0)
						$______ = "ACTIVE $______________ $____ $______";
					else
						$______ = '';
				}
				$_____ = '';
			}
		}
		$_______________ = [
			'phone' => $_____,
			'server' => $_________,
			'text' => $______,
			'timer' => $__________
		];
		$________________ = $this->view('XF:Account\Phone', 'cnet_account_phone', $_______________);
		return $this->addAccountWrapperParams($________________, 'cnet_account_phone');
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */