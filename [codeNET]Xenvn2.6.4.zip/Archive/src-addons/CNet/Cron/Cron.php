<?php
/* Developed by CNet Tools */
namespace CNet\Cron;
class Cron
{
	public static function run()
	{
		$_ = \XF::$time;
		$__ = intval(date('i', $_));
		$___ = intval(date('G', $_));
		$____ = \XF::options();
		$_____ = \XF::app();
		$______ = $_____->jobManager();
		$_______ = intval(strlen($____->boardUrl) % 24);
		$________ = self::repoUtility();
		if (in_array($__, [0, 1, 14, 15, 16, 29, 30, 31, 44, 45, 46, 59])) {
			if ($____->cnet_external_storage) {
				$_________ = $____->cnet_external_storage_cron;
				if ($_________) {
					$_________ = (($_________ == 2) ? 'Restore' : 0);
					$______->enqueueUnique(
						'cnetMoveToExternalStorage',
						"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x45\x78\x74\x65\x72\x6e\x61\x6c\x53\x74\x6f\x72\x61\x67\x65",
						['cron' => 1, 'query' => $_________],
						false
					);
				}
			}
			return;
		}
		if ($___ == $_______ && in_array($__, [4, 5, 6])) {
			$__________ = $_____->service("CNet\x3a\x48\x65\x61\x6c\x74\x68");
			$__________->fileCheck();
			$________->cleanCache();
			if ($____->cnet_limit_download) {
				$___________ = $_____->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
				$___________->cleanLimit();
			}
			return;
		}
		if ($___ == $_______ && in_array($__, [9, 10, 11])) {
			if ($____->cnet_seo_keywords) {
				$____________ = $________->getCache("cnet\x4b\x65\x79\x77\x6f\x72\x64\x73");
				if (!$____________ || !is_array($____________) || !count($____________)) {
					$_____->jobManager()->enqueueUnique(
						'cnetRebuildKeywords',
						"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
						['job_type' => 'rebuild_keywords'],
						false
					);
				}
			}
			if ($____->cnet_sms_verify && $____->cnet_sms_server == 'cnettools') {
				$_____________ = self::repoUtility()->getCache('cnetSMSId');
				if ($_____________ === false) {
					\XF::app()->jobManager()->enqueueUnique(
						'cnetCheckSMS',
						"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
						['job_type' => 'process_sms'],
						false
					);
				}
			}
			return;
		}
		if ($___ == $_______ && in_array($__, [19, 20, 21])) {
			if ($____->cnet_external_storage)
				$________->cleanPartExternalStorage();
			return;
		}
		if ($___ == $_______ && in_array($__, [24, 25, 26])) {
			if ($____->cnet_auto_delete_users)
				$________->deleteUsers();
			return;
		}
		if ($___ == $_______ && in_array($__, [34, 35, 36])) {
			if ($____->cnet_auto_delete_hidden_content)
				$________->deleteHiddenPosts();
			return;
		}
		if ($___ == $_______ && in_array($__, [39, 40, 41])) {
			$______________ = $_____->addonManager()->getById('XFRM');
			if ($______________ && $______________->isActive()) {
				if ($____->cnet_auto_delete_hidden_content)
					$________->deleteHiddenResources();
			}
			return;
		}
		if ($___ == $_______ && in_array($__, [49, 50, 51])) {
			$________->checkFiles();
			return;
		}
	}
	protected static function repoUtility()
	{
		return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */