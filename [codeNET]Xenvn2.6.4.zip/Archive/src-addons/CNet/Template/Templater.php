<?php
/* Developed by CNet Tools */
namespace CNet\Template;
use XF\App;
use XF\Language;
use XF\Mvc\Entity\Entity;
class Templater extends XFCP_Templater
{
	protected $_ = [];
	protected $__ = [];
	protected $___ = '';
	public function __construct(App $____, Language $_____, $______)
	{
		parent::__construct($____, $_____, $______);
		$this->defaultFunctions['copyright'] = 'fnCNetCopyright';
		$this->defaultFunctions['suffix'] = 'fnSuffix';
		$this->defaultFunctions['textlimit'] = 'fnTextLimit';
		$this->defaultFunctions['blockads'] = 'fnBlockAds';
		$this->defaultFunctions['blockcnet'] = 'fnBlockCNet';
		$this->defaultFunctions['favicon'] = 'fnFavicon';
		$this->defaultParams["CNet"] = 1;
		$this->defaultParams["cnet\x43\x61\x63\x68\x65"] = $this->repoUtility()->getCache();
	}
	public function callAdsMacro($____, array $_____, array $______)
	{
		$_______ = parent::callAdsMacro($____, $_____, $______);
		$________ = $this->getTemplateData('public', 'cnet_ads', false);
		if (!isset($________['macros'][$____]))
			return $_______;
		else
			return $_______ . $this->callMacro('public:cnet_ads', $____, $_____, $______);
	}
	public function renderUnfurl(\XF\Entity\UnfurlResult $____, array $_____ = [])
	{
		$______ = $____->url;
		$_______ = '';
		$________ = $this->repoUtility()->buildRedirectUrl($______, $_____);
		if ($________) {
			$_________ = $this->app->options()->boardUrl;
			[$______, $_______] = $________;
			$____->url = $______;
			$__________ = $____->title;
			if (!empty($__________) && preg_match('/^((https?:\/\/|www\.)\S+\.|\d+\.\d+\.\d+\.\d+)\S+.*/i', $__________)) {
				if (stripos($__________, 'http://') === false && stripos($__________, 'https://') === false)
					$__________ = 'https://' . $__________;
				$____->title = parse_url($__________, PHP_URL_HOST);
			} else if (stripos($______, $_________) === 0)
				$____->title = preg_replace('/^https?:\/\//i', '', $______);
			else
				$____->title = parse_url($______, PHP_URL_HOST);
			$_____['noProxy'] = true;
		}
		$___________ = parent::renderUnfurl($____, $_____);
		if ($_______) {
			$____________ = $this->fontAwesome('fa-globe', ['title' => $_______, 'class' => 'cnet-lang-icon']);
			$___________ = preg_replace('/<[^>]+js-unfurl-title[^>]+>/isU',  '$0 ' . $____________, $___________);
		}
		return $___________;
	}
	public function fnAvatar($____, &$_____, $______, $_______, $________ = false, $_________ = [])
	{
		$__________ = parent::fnAvatar($____, $_____, $______, $_______, $________, $_________);
		$___________ = $this->app->options()->cnet_avatar_circle_year ?? 0;
		if ($___________ && $______ instanceof \XF\Entity\User) {
			$_______ = preg_replace('#[^a-zA-Z0-9_-]#s', '', $_______);
			if ($_______ == 'm' || $_______ == 'l') {
				$____________ = $______->getYearOfJoining();
				$_____________ = ' cnet_year';
				if ($____________ < $___________)
					$_____________ .= '';
				else if ($____________ < $___________ * 2)
					$_____________ .= ' cnet_y1';
				else if ($____________ < $___________ * 3)
					$_____________ .= ' cnet_y2';
				else if ($____________ < $___________ * 4)
					$_____________ .= ' cnet_y3';
				else if ($____________ >= $___________ * 4)
					$_____________ .= ' cnet_y4';
				$__________ = str_replace("avatar--{$_______}", "avatar--{$_______}{$_____________}", $__________);
			}
		}
		return $__________;
	}
	public function fnUsernameLink($____, &$_____, $______, $_______ = false, $________ = [])
	{
		if ($this->app instanceof \XF\Admin\App || !($______ instanceof \XF\Entity\User))
			return parent::fnUsernameLink($____, $_____, $______, $_______, $________);
		return $this->fnUsernameIcon($____, $_____, $______, $_______, $________);
	}
	public function fnUsernameIcon($____, &$_____, $______, $_______ = false, $________ = [])
	{
		$_________ = $______->user_id;
		if ($_________ && !isset($this->_[$_________])) {
			$__________ = $___________ = $____________ = '';
			$_____________ = $this->app->options()->cnet_group_icon ?? [];
			$______________ = $______->secondary_group_ids;
			$______________[] = $______->user_group_id;
			$_______________ = 0;
			foreach ($_____________ as $________________ => $_________________) {
				if (isset($_________________['icon']) && in_array($________________, $______________)) {
					$__________ = $_________________['icon'];
					$____________ = $_________________['color'];
					$_______________ = $________________;
					break;
				}
			}
			if ($__________) {
				$___________ = ($_______________ && $____________ ? ' cnet-g g-color-' . $_______________ : '');
				$__________ = $this->fontAwesome($__________, ['class' => 'group-icon']);
				$this->_[$_________] = ['class' => $___________, 'icon' => $__________];
			}
		} else {
			$___________ = $this->_[$_________]['class'] ?? '';
			$__________ = $this->_[$_________]['icon'] ?? '';
		}
		if ($___________) {
			if (isset($________['class']))
				$________['class'] .= $___________;
			else
				$________['class'] = $___________;
		}
		$__________________ = parent::fnUsernameLink($____, $_____, $______, $_______, $________);
		if ($__________)
			$__________________ = preg_replace('/((\<\/\w+\>)+)$/',  "$__________$1", $__________________);
		return $__________________;
	}
	public function fnUserBanners($____, &$_____, $______, $_______ = [])
	{
		$________ = parent::fnUserBanners($____, $_____, $______, $_______);
		$_________ = $this->app->options()->cnet_user_reputation_banner ?? 0;
		if (!$_________ || !($______ instanceof \XF\Entity\User))
			return $________;
		$__________ = 'em';
		if (!empty($_______['tag']))
			$__________ = htmlspecialchars($_______['tag']);
		$___________ = $this->processAttributeToRaw($_______, 'class', ' %s', true);
		$____________ = $______->reaction_score;
		$_____________ = $______->question_solution_count;
		$______________ = $______->message_count;
		$_______________ = $______->trophy_points;
		$________________ = $______->xfrm_resource_count ?? 0;
		$_________________ = ($____________ + $_____________ + $______________ + $_______________ + $________________);
		$__________________ = round($_________________ * 100 / $_________);
		$__________________ = min($__________________, 100);
		if ($__________________ <= 0)
			return $________;
		$__________________ .= '%';
		$___________________ = \XF::phrase('cnet_reputation_x', ['percent' => $__________________]);
		$____________________ = \XF::phrase('cnet_reputation_x_score_x', ['percent' => $__________________, 'score' => $_________________]);
		$_____________________ = "\n<$__________ class=\"userBanner userBanner--primary userBanner--reputation $___________\" data-xf-init=\"tooltip\" title=\"$____________________\" style=\"--cnet-percent-var: $__________________;\" data-text=\"$___________________\"><span class=\"userBanner-before\"></span><strong>$___________________</strong><span class=\"userBanner-after\"></span></$__________>";
		return trim($________ . $_____________________);
	}
	public function fnBlockCNet($____, &$_____)
	{
		$_____ = false;
		return $this->repoUtility()->checkURL();
	}
	protected function getCopyright()
	{
		$____ = $this->app->options();
		$_____ = false;
		$______ = $____->cnet_remove_footer_copyright ?? false;
		$_______ = $this->app instanceof \XF\Admin\App;
		if ($______)
			return '';
		$________ = (($_______ && \XF::$versionId >= 2020570) ? \XF::getCopyrightHtmlAcp() : \XF::getCopyrightHtml());
		if (!$_______ && $_____)
			$________ .= "\n" . "\x3c\x64\x69\x76\x20\x69\x64\x3d\x22cnet\x2d\x63\x6f\x70\x79\x72\x69\x67\x68\x74\x22\x3e\x44\x65\x76\x65\x6c\x6f\x70\x65\x64\x20\x77\x69\x74\x68\x20\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x68\x74\x74\x70\x73\x3a\x2f\x2fcnettools\x2e\x63\x6f\x6d\x22\x20\x74\x69\x74\x6c\x65\x3d\x22CNet\x2e\x43\x6f\x6d\x22\x20\x74\x61\x72\x67\x65\x74\x3d\x22\x5f\x62\x6c\x61\x6e\x6b\x22\x20\x63\x6c\x61\x73\x73\x3d\x22\x75\x2d\x63\x6f\x6e\x63\x65\x61\x6c\x65\x64\x22\x20\x72\x65\x6c\x3d\x22\x73\x70\x6f\x6e\x73\x6f\x72\x65\x64\x20\x6e\x6f\x6f\x70\x65\x6e\x65\x72\x22\x3eCNet\x2e\x43\x6f\x6d\x3c\x2f\x61\x3e\x20\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x63\x6f\x70\x79\x72\x69\x67\x68\x74\x22\x3e\xc2\xa9\x20" . date('Y', \XF::$time) . '</span></div>';
		return $________;
	}
	public function fnCopyright($____, &$_____)
	{
		$_____ = false;
		return $this->getCopyright();
	}
	public function fnCNetCopyright($____, &$_____)
	{
		$_____ = false;
		return $this->getCopyright();
	}
	public function fnSuffix($____, &$_____, $______, $_______ = 0)
	{
		$_____ = false;
		if (($this->app->options()->cnet_thread_suffix || $_______ == 2) && $______) {
			if ($_______ == 1)
				return ' - ' . $______;
			return '&nbsp;<span class="label-suffix">' . $______ . '</span>';
		}
		return '';
	}
	public function fnTextLimit($____, &$_____, $______, $_______ = 0)
	{
		$_____ = false;
		if ($this->app->options()->cnet_limit_download && $______ instanceof Entity) {
			if (!$_______)
				return $______->getTextLimit();
			else
				return $______->getMessageLimit();
		}
		return '';
	}
	public function fnBlockAds($____, &$_____, $______, $_______, $________ = 0, $_________ = '')
	{
		$_____ = false;
		$__________ = $this->app->options()->$______ ?? '';
		$___________ = false;
		if ($__________) {
			$____________ = \XF::visitor();
			if ($_______ == 'forum') {
				if ($________ && !$____________->hasNodePermission($________, 'disable_forum_ad'))
					$___________ = true;
				else if (!$________ && !$____________->hasPermission('forum', 'disable_forum_ad'))
					$___________ = true;
			} else if ($_______ == 'resource') {
				if ($________ && !$____________->hasResourceCategoryPermission($________, 'disable_resource_ad'))
					$___________ = true;
				else if (!$________ && !$____________->hasPermission('resource', 'disable_resource_ad'))
					$___________ = true;
			} else if ($_______)
				$___________ = true;
			if ($___________) {
				$__________ = '<div class="ad_block">' . $__________ . '</div>';
				if ($_________)
					$__________ = '<div class="' . $_________ . '">' . $__________ . '</div>';
				return $__________;
			}
		}
		return '';
	}
	public function fnBbCode($____, &$_____, $______, $_______, $________, array $_________ = [], $__________ = 'html')
	{
		$_____ = false;
		$___________ = parent::fnBbCode($____, $_____, $______, $_______, $________, $_________, $__________);
		if ($this->app->options()->cnet_seo_keywords && ($_______ == 'post' || $_______ == 'resource_update')) {
			$____________ = $this->repoUtility()->getCache("cnet\x4b\x65\x79\x77\x6f\x72\x64\x73");
			if (!$____________ || !is_array($____________) || !count($____________))
				return $___________;
			return $this->repoUtility()->autoSeoLinks($___________, $____________, $this->__);
		}
		return $___________;
	}
	public function fnFavicon($____, &$_____, $______)
	{
		$_____ = false;
		if (!$______)
			return '';
		if ($this->___)
			return $this->___;
		$_______ = strtolower(substr(strrchr($______, '.'), 1));
		$________ = '';
		switch ($_______) {
			case 'ico':
				$________ = 'image/x-icon';
				break;
			case 'png':
				$________ = 'image/png';
				break;
			case 'svg':
				$________ = 'image/svg+xml';
				break;
			default:
				break;
		}
		$this->___ = '<link rel="icon" type="' . $________ . '" href="' . $______ . '" sizes="48x48" />';
		return $this->___;
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */