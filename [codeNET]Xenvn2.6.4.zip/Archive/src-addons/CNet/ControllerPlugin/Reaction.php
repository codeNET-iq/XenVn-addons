<?php
/* Developed by CNet Tools */
namespace CNet\ControllerPlugin;
use XF\Mvc\Entity\Entity;
class Reaction extends XFCP_Reaction
{
	public function actionToggleReaction(Entity $_, $__, $___)
	{
		$____ = $this->app->options();
		if ($____->cnet_limit_download && $____->cnet_force_like != 'disable') {
			$_____ = $_->getEntityContentType();
			$______ = false;
			if ($_____ == 'resource_update')
				$______ = $_->Resource->resource_category_id;
			else if ($_____ == 'post')
				$______ = $_->Thread->node_id;
			if ($______ && $this->repoUtility()->isLimitCategory($______, $_____)) {
				$_______ = \XF::visitor();
				if (($_____ == 'post' && !$_______->hasNodePermission($______, 'cnet_bypass_like_view')) || ($_____ == 'resource_update' && !$_______->hasResourceCategoryPermission($______, 'cnet_bypass_like_view'))) {
					$________ = $this->validateReactionAction($_);
					$_________ = $this->getReactionRepo()->getReactionByContentAndReactionUser($_____, $_->getEntityId(), $_______->user_id);
					if ($_________ && $_________->reaction_id == $________->reaction_id)
						return $this->error(\XF::phrase('cnet_you_cannot_remove_reactions_to_this_content'));
					$__________ = $_->message;
					if ($____->cnet_force_like == 'all' && $__________ && preg_match('/\[code[^\]]*\].+\[\/code\]/is', $__________)) {
						$___________ = parent::actionToggleReaction($_, $__, $___);
						$this->app->templater()->addDefaultParam('xf',  ['visitor' => $_______, 'options' => $____]);
						$____________ = $this->app->bbCode()->render($__________, 'html', $_____, $_, []);
						$___________->setJsonParam('message', $____________);
						return $___________;
					}
				}
			}
		}
		return parent::actionToggleReaction($_, $__, $___);
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */