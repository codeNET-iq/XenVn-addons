<?php
/* Developed by CNet Tools */
namespace CNet\Str;
class Formatter extends XFCP_Formatter
{
	protected function stripCode($_)
	{
		$__ = \XF::app()->options();
		if ($__->cnet_add_redirect_page || $__->cnet_limit_download)
			$_ = preg_replace('/\s*\[url[^\]]*\].*?\[\/url\]\s*/is', '', $_);
		if ($__->cnet_limit_download && $__->cnet_force_like == 'all')
			$_ = preg_replace('/\s*\[code(?:=[^\]]+)?\].*?\[\/code\]\s*/is', '', $_);
		return $_;
	}
	protected function stripCodeForQuote($_)
	{
		$__ = \XF::app()->options();
		if ($__->cnet_add_redirect_page || $__->cnet_limit_download)
			$_ = preg_replace('/\[url[^\]]*\].*?\[\/url\]/is', '***', $_);
		if ($__->cnet_limit_download && $__->cnet_force_like == 'all')
			$_ = preg_replace('/(\[code(?:=[^\]]+)?\]).*?(\[\/code\])/is', '$1***$2', $_);
		return $_;
	}
	public function getBbCodeForQuote($_, $__)
	{
		return parent::getBbCodeForQuote($this->stripCodeForQuote($_), $__);
	}
	public function stripBbCode($_, array $__ = [])
	{
		return parent::stripBbCode($this->stripCode($_), $__);
	}
	public function snippetString($_, $__ = 0, array $___ = [])
	{
		return parent::snippetString($this->stripCode($_), $__, $___);
	}
	public function getLinkClassTarget($_)
	{
		$__ = parent::getLinkClassTarget($_);
		$___ = \XF::app()->router('public')->buildLink('redirect');
		if (stripos($_, $___) !== false) {
			$__['target'] = '_blank';
			$__['class'] = 'link link--external';
		}
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */