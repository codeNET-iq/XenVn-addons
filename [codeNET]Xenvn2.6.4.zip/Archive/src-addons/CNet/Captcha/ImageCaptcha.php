<?php
namespace CNet\Captcha;
use XF\Captcha\AbstractCaptcha;
use XF\Template\Templater;
$_ = \XF::app()->addonManager()->getById("CNet");
if ($_ && $_->isActive()) {
	class ImageCaptcha extends AbstractCaptcha
	{
		public function renderInternal(Templater $__)
		{
			return $__->renderMacro('public:cnet_macros', 'captchaImage', $this->repoUtility()->getImageCaptchaData());
		}
		public function isValid()
		{
			$__ = $this->repoUtility();
			$___ = $this->app->request();
			$____ = $___->filter('captcha_image_answer', 'str');
			$_____ = $___->filter('captcha_image_data', 'str');
			$_____ = $__->decryptKey($_____);
			if ($_____)
				$_____ = explode('|', $_____);
			if ($____ && is_array($_____) && count($_____) == 3) {
				$______ = $_____[0];
				$_______ = $_____[1];
				$________ = $_____[2];
				if ($______ && $________) {
					$_________ = \XF::$time;
					$__________ = $this->app['session.public'];
					$___________ = $__________->get('cnet_captcha_attempts') ?: 0;
					$____________ = $__________->get('cnet_captcha_limit') ?: 0;
					if ($____________ <= ($_________ - 2) && $___________ < 5 && strlen($______) == 9 && $______ == $____ && $_______ == \XF::visitor()->user_id && $________ >= ($_________ - 120) && $________ <= ($_________ - 2) && $___->getUserAgent()) {
						$__________->set('cnet_captcha_attempts', 0);
						return true;
					} else
						$__________->set('cnet_captcha_attempts', $___________ + 1);
				}
			}
			return false;
		}
		protected function repoUtility()
		{
			return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
		}
	}
} else {
	class ImageCaptcha extends \XF\Captcha\HCaptcha {}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */