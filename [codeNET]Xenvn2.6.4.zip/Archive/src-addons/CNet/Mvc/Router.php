<?php
/* Developed by CNet Tools */
namespace CNet\Mvc;
use XF\Http\Request;
class Router extends XFCP_Router
{
	public function routeToController($_, ?Request $__ = null)
	{
		$___ = $____ = $_____ = '';
		if (preg_match('/^([^\/#]+\.)?([a-z])(\d+.*)$/i', urldecode($_), $______)) {
			$___ = strtolower($______[2]);
			$_____ = $______[1] . $______[3];
		}
		if (!empty($___)) {
			switch ($___) {
				case 's':
					$____ = 'resources/categories/';
					break;
				case 'c':
					$____ = 'categories/';
					break;
				case 'f':
					$____ = 'forums/';
					break;
				case 't':
					$____ = 'threads/';
					break;
				case 'r':
					$____ = 'resources/';
					break;
				case 'a':
					$____ = 'attachments/';
					break;
				case 'm':
					$____ = 'members/';
					break;
				default:
					$____ = '';
					break;
			}
			$_ = $____ . $_____;
		}
		return parent::routeToController($_, $__);
	}
	protected function getThreadOrder($_, $__)
	{
		$___ = $_->TypeHandler;
		if ($___->getDefaultPostListOrder($_) != 'post_date' && !($__->isFirstPost() && $___->isFirstPostPinned($_)))
			return true;
		return false;
	}
	public function buildLink($_, $__ = null, array $___ = [], $____ = null)
	{
		$_____ = \XF::app();
		$______ = $_____->options();
		$_______ = $______->cnet_external_storage ?? false;
		if ($_______ && $__ && $__ instanceof \XF\Entity\Attachment) {
			if ($_ == 'full:attachments' && !$____) {
				if ($__->storage && ($__->has_thumbnail || $__->is_audio || $__->is_video) && $__->canView()) {
					[$________, $_________] = $__->getExternalStorageUrl();
					if ($________ && $_________ == 'url')
						return $________;
				}
			}
		}
		$__________ = $______->cnet_convert_link ?? false;
		if ($__________) {
			if (($_ == 'threads/post' || $_ == 'canonical:threads/post') && $__ instanceof \XF\Entity\Thread && isset($___['post_id'])) {
				$___________ = $___['post_id'];
				$____________ = $_____->em()->find('XF:Post', $___________);
				if ($____________) {
					$_ = ((strpos($_, 'canonical:') !== false) ? 'canonical:' : '') . 'threads';
					$____ = '#post-' . $___________;
					$_____________ = floor($____________->position / $______->messagesPerPage) + 1;
					$___ = ['page' => $_____________];
					if ($this->getThreadOrder($__, $____________))
						$___['order'] = 'post_date';
				}
			} else if (($_ == 'threads/latest' || $_ == 'canonical:threads/latest') && $__ instanceof \XF\Entity\Thread && isset($__->LastPost)) {
				$____________ = $__->LastPost;
				if ($____________) {
					$_ = ((strpos($_, 'canonical:') !== false) ? 'canonical:' : '') . 'threads';
					$___________ = $____________->post_id;
					$____ = '#post-' . $___________;
					$_____________ = floor($____________->position / $______->messagesPerPage) + 1;
					$___ = ['page' => $_____________];
					if ($this->getThreadOrder($__, $____________))
						$___['order'] = 'post_date';
				}
			} else if (($_ == 'threads/unread' || $_ == 'canonical:threads/unread') && !\XF::visitor()->user_id) {
				$_ = ((strpos($_, 'canonical:') !== false) ? 'canonical:' : '') . 'threads';
			} else if (($_ == 'posts' || $_ == 'canonical:posts') && $__ instanceof \XF\Entity\Post && isset($__->Thread)) {
				$______________ = $__->Thread;
				if ($______________) {
					$_ = ((strpos($_, 'canonical:') !== false) ? 'canonical:' : '') . 'threads';
					$____ = '#post-' . $__->post_id;
					$_____________ = floor($__->position / $______->messagesPerPage) + 1;
					$___ = ['page' => $_____________];
					if ($this->getThreadOrder($______________, $__))
						$___['order'] = 'post_date';
					$__ = $______________;
				}
			} else if ($_ == 'goto/post') {
				$___________ = $___['id'];
				$____________ = $_____->em()->find('XF:Post', $___________);
				if ($____________) {
					$______________ = $____________->Thread;
					if ($______________) {
						$_ = ((strpos($_, 'canonical:') !== false) ? 'canonical:' : '') . 'threads';
						$____ = '#post-' . $___________;
						$_____________ = floor($____________->position / $______->messagesPerPage) + 1;
						$___ = ['page' => $_____________];
						if ($this->getThreadOrder($______________, $____________))
							$___['order'] = 'post_date';
						$__ = $______________;
					}
				}
			}
		}
		$________ = parent::buildLink($_, $__, $___, $____);
		$_______________ = $______->cnet_remove_version_suffix ?? false;
		if ($_______________ && $_ == 'attachments' && $__ instanceof \XF\Entity\Attachment) {
			$________ = preg_replace('/[-_](\d+(-\d+)+|v\d+)[\w-]*(-[a-z]+\.\d+\/?)$/i', '$3', $________);
		}
		$_______________ = $______->cnet_remove_route ?? false;
		if ($_______________) {
			$________________ = $______->boardUrl;
			$_________________ = parse_url($________________, PHP_URL_PATH);
			$________________ = preg_quote($________________, '/');
			if (empty($_________________)) {
				$__________________ = $________________;
			} else {
				$_________________ = preg_quote($_________________, '/');
				$__________________ = $________________ . '|' . $_________________;
			}
			if (preg_match('/^(' . $__________________ . ')?\/(resources\/categories|categories|forums|threads|resources|attachments|members)\/([^\/#\?]+\.)(\d+.*)$/iU', $________, $___________________)) {
				$____________________ = '';
				$_____________________ = strtolower($___________________[2]);
				if (!empty($_____________________)) {
					switch ($_____________________) {
						case 'resources/categories':
							$____________________ = 's';
							break;
						case 'categories':
							$____________________ = 'c';
							break;
						case 'forums':
							$____________________ = 'f';
							break;
						case 'threads':
							$____________________ = 't';
							break;
						case 'resources':
							$____________________ = 'r';
							break;
						case 'attachments':
							$____________________ = 'a';
							break;
						case 'members':
							$____________________ = 'm';
							break;
						default:
							$____________________ = '';
							break;
					}
					$________ = $___________________[1] . '/' . $___________________[3] . $____________________ . $___________________[4];
				}
			}
		}
		return $________;
	}
	public function prepareStringForUrl($_, $__ = null)
	{
		$_ = strval($_);
		$___ = $__ === null ? $this->romanizeUrls : (bool)$__;
		$____ = $_ . ($___ ? '|r' : '');
		if (isset($this->stringCache[$____]))
			return $this->stringCache[$____];
		if ($___) {
			$_ = preg_replace('/[\x{0300}-\x{036F}]/u', '', $_);
			$_____ = ['à' => 'a', 'á' => 'a', 'ạ' => 'a', 'ả' => 'a', 'ã' => 'a', 'â' => 'a', 'ầ' => 'a', 'ấ' => 'a', 'ậ' => 'a', 'ẩ' => 'a', 'ẫ' => 'a', 'ă' => 'a', 'ằ' => 'a', 'ắ' => 'a', 'ặ' => 'a', 'ẳ' => 'a', 'ẵ' => 'a', 'è' => 'e', 'é' => 'e', 'ẹ' => 'e', 'ẻ' => 'e', 'ẽ' => 'e', 'ê' => 'e', 'ề' => 'e', 'ế' => 'e', 'ệ' => 'e', 'ể' => 'e', 'ễ' => 'e', 'ì' => 'i', 'í' => 'i', 'ị' => 'i', 'ỉ' => 'i', 'ĩ' => 'i', 'ò' => 'o', 'ó' => 'o', 'ọ' => 'o', 'ỏ' => 'o', 'õ' => 'o', 'ô' => 'o', 'ồ' => 'o', 'ố' => 'o', 'ộ' => 'o', 'ổ' => 'o', 'ỗ' => 'o', 'ơ' => 'o', 'ờ' => 'o', 'ớ' => 'o', 'ợ' => 'o', 'ở' => 'o', 'ỡ' => 'o', 'ù' => 'u', 'ú' => 'u', 'ụ' => 'u', 'ủ' => 'u', 'ũ' => 'u', 'ư' => 'u', 'ừ' => 'u', 'ứ' => 'u', 'ự' => 'u', 'ử' => 'u', 'ữ' => 'u', 'ỳ' => 'y', 'ý' => 'y', 'ỵ' => 'y', 'ỷ' => 'y', 'ỹ' => 'y', 'đ' => 'd', 'À' => 'A', 'Á' => 'A', 'Ạ' => 'A', 'Ả' => 'A', 'Ã' => 'A', 'Â' => 'A', 'Ầ' => 'A', 'Ấ' => 'A', 'Ậ' => 'A', 'Ẩ' => 'A', 'Ẫ' => 'A', 'Ă' => 'A', 'Ằ' => 'A', 'Ắ' => 'A', 'Ặ' => 'A', 'Ẳ' => 'A', 'Ẵ' => 'A', 'È' => 'E', 'É' => 'E', 'Ẹ' => 'E', 'Ẻ' => 'E', 'Ẽ' => 'E', 'Ê' => 'E', 'Ề' => 'E', 'Ế' => 'E', 'Ệ' => 'E', 'Ể' => 'E', 'Ễ' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Ị' => 'I', 'Ỉ' => 'I', 'Ĩ' => 'I', 'Ò' => 'O', 'Ó' => 'O', 'Ọ' => 'O', 'Ỏ' => 'O', 'Õ' => 'O', 'Ô' => 'O', 'Ồ' => 'O', 'Ố' => 'O', 'Ộ' => 'O', 'Ổ' => 'O', 'Ỗ' => 'O', 'Ơ' => 'O', 'Ờ' => 'O', 'Ớ' => 'O', 'Ợ' => 'O', 'Ở' => 'O', 'Ỡ' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Ụ' => 'U', 'Ủ' => 'U', 'Ũ' => 'U', 'Ư' => 'U', 'Ừ' => 'U', 'Ứ' => 'U', 'Ự' => 'U', 'Ử' => 'U', 'Ữ' => 'U', 'Ỳ' => 'Y', 'Ý' => 'Y', 'Ỵ' => 'Y', 'Ỷ' => 'Y', 'Ỹ' => 'Y', 'Đ' => 'D'];
			$_ = strtr($_, $_____);
		}
		return parent::prepareStringForUrl($_, $___);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */