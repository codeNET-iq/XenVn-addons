<?php
/* Developed by CNet Tools */
namespace CNet\Mvc\Renderer;
use XF\Mvc\Reply\AbstractReply;
use XF\Util\File;
class Html extends XFCP_Html
{
	public function renderErrors(array $_)
	{
		$__ = \XF::app();
		$___ = ($this->response->httpCode() != 200);
		$____ = ($___ ? $__->options()->cnet_404_search : 0);
		return $this->renderView('XF:Error', $__['app.defaultType'] . ':error', [
			'errors' => $_,
			'error' => count($_) == 1 ? reset($_) : false,
			'search' => ($____ ? $this->itemsSearch($____) : false),
			'noindex' => $___
		]);
	}
	protected function itemsSearch($_)
	{
		$__ = \XF::app();
		if (preg_match("/([a-z0-9-]+)(\.[a-z0-9]+\/?)$/i", $__->request()->getRoutePath(), $___)) {
			if (!isset($___[1]) || empty($___[1]))
				return false;
			if (function_exists('mb_substr'))
				$____ = mb_substr($___[1], 0, 150);
			else
				$____ = substr($___[1], 0, 150);
			$_____ = preg_replace('/[\p{P}]/u', ' ', $____);
			$______ = false;
			if (!empty($____)) {
				$_______ = $this->repoUtility()->get_similar_threads($____, 0, 0, $_);
				$________ = $__->addonManager()->getById('XFRM');
				if ($________ && $________->isActive())
					$______ = $this->repoUtility()->get_similar_resources($____, 0, 0, $_);
				$_________ = [
					'threads' => $_______,
					'resources' => $______,
					"\x6b\x65\x79" => $_____
				];
				return $_________;
			}
		}
		return false;
	}
	protected function getHttpVersion()
	{
		if (!preg_match('#^HTTP/([\d\.]+)$#', $_SERVER['SERVER_PROTOCOL'], $_))
			return null;
		return $_[1];
	}
	public function postFilter($_, AbstractReply $__)
	{
		$___ = \XF::app();
		$____ = $___->options()->cnet_optimize_xf ?? false;
		if (\XF::$versionId >= 2030035 || !$____)
			return parent::postFilter($_, $__);
		$_ = strval($_);
		if (\XF::$debugMode) {
			$_____ = $this->templater->getTemplateErrors();
			if ($_____) {
				$______ = '<div class="blockMessage blockMessage--error"><h2 style="margin: 0 0 .5em 0">Template errors</h2><ul>';
				foreach ($_____ as $_______) {
					$______ .= sprintf(
						'<li>Template %s: %s (%s:%d)</li>',
						htmlspecialchars($_______['template']),
						htmlspecialchars($_______['error']),
						htmlspecialchars(File::stripRootPathPrefix($_______['file'])),
						$_______['line']
					);
				}
				$______ .= '</ul></div>';
				if (strpos($_, '<!--XF:EXTRA_OUTPUT-->') !== false) {
					$_ = str_replace('<!--XF:EXTRA_OUTPUT-->', $______ . '<!--XF:EXTRA_OUTPUT-->', $_);
				} else {
					$_ = preg_replace('#<body[^>]*>#i', "\\0$______", $_);
				}
			}
		}
		$________ = $this->templater;
		$_________ = '';
		$__________ = '';
		$___________ = $________->getIncludedCss(['public:extra.less']);
		$____________ = $this->getHttpVersion();
		if (version_compare($____________, '2', '>=')) {
			foreach ($___________ as $_____________) {
				$_________ .= '<link rel="stylesheet" href="'
					. htmlspecialchars($________->getCssLoadUrl([$_____________]))
					. '" />' . "\n";
			}
		} else {
			$_________ .= '<link rel="stylesheet" href="'
				. htmlspecialchars($________->getCssLoadUrl($___________))
				. '" />' . "\n";
		}
		if ($___________) {
			$______________ = json_encode(array_fill_keys($___________, true));
		} else {
			$______________ = '{}';
		}
		$_______________ = $________->getInlineCss();
		if ($_______________) {
			foreach ($_______________ as $________________) {
				$_________ .= "<style>\n" . $________________ . "\n</style>\n";
			}
		}
		$_________________ = $________->getIncludedJs();
		if ($_________________) {
			foreach ($_________________ as $__________________) {
				$__________ .= '<script src="' . htmlspecialchars($__________________) . '"></script>' . "\n";
			}
			$___________________ = json_encode(array_fill_keys($_________________, true));
		} else {
			$___________________ = '{}';
		}
		$____________________ = $________->getInlineJs();
		if ($____________________) {
			foreach ($____________________ as $________________) {
				$__________ .= "<script>\n" . $________________ . "\n</script>\n";
			}
		}
		if ($___->container()->isCached('db')) {
			$_____________________ = $___->db()->getQueryCount();
		} else {
			$_____________________ = '-';
		}
		$______________________ = microtime(true) - $___->container('time.granular');
		$_ = strtr($_, [
			'<!--XF:CSS-->' => $_________,
			'{\'<!--XF:CSS:JSON-->\'}' => $______________,
			'<!--XF:JS-->' => $__________,
			'{\'<!--XF:JS:JSON-->\'}' => $___________________,
			'<!--XF:QUERIES-->' => $_____________________,
			'<!--XF:PAGE_TIME-->' => number_format($______________________, 4),
			'<!--XF:MEMORY_PEAK-->' => number_format(memory_get_peak_usage() / 1024 / 1024, 2) . 'MB',
		]);
		return $_;
	}
	protected function repoUtility()
	{
		return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */