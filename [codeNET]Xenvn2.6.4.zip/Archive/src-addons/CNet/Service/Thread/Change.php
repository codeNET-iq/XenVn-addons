<?php
/* Developed by CNet Tools */
namespace CNet\Service\Thread;
use XF\Service\AbstractService;
class Change extends AbstractService
{
	public function updateDate(&$_, &$__)
	{
		$___ = $_->Thread;
		$____ = $_->Thread->Forum;
		$_____ = $_->thread_id;
		$_->post_date = $__;
		$_->save(true, false);
		$______ = $this->repository('XF:Thread');
		$______->rebuildThreadPostPositions($_____);
		$___->rebuildCounters();
		$___->save(true, false);
		$____->rebuildCounters();
		$____->save(true, false);
		if (!$_->position) {
			$___->post_date = $__;
			$___->save(true, false);
		}
		$_______ = $this->app->finder('XF:Post')
			->where('thread_id', $_____)
			->order('position', 'DESC')
			->fetchOne();
		if ($_->position == $_______->position) {
			$___->last_post_date = $__;
			$___->save(true, false);
		}
		$_______ = $this->app->finder('XF:NewsFeed')
			->where('content_type', 'thread')
			->where('content_id', $_____)
			->where('action', 'insert')
			->fetchOne();
		if ($_______)
			$_______->delete(true, false);
		$________ = $this->app->finder('XF:Post')
			->where('thread_id', $_____)
			->where('message_state', 'visible')
			->fetch();
		foreach ($________ as $_______) {
			$_________ = $this->app->finder('XF:NewsFeed')
				->where('content_type', 'post')
				->where('content_id', $_______->post_id)
				->where('action', 'insert')
				->fetchOne();
			if ($_________)
				$_________->delete(true, false);
		}
		if ($this->app->options()->enableNewsFeed) {
			$__________ = time() - 90 * 86400;
			$________ = $this->app->finder('XF:Post')
				->where('thread_id', $_____)
				->where('post_date', '>', $__________)
				->where('message_state', 'visible')
				->fetch();
			foreach ($________ as $_______) {
				if (!$_______->user_id)
					continue;
				$___________ = $_______->position;
				if (!$___________) {
					$____________ = $this->app->em()->create('XF:NewsFeed');
					$____________->user_id = $_______->user_id;
					$____________->username = $_______->username;
					$____________->content_type = 'thread';
					$____________->content_id = $_____;
					$____________->action = 'insert';
					$____________->event_date = $_______->post_date;
					$____________->save(true, false);
				}
				if ($___________) {
					$____________ = $this->app->em()->create('XF:NewsFeed');
					$____________->user_id = $_______->user_id;
					$____________->username = $_______->username;
					$____________->content_type = 'post';
					$____________->content_id = $_______->post_id;
					$____________->action = 'insert';
					$____________->event_date = $_______->post_date;
					$____________->save(true, false);
				}
			}
		}
	}
	public function updateAuthor(&$_, &$__)
	{
		$___ = $_->Thread;
		$____ = $_->Thread->Forum;
		$_____ = $_->post_id;
		$______ = $_->thread_id;
		$_______ = $_->position;
		$________ = $_->user_id;
		$_________ = $__->user_id;
		$__________ = $__->username;
		$_->user_id = $_________;
		$_->username = $__________;
		$_->save(true, false);
		$___________ = $this->app->finder('XF:ReactionContent')
			->where('content_type', 'post')
			->where('content_id', $_____)
			->where('reaction_user_id', $_________)
			->fetchOne();
		if ($___________)
			$___________->delete(true, false);
		if (!$_______) {
			$___->user_id = $_________;
			$___->username = $__________;
			$___->save(true, false);
		}
		$____________ = false;
		$___________ = $this->app->finder('XF:Post')
			->where('thread_id', $______)
			->order('position', 'DESC')
			->fetchOne();
		if ($_______ == $___________->position) {
			$___->last_post_user_id = $_________;
			$___->last_post_username = $__________;
			$___->save(true, false);
			$____________ = true;
		}
		$___________ = $this->app->finder('XF:Attachment')
			->where('content_type', 'post')
			->where('content_id', $_____)
			->with('Data')
			->fetch();
		foreach ($___________ as $_____________) {
			$______________ = $_____________->Data;
			$______________->user_id = $_________;
			$______________->save(true, false);
		}
		if ($____________) {
			$___________ = $this->app->finder('XF:Post')
				->where('Thread.node_id', $____->node_id)
				->order('post_date', 'DESC')
				->fetchOne();
			if ($___________)
				$_______________ = $___________->post_id;
			if ($_______________ == $_____) {
				$____->last_post_user_id = $_________;
				$____->last_post_username = $__________;
				$____->save(true, false);
			}
		}
		$________________ = $this->app->finder('XF:ThreadRead')
			->where('thread_id', $______)
			->where('user_id', $________)
			->fetch();
		foreach ($________________ as $___________) {
			$___________->delete(true, false);
		}
		$_________________ = $this->app->finder('XF:ThreadUserPost')
			->where('thread_id', $______)
			->where('user_id', $________)
			->fetchOne();
		if ($_________________) {
			$________________ = $this->app->finder('XF:Post')
				->where('thread_id', $______)
				->where('user_id', $________)
				->fetch();
			$__________________ = count($________________);
			if ($__________________) {
				$_________________->post_count = $__________________;
				$_________________->save(true, false);
			} else
				$_________________->delete(true, false);
		} else {
			$________________ = $this->app->finder('XF:Post')
				->where('thread_id', $______)
				->where('user_id', $________)
				->fetch();
			$_________________ = $this->app->em()->create('XF:ThreadUserPost');
			$_________________->thread_id = $______;
			$_________________->user_id = $________;
			$_________________->post_count = count($________________);
			$_________________->save(true, false);
		}
		$_________________ = $this->app->finder('XF:ThreadUserPost')
			->where('thread_id', $______)
			->where('user_id', $_________)
			->fetchOne();
		if ($_________________) {
			$________________ = $this->app->finder('XF:Post')
				->where('thread_id', $______)
				->where('user_id', $_________)
				->fetch();
			$_________________->post_count = count($________________);
			$_________________->save(true, false);
		} else {
			$________________ = $this->app->finder('XF:Post')
				->where('thread_id', $______)
				->where('user_id', $_________)
				->fetch();
			$_________________ = $this->app->em()->create('XF:ThreadUserPost');
			$_________________->thread_id = $______;
			$_________________->user_id = $_________;
			$_________________->post_count = count($________________);
			$_________________->save(true, false);
		}
		$___________ = $this->app->finder('XF:User')
			->where('user_id', $________)
			->fetchOne();
		if ($___________ && $___________->message_count) {
			$___________->message_count = ($___________->message_count - 1);
			$___________->save(true, false);
		}
		$___________ = $this->app->finder('XF:User')
			->where('user_id', $_________)
			->fetchOne();
		if ($___________) {
			$___________->message_count = ($___________->message_count + 1);
			$___________->save(true, false);
		}
		$___________ = $this->app->finder('XF:NewsFeed')
			->where('content_type', 'thread')
			->where('content_id', $______)
			->where('action', 'insert')
			->fetchOne();
		if ($___________) {
			$___________->user_id = $_________;
			$___________->username = $__________;
			$___________->save(true, false);
		}
		$___________ = $this->app->finder('XF:NewsFeed')
			->where('content_type', 'post')
			->where('content_id', $_____)
			->where('action', 'insert')
			->fetchOne();
		if ($___________) {
			$___________->user_id = $_________;
			$___________->username = $__________;
			$___________->save(true, false);
		}
		$___________ = $this->app->finder('XF:ThreadWatch')
			->where('user_id', $________)
			->where('thread_id', $______)
			->fetchOne();
		if ($___________)
			$___________->delete(true, false);
		$___________ = $this->app->finder('XF:Post')
			->where('user_id', $________)
			->where('thread_id', $______)
			->fetch();
		$___________________ = count($___________);
		if ($___________________) {
			$___________ = $this->app->finder('XF:UserOption')
				->where('user_id', $________)
				->fetchOne();
			if ($___________) {
				if ($___________->creation_watch_state == 'watch_no_email' && !$_______) {
					$____________________ = $this->app->em()->create('XF:ThreadWatch');
					$____________________->user_id = $________;
					$____________________->thread_id = $______;
					$____________________->email_subscribe = 0;
					$____________________->save(true, false);
				}
				if ($___________->creation_watch_state == 'watch_email' && !$_______) {
					$____________________ = $this->app->em()->create('XF:ThreadWatch');
					$____________________->user_id = $________;
					$____________________->thread_id = $______;
					$____________________->email_subscribe = 1;
					$____________________->save(true, false);
				}
				if ($___________->interaction_watch_state == 'watch_no_email' && $_______) {
					$____________________ = $this->app->em()->create('XF:ThreadWatch');
					$____________________->user_id = $________;
					$____________________->thread_id = $______;
					$____________________->email_subscribe = 0;
					$____________________->save(true, false);
				}
				if ($___________->interaction_watch_state == 'watch_email' && $_______) {
					$____________________ = $this->app->em()->create('XF:ThreadWatch');
					$____________________->user_id = $________;
					$____________________->thread_id = $______;
					$____________________->email_subscribe = 1;
					$____________________->save(true, false);
				}
			}
		}
		$___________ = $this->app->finder('XF:ThreadWatch')
			->where('user_id', $_________)
			->where('thread_id', $______)
			->fetchOne();
		if ($___________)
			$___________->delete(true, false);
		$___________ = $this->app->finder('XF:UserOption')
			->where('user_id', $_________)
			->fetchOne();
		if ($___________) {
			if ($___________->creation_watch_state == 'watch_no_email' && !$_______) {
				$____________________ = $this->app->em()->create('XF:ThreadWatch');
				$____________________->user_id = $_________;
				$____________________->thread_id = $______;
				$____________________->email_subscribe = 0;
				$____________________->save(true, false);
			}
			if ($___________->creation_watch_state == 'watch_email' && !$_______) {
				$____________________ = $this->app->em()->create('XF:ThreadWatch');
				$____________________->user_id = $_________;
				$____________________->thread_id = $______;
				$____________________->email_subscribe = 1;
				$____________________->save(true, false);
			}
			if ($___________->interaction_watch_state == 'watch_no_email' && $_______) {
				$____________________ = $this->app->em()->create('XF:ThreadWatch');
				$____________________->user_id = $_________;
				$____________________->thread_id = $______;
				$____________________->email_subscribe = 0;
				$____________________->save(true, false);
			}
			if ($___________->interaction_watch_state == 'watch_email' && $_______) {
				$____________________ = $this->app->em()->create('XF:ThreadWatch');
				$____________________->user_id = $_________;
				$____________________->thread_id = $______;
				$____________________->email_subscribe = 1;
				$____________________->save(true, false);
			}
		}
		$this->app->search()->reassignContent($________, $_________);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */