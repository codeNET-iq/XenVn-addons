<?php
/* Developed by CNet Tools */
namespace CNet\Service\Asset;
use XF\FileWrapper;
class Upload extends XFCP_Upload
{
	protected static $_ = false;
	public function setImageFromUpload(\XF\Http\Upload $__)
	{
		if ($this->assetType && stripos($this->assetType, 'cnet_') === 0) {
			static::$_ = true;
			if (\XF::$versionId < 2030035)
				$__->setOptimize(false);
			else
				$__->setImageOptimize(false);
		} else if (\XF::$versionId < 2030035 && $this->app->options()->cnet_convert_avif)
			$__->setOptimize(true);
		return parent::setImageFromUpload($__);
	}
	public function setImageFromFile(FileWrapper $__)
	{
		if (!static::$_)
			return parent::setImageFromFile($__);
		if (!$this->validateImageForAsset($__, $___)) {
			$this->error = $___;
			$this->tempFile = null;
			return false;
		}
		$____ = preg_replace('#[^a-z0-9_.-]#i', '', $__->getFileName());
		if (!in_array(strtolower($__->getExtension()), $this->getValidAssetExtensions()))
			throw new \LogicException("Unexpected file extension for $____");
		$this->tempFile = $__->getFilePath();
		$this->fileName = $____;
		return true;
	}
	protected function validateImageForAsset(FileWrapper $__, &$___ = null)
	{
		if (static::$_ && $__->getExtension() == 'ico')
			return true;
		return parent::validateImageForAsset($__, $___);
	}
	public static function getValidAssetExtensions()
	{
		$__ = parent::getValidAssetExtensions();
		if (!in_array('webp', $__))
			$__[] = 'webp';
		if (static::$_ && !in_array('ico', $__))
			$__[] = 'ico';
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */