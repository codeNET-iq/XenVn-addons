/* Developed by CNet Tools */
// Note: This is sample code, you should enhance security if possible.
// Query syntax: ?url=...&proxy_key=...
export default {
	async fetch(request, env, ctx) {
		const urlObj = new URL(request.url);
		const providedKey = urlObj.searchParams.get("proxy_key") || "";
		const secret = env['proxy_key'];
		if (!secret || !providedKey || providedKey != secret) {
			return new Response("Unauthorized: Invalid proxy key", { status: 401 });
		}
		let target = urlObj.searchParams.get("url") || "";
		if (!target) {
			return new Response("Missing ?url=...", { status: 400 });
		}
		let targetUrl;
		try {
			targetUrl = new URL(target);
		} catch (e) {
			return new Response("Invalid target URL", { status: 400 });
		}
		if (!["http:", "https:"].includes(targetUrl.protocol)) {
			return new Response("Unsupported protocol", { status: 400 });
		}
		const hostname = targetUrl.hostname.toLowerCase();
		if (hostname == "localhost" || hostname == "127.0.0.1" || hostname == "::1" || hostname.endsWith(".local")) {
			return new Response("Target host not allowed", { status: 403 });
		}
		const cacheKey = new Request(request.url, request);
		const cache = caches.default;
		try {
			const cached = await cache.match(cacheKey);
			if (cached) {
				return cached;
			}
		} catch (e) { }
		const outgoingHeaders = new Headers(request.headers);
		const hop = [
			"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade", "x-proxy-key", "x-forwarded-for", "x-real-ip", "forwarded", "via", "cf-connecting-ip"
		];
		for (const h of hop) {
			outgoingHeaders.delete(h);
		}
		const fetchInit = {
			method: request.method,
			headers: outgoingHeaders,
			redirect: "follow",
			body: ["GET", "HEAD"].includes(request.method) ? undefined : request.body
		};
		let upstream;
		try {
			upstream = await fetch(target, fetchInit);
		} catch (err) {
			return new Response("Upstream fetch error: " + err.message, { status: 502 });
		}
		const respHeaders = new Headers(upstream.headers);
		const contentLength = respHeaders.get("content-length");
		if (contentLength && Number(contentLength) > 10485760) {
			return new Response("Upstream file too large", { status: 413 });
		}
		const response = new Response(upstream.body, {
			status: upstream.status,
			statusText: upstream.statusText,
			headers: respHeaders
		});
		if (upstream.status == 200) {
			try {
				const toCache = response.clone();
				toCache.headers.set("Cache-Control", "public, max-age=86400");
				ctx.waitUntil(cache.put(cacheKey, toCache));
			} catch (e) { }
		}
		return response
	}
};