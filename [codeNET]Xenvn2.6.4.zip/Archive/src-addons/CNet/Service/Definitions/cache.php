<?php
/* Developed by CNet Tools */
define('CACHE', ['image' => true, 'css' => true]);
define('APACHE_X_SENDFILE', false);
define('EXTERNAL_FOLDER', '');
define('DEBUG', false);
define('DIR', str_replace('\\', '/', __DIR__));
require_once DIR . '/src/config.php';
define('CONFIG', $config ?? []);
define('INTERNAL_DATA_PATH', CONFIG['INTERNAL_DATA_PATH'] ?? 'internal_data');
function exitRun($_, $__ = '')
{
	header('Content-type: text/plain; charset=utf-8');
	header('Cache-Control: private, no-cache, max-age=0');
	http_response_code($_);
	if ($__)
		echo $__;
	exit();
}
function byteConvert($_)
{
	if ($_ <= 0)
		return '0B';
	$__ = ['B', 'K', 'M', 'G'];
	$___ = min(floor(log($_, 1024)), count($__) - 1);
	$_ /= pow(1024, $___);
	return  round($_) . $__[$___];
}
$_ = strval($_GET['type'] ?? '');
if (!$_)
	exitRun(404, 'No query type!');
function loadDB()
{
	require_once DIR . '/src/XF/Db/AbstractStatement.php';
	require_once DIR . '/src/XF/Db/AbstractAdapter.php';
	require_once DIR . '/src/XF/Db/Exception.php';
	require_once DIR . '/src/XF/Db/Mysqli/Statement.php';
	require_once DIR . '/src/XF/Db/Mysqli/Adapter.php';
	$__ = (array)CONFIG['db'] ?? false;
	if (!$__)
		exitRun(500, 'Database configuration not set!');
	$___ = new XF\Db\Mysqli\Adapter($__, CONFIG['fullUnicode'] ?? false);
	register_shutdown_function(function () use ($___) {
		$___->closeConnection();
	});
	return $___;
}
function checkUser($__)
{
	$___ = 0;
	$____ = CONFIG['cookie']['prefix'] ?? 'xf_';
	$_____ = $_COOKIE[$____ . 'session'] ?? '';
	if (!$_____)
		exitRun(403, 'You must login to view!');
	$______ = CONFIG['cache']['sessions'] ?? false;
	$_______ = CONFIG['cache']['provider'] ?? '';
	$________ = CONFIG['cache']['config'] ?? '';
	if ($______ && $_______ == 'Redis') {
		$_________ = $________['host'] ?? '';
		$__________ = $________['port'] ?? 6379;
		$___________ = $________['password'] ?? '';
		$____________ = $________['database'] ?? 0;
		$_____________ = new Redis();
		$_____________->connect($_________, $__________);
		if ($___________)
			$_____________->auth($___________);
		$_____________->select($____________);
		$______________ = $_____________->get('xf:session_' . $_____);
		if ($______________) {
			if (function_exists('igbinary_unserialize'))
				$______________ = igbinary_unserialize($______________);
			else
				$______________ = unserialize($______________);
			$___ = $______________['userId'] ?? 0;
		}
	} else {
		$_______________ = $__->query("SELECT * FROM xf_session WHERE session_id = ? AND expiry_date >= ?", [$_____, time()])->fetch();
		if ($_______________) {
			$______________ = $_______________['session_data'];
			$______________ = unserialize($______________);
			$___ = $______________['userId'] ?? 0;
		}
	}
	if (!$___)
		exitRun(403, 'You must login to view!');
	return $___;
}
function fastImage()
{
	$__ = intval($_GET['id'] ?? 0);
	if (!$__)
		exitRun(404, 'Image Id is empty!');
	$___ = loadDB();
	$____ = $___->query("
				SELECT attachment.*, attachment_data.*
				FROM xf_attachment AS attachment
				INNER JOIN xf_attachment_data AS attachment_data ON attachment_data.data_id = attachment.data_id
				WHERE attachment.attachment_id = ? AND attachment_data.width > 0 AND attachment_data.height > 0
			", [$__])->fetchAliasGrouped();
	if (!is_array($____) || !count($____))
		exitRun(404, 'Image database not found!');
	$_____ = $____['attachment'] ?? '';
	$______ = $____['attachment_data'] ?? '';
	if (!$_____ || !$______)
		exitRun(404, 'Image database is wrong!');
	$_______ = $_____['content_type'];
	$________ = $_____['content_id'];
	$_________ = $_____['temp_hash'];
	$__________ = $_____['storage'] ?? 0;
	$___________ = intval($______['data_id']);
	$____________ = $______['file_key'] ?? $______['file_hash'];
	$_____________ = $______['filename'];
	$______________ = intval($______['upload_date']);
	$_______________ = floor($___________ / 1000);
	$________________ = sprintf(
		'%s/attachments/%d/%d-%s.data',
		INTERNAL_DATA_PATH,
		$_______________,
		$___________,
		$____________
	);
	if (EXTERNAL_FOLDER && $__________)
		$________________ = str_replace('\\', '/', DIR . '/' . ltrim(EXTERNAL_FOLDER, "/\\") . '/' . $________________);
	else
		$________________ = str_replace('\\', '/', DIR . '/' . $________________);
	if (!is_file($________________))
		exitRun(404, 'Image filepath not found!');
	$_________________ = filesize($________________);
	if (!$_________________)
		exitRun(400, 'Image filesize is 0!');
	if ($_______ == 'conversation_message') {
		$__________________ = true;
		$___________________ = checkUser($___);
		$____________________ = $_GET['hash'] ?? '';
		if ($_________ && $_________ == $____________________)
			$__________________ = false;
		if ($__________________) {
			$____ = $___->query("
				SELECT conversation_message.*, conversation_master.*
				FROM xf_conversation_message AS conversation_message
				INNER JOIN xf_conversation_master AS conversation_master ON conversation_master.conversation_id = conversation_message.conversation_id
				WHERE conversation_message.message_id = ?
			", [$________])->fetchAliasGrouped();
			if (!is_array($____) || !count($____))
				exitRun(404, 'Conversation database not found!');
			$_____________________ = $____['conversation_message'] ?? '';
			$______________________ = $____['conversation_master'] ?? '';
			if (!$_____________________ || !$______________________)
				exitRun(404, 'Conversation database is wrong!');
			if ($___________________ == $_____________________['user_id'] || $___________________ == $______________________['user_id'])
				$__________________ = false;
			else {
				$_______________________ = $______________________['recipients'];
				$_______________________ = json_decode($_______________________, true);
				foreach ($_______________________ as $________________________) {
					if ($________________________['user_id'] == $___________________) {
						$__________________ = false;
						break;
					}
				}
			}
		}
		if ($__________________)
			exitRun(403, 'Image access prohibited!');
	}
	$_________________________ = [
		'gif' => 'image/gif',
		'jpg' => 'image/jpeg',
		'jpeg' => 'image/jpeg',
		'jpe' => 'image/jpeg',
		'pjpeg' => 'image/pjpeg',
		'png' => 'image/png',
		'ico' => 'image/ico',
		'webp' => 'image/webp'
	];
	$__________________________ = strtolower(pathinfo($_____________, PATHINFO_EXTENSION));
	if (!isset($_________________________[$__________________________]))
		exitRun(400, 'File is not an image!');
	header('Cache-control: public, max-age=31536000');
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $______________) . ' GMT');
	header('ETag: "' . $______________ . '"');
	$___________________________ = $_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '';
	$____________________________ = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
	if (($___________________________ && strtotime($___________________________) >= $______________) || ($____________________________ && trim($____________________________) == $______________)) {
		http_response_code(304);
		exit();
	}
	header('Content-Transfer-Encoding: binary');
	header('Content-Disposition: inline; filename="' . $_____________ . '"');
	header('Content-Type: ' . $_________________________[$__________________________]);
	if (DEBUG)
		header('X-Memory-Usage: ' . byteConvert(memory_get_usage()));
	if (APACHE_X_SENDFILE) {
		header("X-Sendfile: $________________");
		exit();
	} else {
		if (!ob_get_level() && $_________________ <= 1048576) {
			header("Content-Length: $_________________");
			readfile($________________);
			exit();
		} else {
			$_____________________________ = 0;
			$______________________________ = $_________________;
			$_______________________________ = $_________________ - 1;
			if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $________________________________)) {
				if ($________________________________[1] != '')
					$_____________________________ = intval($________________________________[1]);
				if ($________________________________[2] != '')
					$_______________________________ = intval($________________________________[2]);
				if ($_____________________________ > $_______________________________ || $_____________________________ >= $_________________) {
					header("Content-Range: bytes */$_________________");
					http_response_code(416);
				}
				$______________________________ = $_______________________________ - $_____________________________ + 1;
				http_response_code(206);
				header("Content-Range: bytes $_____________________________-$_______________________________/$_________________");
				header("Content-Length: $______________________________");
			} else {
				http_response_code(200);
				header("Content-Length: $_________________");
			}
			header('Accept-Ranges: bytes');
			$_________________________________ = fopen($________________, 'rb');
			if (!$_________________________________)
				exitRun(500, 'Cannot open file for reading!');
			fseek($_________________________________, $_____________________________);
			while ($______________________________ > 0 && !feof($_________________________________)) {
				$__________________________________ = fread($_________________________________, min(32768, $______________________________));
				if ($__________________________________ === false || $__________________________________ === '')
					break;
				echo $__________________________________;
				$______________________________ -= strlen($__________________________________);
			}
			fclose($_________________________________);
			exit();
		}
	}
	exit();
}
function fastCSS()
{
	$__ = DIR . '/' . INTERNAL_DATA_PATH . '/css';
	$___ = trim(strval($_GET['css'] ?? ''));
	$____ = [];
	$____['s'] = intval($_GET['s'] ?? 0);
	$____['l'] = intval($_GET['l'] ?? 0);
	$____['d'] = intval($_GET['d'] ?? 0);
	$____['k'] = trim(strval($_GET['k'] ?? ''));
	$_____ = $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '';
	$______ = ($_____ && strpos($_____, 'gzip') !== false);
	$_______ = '';
	$________ = '';
	$_________ = '';
	$__________ = '';
	if ($___) {
		$_________ = md5($___);
		$_______ = $_________ . '-' . trim(implode('-', $____), "-");
		$_______ = str_replace(['/', '\\', '\'', '"', ':',  '*',  '?',   '<',  '>',  '|', "\0"], '', $_______);
		if (strlen($_______) >= 200)
			$_______ = substr($_______, 0, 195);
		$_______ .= '.css';
		$________ = "$__/$_______" . ($______ ? '.gz' : '');
	}
	if (!$________ || !is_file($________)) {
		require DIR . '/src/XF.php';
		\XF::start(DIR);
		$___________ = \XF::setupApp(XF\Pub\App::class, [
			'preLoad' => ['masterStyleModifiedDate', 'smilieSprites'],
		]);
		$____________ = $___________->cssWriter();
		$_____________ = $____________->run(($___ ? explode(',', $___) : []), $____['s'], $____['l'], $____['k']);
		$__________ = $_____________->body();
		if ($________ && trim($__________) != '@charset "UTF-8";') {
			$______________ = dirname($________);
			if (!is_dir($______________))
				mkdir($______________, 0775, true);
			if ($______)
				$__________ = gzencode($__________, 9);
			file_put_contents($________, $__________);
		} else {
			$_____________->send($___________->request());
			exit();
		}
	}
	if (!$________ || !is_file($________))
		exitRun(404, 'CSS cache file is not found!');
	$_______________ = $_________ . '-' . $____['s'] . '-' . $____['l'];
	$________________ = glob("$__/*");
	if (is_array($________________) && count($________________)) {
		$_________________ = time() - 86400;
		$__________________ = time() - 259200;
		foreach ($________________ as $___________________) {
			if (is_file($___________________)) {
				$____________________ = basename($___________________);
				if (stripos($____________________, $_______________) === 0) {
					if ($____________________ == $_______ || $____________________ == $_______ . '.gz' || filemtime($___________________) > $_________________)
						continue;
					unlink($___________________);
				} else if (filemtime($___________________) < $__________________)
					unlink($___________________);
			}
		}
	}
	$_____________________ = filesize($________);
	$______________________ = filemtime($________);
	$_______________________ = $______________________ . ($______ ? '-gzip' : '');
	header('Cache-control: public, max-age=31536000');
	header('Vary: Accept-Encoding');
	if ($______)
		header("Content-Encoding: gzip");
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $______________________) . ' GMT');
	header('ETag: "' . $_______________________ . '"');
	$________________________ = $_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '';
	$_________________________ = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
	if (($________________________ && strtotime($________________________) >= $______________________) || ($_________________________ && trim($_________________________) == $_______________________)) {
		http_response_code(304);
		exit();
	}
	header('Content-Disposition: inline; filename="' . $_______ . '"');
	header('Content-Type: text/css; charset=UTF-8');
	header("Content-Length: $_____________________");
	if (DEBUG)
		header('X-Memory-Usage: ' . byteConvert(memory_get_usage()));
	if ($__________) {
		echo $__________;
	} else if (!ob_get_level() && $_____________________ <= 1048576) {
		readfile($________);
		exit();
	} else {
		$__________________________ = fopen($________, 'rb');
		if (!$__________________________)
			exitRun(500, 'Cannot open file for reading!');
		while (!feof($__________________________)) {
			$___________________________ = fread($__________________________, 32768);
			if ($___________________________ === false || $___________________________ === '')
				break;
			echo $___________________________;
		}
		fclose($__________________________);
		exit();
	}
	exit();
}
if ($_ == 'image' && CACHE['image'])
	fastImage();
else if ($_ == 'css' && CACHE['css'])
	fastCSS();

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */