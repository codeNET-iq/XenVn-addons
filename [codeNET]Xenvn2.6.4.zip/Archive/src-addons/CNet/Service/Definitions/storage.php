<?php
/* Developed by CNet Tools */
define('CONNECTION_KEY_CODE', '');
define('STORAGE_FOLDER', '');
define('STORAGE_FOLDER_IN_PARENT_FOLDER', false);
define('APACHE_X_SENDFILE', false);
if (STORAGE_FOLDER_IN_PARENT_FOLDER)
	define('PATH', str_replace('\\', '/', dirname(__DIR__)) . '/' . ltrim(STORAGE_FOLDER, '/\\'));
else
	define('PATH', str_replace('\\', '/', __DIR__) . '/' . ltrim(STORAGE_FOLDER, '/\\'));
function createFile($_, $__ = '')
{
	if (is_file($_))
		return true;
	if (file_put_contents($_, $__) !== false)
		return true;
	return false;
}
function createDir($_)
{
	if (is_dir($_)) {
		if (is_writable($_))
			return true;
		return false;
	}
	mkdir($_, 0775, true);
	if (is_dir($_))
		return true;
	return false;
}
function exitRun($_, $__ = '')
{
	header('Content-type: text/plain; charset=utf-8');
	header('Cache-Control: private, no-cache, max-age=0');
	http_response_code($_);
	if ($__)
		echo $__;
	exit();
}
function processKey($_)
{
	$__ = strlen($_);
	if ($__ == 16)
		return $_;
	else if ($__ < 16)
		return substr($_ . str_repeat("\0", 16), 0, 16);
	else
		return substr($_, 0, 16);
}
function explodeData($_)
{
	$_ = strval(rawurldecode(trim($_)));
	$__ = processKey(CONNECTION_KEY_CODE);
	if ($_)
		$_ = openssl_decrypt($_, "AES-128-ECB", $__);
	if (!$_)
		exitRun(400, 'Error decrypting data!');
	$_ = explode('|', $_);
	$___ = intval($_[0] ?? 0);
	$____ = strval($_[1] ?? '');
	$_____ = strval($_[2] ?? '');
	if (!$____)
		exitRun(400, 'Error file path!');
	$______ = round(time() / 60) * 60;
	if ($___ && ($___ < ($______ - 600) || $___ > ($______ + 60)))
		exitRun(410, 'Link expired!');
	return [$___, $____, $_____];
}
function byteConvert($_)
{
	if ($_ <= 0)
		return '0B';
	$__ = ['B', 'K', 'M', 'G'];
	$___ = min(floor(log($_, 1024)), count($__) - 1);
	$_ /= pow(1024, $___);
	return  round($_) . $__[$___];
}
function checkSetup()
{
	[$_, $__] = explodeData($_GET['setup']);
	if ($__ != 'setup')
		exitRun(400, 'Invalid query!');
	header('Content-type: text/plain; charset=utf-8');
	header('Cache-Control: private, no-cache, max-age=0');
	$___ = ['curl_version', 'openssl_encrypt', 'openssl_decrypt', 'md5_file', 'fread', 'fopen'];
	$____ = [];
	foreach ($___ as $_____) {
		if (!function_exists($_____))
			$____[] = $_____;
	}
	$______ = ['RecursiveIteratorIterator', 'RecursiveDirectoryIterator'];
	foreach ($______ as $_______) {
		if (!class_exists($_______))
			$____[] = $_______;
	}
	if (count($____)) {
		echo '- [Error] Class requirements: ' . implode(', ', $____);
		$____ = [];
	}
	$________ = str_replace('\\', '/', __DIR__) . '/index.php';
	if (!is_file($________)) {
		$________ = str_replace('\\', '/', __DIR__) . '/index.html';
		if (!createFile($________))
			$____[] = '- [Error] Unable to create file: ' . $________ . ' (Need to manually create an empty file named "index.html" at the requested path)';
	}
	$________ = PATH;
	if (!createDir($________))
		$____[] = '- [Error] Unable to create or access directory: ' . $________ . ' (Need to manually create a folder named "' . STORAGE_FOLDER . '" at the requested path and Chmod 777 permissions)';
	if (!count($____)) {
		$________ = PATH . '/' . 'index.html';
		if (!createFile($________))
			$____[] = '- [Error] Unable to create file: '  . $________ . ' (Requires Chmod 777 permissions for the parent directory named "' . STORAGE_FOLDER . '")';
		$________ = PATH . '/' . '.htaccess';
		if (!createFile($________, "Order deny,allow\nDeny from all\n"))
			$____[] = '- [Error] Unable to create file: ' . $________ . ' (Requires Chmod 777 permissions for the parent directory named "' . STORAGE_FOLDER . '")';
	}
	if (count($____))
		echo implode("\n", $____);
	else
		echo 'Setup complete!';
	echo "\n\nServer Info:\n";
	echo '- phpVersion: ' . phpversion() . "\n";
	echo '- memory_limit: ' . ini_get('memory_limit') . "\n";
	echo '- memory_get_usage: ' . byteConvert(memory_get_usage()) . "\n";
	echo '- post_max_size: ' . ini_get('post_max_size') . "\n";
	echo '- upload_max_filesize: ' . ini_get('upload_max_filesize') . "\n";
	echo '- max_execution_time: ' . ini_get('max_execution_time') . "\n";
	echo '- curl_version: ' . (function_exists('curl_version') ? curl_version()['version'] : '') . "\n";
	echo '- ssl_version: ' . (function_exists('curl_version') ? curl_version()['ssl_version'] : '') . "\n";
	echo '- openssl_version: ' . (defined('OPENSSL_VERSION_TEXT') ? OPENSSL_VERSION_TEXT : '') . "\n";
	echo '- timezone: ' . ini_get('date.timezone') . "\n";
	$_________ = "/";
	$__________ = realpath('.');
	$___________ = ini_get('open_basedir');
	if ($___________) {
		$____________ = explode(PATH_SEPARATOR, $___________);
		foreach ($____________ as $_____________) {
			$______________ = realpath($_____________);
			if ($______________ && stripos($__________, $______________) === 0) {
				$_________ = $______________;
				break;
			}
		}
	}
	echo '- current_directory: ' . $__________ . "\n";
	echo '- storage_directory: ' . realpath(PATH) . "\n";
	echo '- disk_total_space: ' . (function_exists('disk_total_space') ? byteConvert(disk_total_space($_________)) : '') . "\n";
	echo '- disk_free_space: ' . (function_exists('disk_free_space') ? byteConvert(disk_free_space($_________)) : '') . "\n";
}
function downloadFile()
{
	[$_, $__, $___] = explodeData($_GET['download']);
	if (!$___)
		$___ = 'download.data';
	$__ = PATH . '/' . trim($__, "\\/");
	if (!is_file($__))
		exitRun(404, 'File not found!');
	$____ = filesize($__);
	if (!isset($_GET['redirect']) || isset($_POST['submit'])) {
		$_____ = strtolower(pathinfo($___, PATHINFO_EXTENSION));
		if (strpos($_____, 'php') === 0)
			exitRun(400, 'File is forbidden!');
		$______ = [
			'gif' => 'image/gif',
			'jpg' => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'jpe' => 'image/jpeg',
			'pjpeg' => 'image/pjpeg',
			'png' => 'image/png',
			'ico' => 'image/ico',
			'webp' => 'image/webp',
			'm4v' => 'video/mp4',
			'mov' => 'video/quicktime',
			'mp4' => 'video/mp4',
			'mp4v' => 'video/mp4',
			'mpeg' => 'video/mpeg',
			'mpg' => 'video/mpeg',
			'ogv' => 'video/ogg',
			'webm' => 'video/webm',
			'mp3' => 'audio/mpeg',
			'opus' => 'audio/ogg',
			'ogg' => 'audio/ogg',
			'wav' => 'audio/wav'
		];
		$_______ = (!$_ && isset($______[$_____])) ? $______[$_____] : 'application/octet-stream';
		$________ = ($_______ == 'application/octet-stream');
		$_________ = filemtime($__);
		$__________ = gmdate('D, d M Y H:i:s', $_________) . ' GMT';
		header('Cache-control: ' . (($_ || $________) ? 'private, no-cache, max-age=0' : 'public, max-age=31536000'));
		header("Last-Modified: $__________");
		header('ETag: "' . $_________ . '"');
		$___________ = $_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '';
		$____________ = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
		if (($___________ && strtotime($___________) == $_________) || ($____________ && trim($____________) == $_________)) {
			http_response_code(304);
			exit();
		}
		header('Content-Transfer-Encoding: binary');
		header('Content-Disposition: ' . ($________ ? 'attachment' : 'inline') . '; filename="' . $___ . '"');
		header("Content-Type: $_______");
		header('Content-MD5: ' . md5_file($__));
		if (APACHE_X_SENDFILE) {
			header("X-Sendfile: $__");
			exit();
		} else {
			if (!ob_get_level() && $____ <= 1048576) {
				header("Content-Length: $____");
				readfile($__);
				exit();
			} else {
				$_____________ = 0;
				$______________ = $____;
				$_______________ = $____ - 1;
				if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $________________)) {
					if ($________________[1] != '')
						$_____________ = intval($________________[1]);
					if ($________________[2] != '')
						$_______________ = intval($________________[2]);
					if ($_____________ > $_______________ || $_____________ >= $____) {
						header("Content-Range: bytes */$____");
						http_response_code(416);
						exit();
					}
					$______________ = $_______________ - $_____________ + 1;
					http_response_code(206);
					header("Content-Range: bytes $_____________-$_______________/$____");
					header("Content-Length: $______________");
				} else {
					http_response_code(200);
					header("Content-Length: $____");
				}
				header('Accept-Ranges: bytes');
				$_________________ = fopen($__, 'rb');
				if (!$_________________)
					exitRun(500, 'Cannot open file for reading!');
				fseek($_________________, $_____________);
				while ($______________ > 0 && !feof($_________________)) {
					$__________________ = fread($_________________, min(32768, $______________));
					if ($__________________ === false || $__________________ === '')
						break;
					echo $__________________;
					$______________ -= strlen($__________________);
				}
				fclose($_________________);
				exit();
			}
		}
	} else {
		$___________________ = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" media="(prefers-color-scheme: light)" content="#CFE4F2"><meta name="theme-color" media="(prefers-color-scheme: dark)" content="#121212"><title>[[title]]</title><meta name="description" content="Download [[title]] | [[domain]]"><style>:root{--cnet-primary:#1f6da5;--cnet-primary-hover:#185886;--cnet-bg:#f5f7fa;--cnet-bg-gradient:radial-gradient(circle at center, #F7FBFD, #CFE4F2);--cnet-card:#ffffff;--cnet-text:#2c3e50;--cnet-border:#d8dde4;--cnet-input-bg:#f9fafb;--cnet-footer:#707070}@media (prefers-color-scheme:dark){:root{--cnet-primary:#1D79B9;--cnet-primary-hover:#1868A0;--cnet-bg:#181b1f;--cnet-bg-gradient:radial-gradient(circle at center, #1c2e40, #121212);--cnet-card:#23272e;--cnet-text:#e5e7eb;--cnet-border:#3b4149;--cnet-input-bg:#2b3138;--cnet-footer:#7D7D7D}}*{box-sizing:border-box}body,html{margin:0;min-height:100%}body{background:var(--cnet-bg);background:var(--cnet-bg-gradient);color:var(--cnet-text);font:14px/1.5 sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;height:100vh}header{margin-bottom:20px;text-align:center}main{width:100%;max-width:460px}footer{margin-top:20px;font-size:12px;color:var(--cnet-footer);text-align:center}.download-box{width:100%;background:var(--cnet-card);border:1px solid var(--cnet-border);border-radius:10px;padding:16px;box-shadow:0 2px 10px rgba(0,0,0,.05)}.download-title{margin:0 0 12px;text-align:center;font-size:15px;font-weight:600}.download-row{display:flex;gap:10px}.filename{flex:1;min-width:0;padding:10px 12px;border:1px solid var(--cnet-border);border-radius:6px;background:var(--cnet-input-bg);color:var(--cnet-text);font-size:14px;text-overflow:ellipsis}.download-btn{appearance:none;border:0;border-radius:6px;min-width:110px;padding:10px 16px;background:var(--cnet-primary);color:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:background-color .3s ease}.download-btn:hover{background:var(--cnet-primary-hover)}.download-btn:active{transform:translateY(1px)}.main-title{font-size:20px;margin:0;color:var(--cnet-primary)}@media (max-width:480px){.download-row{flex-direction:column}.download-btn{width:100%}}</style></head><body><header><h1 class="main-title">Welcome to [[domain]]</h1></header><main><form method="post" class="download-box"><div class="download-title">Ready to download</div><div class="download-row"><input class="filename" type="text" name="filename" value="[[title]]" title="Download [[title]]" disabled> <button class="download-btn" name="submit" type="submit" title="Click to download">Download</button></div></form></main><footer>© [[domain]] &#183; All rights reserved.</footer></body></html>';
		$___ .= ' (' . byteConvert($____) . ')';
		$____________________ = $_SERVER['SERVER_NAME'];
		header('Content-type: text/html; charset=utf-8');
		header('Cache-Control: private, no-cache, max-age=0');
		$___________________ = str_replace(['[[title]]', '[[domain]]'], [$___, $____________________], $___________________);
		echo $___________________;
		exit();
	}
}
function checkChunk()
{
	[$_, $__] = explodeData($_GET['chunk']);
	$___ = PATH . '/' . rtrim($__, "\\/") . '.part';
	$____ = 0;
	if (is_file($___))
		$____ = filesize($___);
	header("X-Upload-Offset: $____");
	header('Accept-Ranges: bytes');
	exitRun(200);
}
function uploadFile()
{
	[$_, $__, $___] = explodeData($_GET['upload']);
	$__ = PATH . '/' . rtrim($__, "\\/");
	$____ = dirname($__);
	if (!createDir($____))
		exitRun(400, 'Unable to create / access directory: ' . $____);
	$_____ = intval($_SERVER['HTTP_X_OFFSET'] ?? 0);
	$______   = intval($_SERVER['HTTP_X_TOTALSIZE'] ?? 0);
	$_______ = $__ . '.part';
	$________ = fopen('php://input', 'rb');
	$_________ = fopen($_______, 'c+b');
	if (!$_________) {
		fclose($________);
		exitRun(500, 'Cannot open file for writing!');
	}
	if (!flock($_________, LOCK_EX | LOCK_NB)) {
		fclose($________);
		fclose($_________);
		exitRun(423, 'File is locked!');
	}
	if (ob_get_level())
		ob_end_clean();
	fseek($_________, $_____);
	while (!feof($________)) {
		$__________ = fread($________, 32768);
		if ($__________ === false || $__________ === '')
			break;
		fwrite($_________, $__________);
	}
	flock($_________, LOCK_UN);
	fclose($________);
	fclose($_________);
	if (!is_file($_______))
		exitRun(500, 'File save failed!');
	if (filesize($_______) >= $______ && $______ > 0) {
		rename($_______, $__);
		clearstatcache(true, $__);
		if (!is_file($__))
			exitRun(500, 'File save failed!');
		if (md5_file($__) != $___) {
			unlink($__);
			exitRun(400, 'MD5 codes do not match!');
		}
		exitRun(200, 'ok');
	}
	exitRun(200, 'ok');
}
function deleteFile()
{
	[$_, $__] = explodeData($_GET['delete']);
	$__ = PATH . '/' . rtrim($__, "\\/");
	if (is_file($__)) {
		if (unlink($__)) {
			header('X-File-Deleted: true');
			exitRun(200);
		} else
			exitRun(500, 'Error deleting file!');
	}
	exitRun(200);
}
function cleanFiles()
{
	[$_, $__] = explodeData($_GET['clean']);
	$___ = PATH;
	if (!is_dir($___))
		exitRun(404, 'Directory does not exist!');
	if ($__ != 'clean')
		exitRun(400, 'Invalid query!');
	$____ = time() - 3600;
	$_____ = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($___ . '/', FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_PATHNAME | FilesystemIterator::KEY_AS_PATHNAME), RecursiveIteratorIterator::LEAVES_ONLY);
	$______ = 0;
	foreach ($_____ as $_______) {
		$________ = strtolower(substr(strrchr($_______, '.'), 1));
		if ($________ == 'part') {
			if (filemtime($_______) <= $____) {
				if (!unlink($_______))
					$______++;
			}
		}
	}
	if ($______)
		exitRun(500, 'Error deleting file!');
	exitRun(200);
}
if (isset($_GET['setup']))
	checkSetup();
else if (isset($_GET['download']))
	downloadFile();
else if (isset($_GET['chunk']))
	checkChunk();
else if (isset($_GET['upload']))
	uploadFile();
else if (isset($_GET['delete']))
	deleteFile();
else if (isset($_GET['clean']))
	cleanFiles();
else {
	exitRun(200, 'Welcome to ' . $_SERVER['SERVER_NAME']);
	exit();
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */