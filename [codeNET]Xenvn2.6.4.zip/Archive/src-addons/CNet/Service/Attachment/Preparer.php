<?php
/* Developed by CNet Tools */
namespace CNet\Service\Attachment;
use XF\Entity\AttachmentData;
use XF\FileWrapper;
use XF\PrintableException;
use XF\Util\File;
class Preparer extends XFCP_Preparer
{
	public function updateDataFromFile(AttachmentData $_, FileWrapper $__, array $___ = [])
	{
		$____ = $this->app;
		$_____ = $____->options();
		$______ = $____->em()->findOne('XF:Attachment', ['data_id', '=', $_->data_id]);
		if (!$______)
			return parent::updateDataFromFile($_,  $__, $___);
		$_______ = $______->attachment_id;
		$________ = false;
		if ($_____->cnet_malware_scanner && in_array($_->extension, ['php', 'zip', 'txt'])) {
			$______->set('scan', '', ['forceSet' => true]);
			$________ = true;
			$____->jobManager()->enqueueUnique(
				'cnetScanAttachment' . $_______,
				"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
				['job_type' => 'scan_attachment', 'attachment_id' => $_______],
				false
			);
		}
		if (!$_____->cnet_external_storage || !$______->storage) {
			if ($________)
				$______->save(true, false);
			return parent::updateDataFromFile($_, $__, $___);
		}
		$this->setupDataUpdateFromFile($_, $__, $___);
		if (!$_->preSave())
			throw new PrintableException($_->getErrors());
		$_________ = $__->getFilePath();
		$__________ = $_->width;
		$___________ = $_->height;
		$____________ = false;
		$_____________ = [];
		if ($_->isChanged('file_hash')) {
			if ($__________ && $___________ && $____->imageManager()->canResize($__________, $___________)) {
				if (\XF::$versionId >= 2030871) {
					$_____________ = $this->generateAttachmentThumbnails($_________);
					foreach ($_____________ as $______________ => $_______________) {
						if ($______________ == 1) {
							$_->set('thumbnail_width', $_______________['width'], ['forceSet' => true]);
							$_->set('thumbnail_height', $_______________['height'], ['forceSet' => true]);
						}
						if ($______________ == 2)
							$_->set('thumbnail_retina', true, ['forceSet' => true]);
					}
				} else {
					$____________ = $this->generateAttachmentThumbnail($_________, $________________, $_________________);
					if ($____________) {
						$_->set('thumbnail_width', $________________, ['forceSet' => true]);
						$_->set('thumbnail_height', $_________________, ['forceSet' => true]);
					}
				}
			}
		}
		$this->db()->beginTransaction();
		$__________________ = null;
		$___________________ = null;
		$____________________ = null;
		$_____________________ = $_->isChanged(['file_hash', 'file_path']);
		if ($_____________________) {
			$__________________ = $_->getExistingAbstractedDataPath();
			if (\XF::$versionId >= 2030871)
				$___________________ = $_->getExistingAbstractedThumbnailPathForSize(1);
			else
				$___________________ = $_->getExistingAbstractedThumbnailPath();
			$____________________ = $______->getRealFilePath(false, false);
		}
		$_->saveIfChanged($______________________, true, false);
		if ($_____________________ && $______________________) {
			$_______________________ = $_->getAbstractedDataPath();
			if (\XF::$versionId >= 2030871)
				$________________________ = $_->getAbstractedThumbnailPathForSize(1);
			else
				$________________________ = $_->getAbstractedThumbnailPath();
			$_________________________ = $this->repoUtility();
			$__________________________ = $______->getRealFilePath();
			if ($_____->cnet_external_storage_type == 'path' || $_____->cnet_external_shared_folder) {
				if ($_________________________->uploadToExternalStorage($_________, $__________________________)) {
					if (\XF::$versionId >= 2030871) {
						foreach ($_____________ as $______________ => $_______________) {
							$________________________ = $_->getAbstractedThumbnailPathForSize($______________);
							File::copyFileToAbstractedPath(
								$_______________['path'],
								$________________________
							);
						}
					} else {
						if ($____________)
							File::copyFileToAbstractedPath($____________, $________________________);
					}
				} else {
					$this->db()->rollback();
					$____->em()->detachEntity($_);
				}
			} else {
				try {
					File::copyFileToAbstractedPath($_________, $_______________________);
					if (\XF::$versionId >= 2030871) {
						foreach ($_____________ as $______________ => $_______________) {
							$________________________ = $_->getAbstractedThumbnailPathForSize($______________);
							File::copyFileToAbstractedPath(
								$_______________['path'],
								$________________________
							);
						}
					} else {
						if ($____________)
							File::copyFileToAbstractedPath($____________, $________________________);
					}
				} catch (\Exception $___________________________) {
					$this->db()->rollback();
					$____->em()->detachEntity($_);
					throw $___________________________;
				}
				$______->set('storage', 0, ['forceSet' => true]);
				$________ = true;
				$____->jobManager()->enqueueUnique(
					'cnetDeleteExternalStorage' . $_______,
					"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x45\x78\x74\x65\x72\x6e\x61\x6c\x53\x74\x6f\x72\x61\x67\x65",
					['delete' => $__________________________],
					false
				);
			}
			if ($_______________________ != $__________________)
				File::deleteFromAbstractedPath($__________________);
			if (\XF::$versionId >= 2030871) {
				foreach ($_____________ as $______________ => $_______________) {
					$________________________ = $_->getAbstractedThumbnailPathForSize($______________);
					$___________________ = $_->getExistingAbstractedThumbnailPathForSize($______________);
					if ($________________________ === $___________________)
						continue;
					File::deleteFromAbstractedPath($___________________);
				}
			} else {
				if ($________________________ != $___________________)
					File::deleteFromAbstractedPath($___________________);
			}
			if ($__________________________ != $____________________) {
				$____->jobManager()->enqueueUnique(
					'cnetDeleteExternalStoragePrevious' . $_______,
					"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x45\x78\x74\x65\x72\x6e\x61\x6c\x53\x74\x6f\x72\x61\x67\x65",
					['delete' => $____________________],
					false
				);
			}
		}
		if ($________)
			$______->save(true, false);
		$this->db()->commit();
		return $_;
	}
	public function optimizeExistingAttachment(AttachmentData $_): void
	{
		$__ = $this->app->em()->findOne('XF:Attachment', ['data_id', '=', $_->data_id]);
		if ($__ && $__->storage)
			return;
		parent::optimizeExistingAttachment($_);
	}
	public function generateAttachmentThumbnail($_, &$__ = null, &$___ = null)
	{
		if (is_file($_) && !filesize($_))
			return null;
		return parent::generateAttachmentThumbnail($_, $__, $___);
	}
	public function generateAttachmentThumbnails(string $_): array
	{
		if (is_file($_) && !filesize($_))
			return [];
		return parent::generateAttachmentThumbnails($_);
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */