<?php
/* Developed by CNet Tools */
namespace CNet\Service;
use XF\Service\AbstractService;
class Seo extends AbstractService
{
	protected $_ = [];
	protected $__ = 0;
	protected $___ = '';
	protected $____ = '';
	public function getResults()
	{
		$this->checkHTTPS();
		$this->checkHeader();
		$this->checkPHP();
		$this->checkCache();
		$this->checkPWA();
		$this->checkCacheFile();
		$this->checkOptions();
		$this->checkOpenGraph();
		$this->checkHTMLHead();
		return $this->_;
	}
	public function getDebug()
	{
		return $this->____;
	}
	public function getDone()
	{
		return '(' . $this->__ . '/' . count($this->_) . ')';
	}
	protected function checkHTTPS()
	{
		$_____ = ' [<a target="_blank" href="' . $this->app->router('admin')->buildLink('full:options/boardUrl/view') . '">?</a>]';
		$______ = $this->app->options()->boardUrl;
		if (strpos($______, 'https://') === 0 && (isset($_SERVER['HTTPS']) || isset($_SERVER['HTTP_X_FORWARDED_PROTO']))) {
			$this->__++;
			$this->_[] = '[HTTPS] <span style="color:green">' . $______ . '</span>' . $_____;
		} else {
			$this->_[] = '[HTTPS] <span style="color:red">' . $______ . '</span>' . $_____;
		}
	}
	protected function checkHeader()
	{
		$_____ = $this->app->router('public')->buildLink('canonical:index');
		$______ = $this->repoUtility();
		[$_______, $____, $________] = $______->getCurl($_____, 'verbose', '', 0, false);
		if ($________) {
			$this->app->error()->logError($________);
			return [];
		}
		$this->___ = $_______;
		$this->____ = "----- Debugs -----\n\n" . $____;
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://www.cloudflare.com/learning/ssl/why-use-tls-1.3/">?</a>]';
		if (preg_match('/SSL connection.+1\.(\d)/i', $____, $___________)) {
			$_______ =  $___________[0];
			if ($___________[1] >= 2) {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[TLS] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[TLS] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://www.cloudflare.com/learning/ssl/what-is-an-ssl-certificate/">?</a>]';
		if (preg_match('/ssl certificate.+(ok|problem)/i', $____, $___________)) {
			$_______ =  $___________[0];
			if (($___________[1]) == 'ok') {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[SSL] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[SSL] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://web.dev/articles/performance-http2">?</a>]';
		if (preg_match('/using http.*\/(\d).*/i', $____, $___________)) {
			$_______ =  $___________[0];
			if ($___________[1] >= 2) {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[Protocols] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[Protocols] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://developer.chrome.com/docs/lighthouse/seo/http-status-code">?</a>]';
		if (preg_match('/http\/\d(\.\d)?\s+([\d]{3})/i', $____, $___________)) {
			$_______ =  $___________[0];
			if ($___________[2] == 200) {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[HTTP-Status-Code] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[HTTP-Status-Code] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Set-Cookie">?</a>]';
		if (preg_match('/set-cookie:.+__secure-(.+)/i', $____, $___________)) {
			$_______ =  $___________[0];
			$____________ = $___________[1];
			if (stripos($____________, 'httponly') !== FALSE && stripos($____________, 'secure') !== FALSE && (stripos($____________, 'samesite=strict') !== FALSE || stripos($____________, 'samesite=lax') !== FALSE)) {
				$this->__++;
				$_________ = true;
			}
		} else if (preg_match('/set-cookie:.+/i', $____, $___________)) {
			$_______ = $___________[0];
		}
		if ($_________) {
			$this->_[] = '[Cookie-Secure] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[Cookie-Secure] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Encoding">?</a>]';
		if (preg_match('/content-encoding:.+/i', $____, $___________)) {
			$this->__++;
			$_________ = true;
			$_______ =  $___________[0];
		}
		if ($_________) {
			$this->_[] = '[Compress] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[Compress] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Strict-Transport-Security">?</a>]';
		if (preg_match('/strict-transport-security:.+max-age=(\d+).*/i', $____, $___________)) {
			$_______ = $___________[0];
			if ($___________[1] >= 15552000) {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[HSTS] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[HSTS] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Content-Type-Options">?</a>]';
		if (preg_match('/x-content-type-options:.+/i', $____, $___________)) {
			$_______ = $___________[0];
			if (strpos($_______, 'nosniff') !== false) {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[MIME Sniffing] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[MIME Sniffing] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
		$_________ = false;
		$_______ = 'Not configured';
		$__________ = ' [<a target="_blank" href="https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP">?</a>]';
		if (preg_match('/content-security-policy:.+/i', $____, $___________)) {
			$_______ = $___________[0];
			if (strpos($_______, 'default-src') !== false) {
				$this->__++;
				$_________ = true;
			}
		}
		if ($_________) {
			$this->_[] = '[CSP] <span style="color:green">' . $_______ . '</span>' . $__________;
		} else {
			$this->_[] = '[CSP] <span style="color:red">' . $_______ . '</span>' . $__________;
		}
	}
	protected function getHeader($_____)
	{
		$______ = $this->repoUtility();
		[$_______, $________] = $______->getCurl($_____, 'header', '', 5, false);
		if ($________) {
			$this->app->error()->logError($________);
			return [];
		} else
			return $______->toArray($_______);
	}
	protected function checkPHP()
	{
		$_____ = ' [<a target="_blank" href="https://www.php.net/releases/8.0/en.php">?</a>]';
		$______ = phpversion();
		if (version_compare($______, '8.0.0', '>=')) {
			$this->__++;
			$this->_[] = '[PHP-Version] <span style="color:green">Version: ' . $______ . '</span>' . $_____;
		} else {
			$this->_[] = '[PHP-Version] <span style="color:red">Version: ' . $______ . '</span>' . $_____;
		}
		$_____ = ' [<a target="_blank" href="https://www.php.net/manual/en/book.opcache.php">?</a>]';
		$______ = false;
		if (function_exists('opcache_get_configuration')) {
			$______ = opcache_get_configuration();
		}
		if ($______ && $______['directives']['opcache.enable']) {
			$this->__++;
			$this->_[] = '[PHP-OPcache] <span style="color:green">Enabled, version: ' . $______['version']['version'] . '</span>' . $_____;
		} else {
			$this->_[] = '[PHP-OPcache] <span style="color:red">Not configured</span>' . $_____;
		}
	}
	protected function checkCache()
	{
		$config = $this->app->config();
		$_____ = ' [<a target="_blank" href="https://xenforo.com/docs/xf2/cache/">?</a>]';
		if ($config['cache']['enabled']) {
			$this->__++;
			$this->_[] = '[XF-Cache] <span style="color:green">Providers: ' . $config['cache']['provider'] . '</span>' . $_____;
		} else {
			$this->_[] = '[XF-Cache] <span style="color:red">Not configured</span>' . $_____;
		}
		if ($config['pageCache']['enabled'] && isset($config['cache']['context']['page']['provider'])) {
			$this->__++;
			$this->_[] = '[XF-Guest-Cache] <span style="color:green">>Providers: ' . $config['cache']['context']['page']['provider'] . '</span>' . $_____;
		} else {
			$this->_[] = '[XF-Guest-Cache] <span style="color:red">Not configured</span>' . $_____;
		}
	}
	protected function checkPWA()
	{
		$_____ = $this->app->repository('XF:PWA');
		$______ = $_____->isInstallable();
		$_______ = ' [<a target="_blank" href="' . $this->app->router('admin')->buildLink('full:pwa/') . '">?</a>]';
		if ($______) {
			$this->__++;
			$this->_[] = '[XF-PWA] <span style="color:green">Installable</span>' . $_______;
		} else {
			$this->_[] = '[XF-PWA] <span style="color:red">Not configured</span>' . $_______;
		}
	}
	protected function checkCacheFile()
	{
		$_____ = $this->app->options()->boardUrl;
		$______ = ' [<a target="_blank" href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/cache-control">?</a>]';
		$_______ = false;
		$________ = 'Not configured';
		$_________ = $this->getHeader($_____ . "\x2f\x6a\x73\x2fCNet\x2f\x6f\x70\x74\x69\x6d\x61\x6c\x2e\x6d\x69\x6e\x2e\x6a\x73\x3f\x5f\x76\x3d" . $this->app['jsVersion']);
		foreach ($_________ as $__________) {
			if (stripos($__________, 'cache-control:') !== FALSE) {
				$________ = $__________;
				if (stripos($__________, 'public') !== FALSE && preg_match('/max-age=(\d+)/i', $__________, $___________)) {
					if ($___________[1] >= 15552000) {
						$this->__++;
						$_______ = true;
					}
				}
			}
		}
		if ($_______) {
			$this->_[] = '[JS-Cache] <span style="color:green">' . $________ . '</span>' . $______;
		} else {
			$this->_[] = '[JS-Cache] <span style="color:red">' . $________ . '</span>' . $______;
		}
		$_______ = false;
		$________ = 'Not configured';
		$____________ = $this->app->options()->defaultStyleId;
		$_____________ = $this->app->style($____________);
		$______________ = '/css.php?css=public%3Acnet_css.less&d=' . $_____________->getLastModified();
		$_________ = $this->getHeader($_____ . $______________);
		foreach ($_________ as $__________) {
			if (stripos($__________, 'cache-control:') !== FALSE) {
				$________ = $__________;
				if (stripos($__________, 'public') !== FALSE && preg_match('/max-age=(\d+)/i', $__________, $___________)) {
					if ($___________[1] >= 15552000) {
						$this->__++;
						$_______ = true;
					}
				}
			}
		}
		if ($_______) {
			$this->_[] = '[CSS-Cache] <span style="color:green">' . $________ . '</span>' . $______;
		} else {
			$this->_[] = '[CSS-Cache] <span style="color:red">' . $________ . '</span>' . $______;
		}
		$_______ = false;
		$________ = 'Not configured';
		$_________ = $this->getHeader($_____ . "\x2f\x73\x74\x79\x6c\x65\x73\x2fCNet\x2f\x6e\x6f\x2d\x69\x6d\x61\x67\x65\x2e\x77\x65\x62\x70");
		foreach ($_________ as $__________) {
			if (stripos($__________, 'cache-control:') !== FALSE) {
				$________ = $__________;
				if (stripos($__________, 'public') !== FALSE && preg_match('/max-age=(\d+)/i', $__________, $___________)) {
					if ($___________[1] >= 15552000) {
						$this->__++;
						$_______ = true;
					}
				}
			}
		}
		if ($_______) {
			$this->_[] = '[IMG-Cache] <span style="color:green">' . $________ . '</span>' . $______;
		} else {
			$this->_[] = '[IMG-Cache] <span style="color:red">' . $________ . '</span>' . $______;
		}
		$_______ = false;
		$________ = 'Not configured';
		if (\XF::$versionId >= 2030035) {
			$______________ = $_____ . '/' . 'styles/fa/solid/caret-down.svg';
		} else {
			$______________ = $_____ . '/' . 'styles/fonts/fa/fa-regular-400.woff';
		}
		$_________ = $this->getHeader($______________);
		foreach ($_________ as $__________) {
			if (stripos($__________, 'cache-control:') !== FALSE) {
				$________ = $__________;
				if (stripos($__________, 'public') !== FALSE && preg_match('/max-age=(\d+)/i', $__________, $___________)) {
					if ($___________[1] >= 15552000) {
						$this->__++;
						$_______ = true;
					}
				}
			}
		}
		if ($_______) {
			$this->_[] = '[SVG/WOFF-Cache] <span style="color:green">' . $________ . '</span>' . $______;
		} else {
			$this->_[] = '[SVG/WOFF-Cache] <span style="color:red">' . $________ . '</span>' . $______;
		}
		$_______ = false;
		$________ = 'Not configured';
		$_______________ = $this->finder('XF:Attachment')
			->where([['content_type', '=', 'post'], ['unassociated', '<>', true], ['Data.width', '<>', ''], ['Data.height', '<>', '']])
			->fetchOne();
		if ($_______________) {
			$______________ = $this->app->router('public')->buildLink('full:attachments', $_______________);
			$_________ = $this->getHeader($______________);
			foreach ($_________ as $__________) {
				if (stripos($__________, 'cache-control:') !== FALSE) {
					$________ = $__________;
					if (stripos($__________, 'public') !== FALSE && preg_match('/max-age=(\d+)/i', $__________, $___________)) {
						if ($___________[1] >= 15552000) {
							$this->__++;
							$_______ = true;
						}
					}
				}
			}
		}
		if ($_______) {
			$this->_[] = '[Attachment-IMG-Cache] <span style="color:green">' . $________ . '</span>' . $______;
		} else {
			$this->_[] = '[Attachment-IMG-Cache] <span style="color:red">' . $________ . '</span>' . $______;
		}
	}
	protected function checkOptions()
	{
		$_____ = ['boardUrlCanonical', 'useFriendlyUrls', 'romanizeUrls', 'includeTitleInUrls', 'imageOptimization', 'imageLinkProxy', 'cnet_optimal_meta_data', 'cnet_view_all_image', 'cnet_minify_html_code'];
		$_ = $this->app->finder('XF:Option')->whereIds($_____)->fetch()->sortByList($_____);
		foreach ($_ as $______) {
			$_______ = $______->option_value;
			$________ = ' [<a target="_blank" href="' . $this->app->router('admin')->buildLink('full:options/' . $______->option_id . '/view') . '">?</a>]';
			if (is_array($_______)) {
				foreach ($_______ as $_________) {
					if (!$_________) {
						$_______ = 0;
						break;
					}
				}
				if ($_______ !== 0)
					$_______ = 1;
			}
			if ($_______) {
				$this->__++;
				$this->_[] = '[Options] <span style="color:green">' . $______->getTitle() . ': ' . $_______ . '</span>' . $________;
			} else {
				$this->_[] = '[Options] <span style="color:red">' . $______->getTitle() . ': ' . $_______ . '</span>' . $________;
			}
		}
	}
	protected function checkOpenGraph()
	{
		$___ = $this->___;
		$_____ = ' [<a target="_blank" href="https://ogp.me/">?</a>]';
		if (preg_match('/<.+og:title.+content=[\'"](.+)[\'"].*>/iU', $___, $______)) {
			$_______ = htmlentities($______[1]);
			$this->__++;
			$this->_[] = '[OG:Title] <span style="color:green">' . $_______ . '</span>' . $_____;
		} else {
			$this->_[] = '[OG:Title] <span style="color:red">Not configured</span>' . $_____;
		}
		if (preg_match('/<.+og:type.+content=[\'"](.+)[\'"].*>/iU', $___, $______)) {
			$this->__++;
			$this->_[] = '[OG:Type] <span style="color:green">' . $______[1] . '</span>' . $_____;
		} else {
			$this->_[] = '[OG:Type] <span style="color:red">Not configured</span>' . $_____;
		}
		if (preg_match('/<.+og:image.+content=[\'"](https.+)[\'"].*>/iU', $___, $______)) {
			$this->__++;
			$this->_[] = '[OG:Image] <span style="color:green">' . $______[1] . '</span>' . $_____;
		} else {
			$this->_[] = '[OG:Image] <span style="color:red">Not configured</span>' . $_____;
		}
		if (preg_match('/<.+og:url.+content=[\'"](https.+)[\'"].*>/iU', $___, $______)) {
			$this->__++;
			$this->_[] = '[OG:Url] <span style="color:green">' . $______[1] . '</span>' . $_____;
		} else {
			$this->_[] = '[OG:Url] <span style="color:red">Not configured</span>' . $_____;
		}
	}
	protected function checkHTMLHead()
	{
		$___ = $this->___;
		$_____ = ' [<a target="_blank" href="https://help.ahrefs.com/en/articles/2614035-https-page-has-internal-links-to-http-error-in-site-audit">?</a>]';
		if (!preg_match('/<.+(src|href|content)=[\'"]http:\/\/.+[\'"].*>/iU', $___)) {
			$this->__++;
			$this->_[] = '[No-HTTP-Link] <span style="color:green">OK</span>' . $_____;
		} else {
			$this->_[] = '[No-HTTP-Link] <span style="color:red">Contains HTTP links</span>' . $_____;
		}
		$_____ = ' [<a target="_blank" href="https://www.w3schools.com/html/html_favicon.asp">?</a>]';
		if (preg_match('/<.+rel=[\'"]icon[\'"].+href=[\'"](.+)[\'"].*>/iU', $___, $______)) {
			$this->__++;
			$this->_[] = '[Favicon] <span style="color:green">' . $______[1] . '</span>' . $_____;
		} else {
			$this->_[] = '[Favicon] <span style="color:red">Not configured</span>' . $_____;
		}
		$_____ = ' [<a target="_blank" href="https://dequeuniversity.com/rules/axe/4.9/document-title">?</a>]';
		if (preg_match('/<title>(.+)<\/title>/iU', $___, $______)) {
			$_______ = htmlentities($______[1]);
			$this->__++;
			$this->_[] = '[Document-Title] <span style="color:green">' . $_______ . '</span>' . $_____;
		} else {
			$this->_[] = '[Document-Title] <span style="color:red">Not configured</span>' . $_____;
		}
		$_____ = ' [<a target="_blank" href="https://developer.chrome.com/docs/lighthouse/seo/meta-description">?</a>]';
		if (preg_match('/<meta\s+name=["\']description["\']\s+content=["\'](.+)["\']\s*\/>/iU', $___, $______)) {
			$_______ = htmlentities($______[1]);
			$this->__++;
			$this->_[] = '[Meta-Description] <span style="color:green">' . $_______ . '</span>' . $_____;
		} else {
			$this->_[] = '[Meta-Description] <span style="color:red">Not configured</span>' . $_____;
		}
		$________ = '';
		$_____ = ' [<a target="_blank" href="https://dequeuniversity.com/rules/axe/4.10/link-name">?</a>]';
		if (preg_match_all('/<a(.+href=["\'][^#].*["\'].*)>(.*)<\/a>/isU', $___, $______)) {
			foreach ((array) $______[1] as $_________ => $__________) {
				if (stripos($__________, 'aria-label=') === FALSE && (empty($______[2][$_________]) || empty(strip_tags($______[2][$_________])))) {
					$________ = htmlentities($______[0][$_________]);
					break;
				}
			}
		}
		if (!$________) {
			$this->__++;
			$this->_[] = '[Links-Name] <span style="color:green">OK</span>' . $_____;
		} else {
			$this->_[] = '[Links-Name] <span style="color:red">' . $________ . '</span>' . $_____;
		}
		$________ = '';
		$_____ = ' [<a target="_blank" href="https://developers.google.com/search/docs/crawling-indexing/links-crawlable">?</a>]';
		if (preg_match_all('/<a(.+)>.*<\/a>/isU', $___, $______)) {
			foreach ((array) $______[1] as $_________ => $__________) {
				if (stripos($__________, 'href=') === FALSE && stripos($__________, 'data-') === FALSE && stripos($__________, 'aria-controls=') === FALSE) {
					$________ = htmlentities($______[0][$_________]);
					break;
				}
			}
		}
		if (!$________) {
			$this->__++;
			$this->_[] = '[Links-Crawlable] <span style="color:green">OK</span>' . $_____;
		} else {
			$this->_[] = '[Links-Crawlable] <span style="color:red">' . $________ . '</span>' . $_____;
		}
		$________ = '';
		$_____ = ' [<a target="_blank" href="https://dequeuniversity.com/rules/axe/4.9/image-alt">?</a>]';
		if (preg_match_all('/<img.+src=.+>/isU', $___, $______)) {
			foreach ($______[0] as $__________) {
				if (stripos($__________, 'alt=') === FALSE && stripos($__________, 'aria-label=') === FALSE && stripos($__________, 'aria-labelledby=') === FALSE) {
					$________ = htmlentities($__________);
					break;
				}
			}
		}
		if (!$________) {
			$this->__++;
			$this->_[] = '[Image-Alt] <span style="color:green">OK</span>' . $_____;
		} else {
			$this->_[] = '[Image-Alt] <span style="color:red">' . $________ . '</span>' . $_____;
		}
		$___________ = str_replace('\\', '/', \XF::getRootDirectory()) . '/';
		$____________ = $___________ . 'robots.txt';
		$_____________ = false;
		$_____ = ' [<a target="_blank" href="https://developer.chrome.com/docs/lighthouse/seo/invalid-robots-txt">?</a>]';
		if (is_file($____________)) {
			$_______ = file_get_contents($____________);
			if ($_______ && preg_match('/user-agent:.+/i', $_______)) {
				$this->__++;
				$_____________ = true;
			}
		}
		if ($_____________) {
			$this->_[] = '[robots.txt] <span style="color:green">OK</span>' . $_____;
		} else {
			$this->_[] = '[robots.txt] <span style="color:red">Not configured</span>' . $_____;
		}
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */