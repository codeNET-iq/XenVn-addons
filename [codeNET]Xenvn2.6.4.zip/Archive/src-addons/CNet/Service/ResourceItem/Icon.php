<?php
/* Developed by CNet Tools */
namespace CNet\Service\ResourceItem;
use XF\Util\File;
class Icon extends XFCP_Icon
{
	protected $allowedTypes = [IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP];
	public function setImageFromUpload(\XF\Http\Upload $_)
	{
		if (\XF::$versionId < 2030035 && $this->app->options()->cnet_convert_avif) {
			$_->setOptimize(true);
		}
		return parent::setImageFromUpload($_);
	}
	public function convertToWebp()
	{
		$_ = $this->resource->getAbstractedIconPath();
		if (!$this->app->fs()->has($_))
			new \InvalidArgumentException("Resource does not have an icon ({$_})");
		$__ = File::copyAbstractedPathToTempFile($_);
		if (!$this->setImage($__))
			return;
		$___ = $this->app->imageManager();
		$____ = $___->imageFromFile($this->fileName);
		if (!$____)
			return;
		$_____ = $____->getType();
		if ($_____ === IMAGETYPE_WEBP || $_____ === IMAGETYPE_GIF)
			return;
		$______ = $____->optimizeImage($this->fileName);
		if ($______)
			$this->updateIcon();
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */