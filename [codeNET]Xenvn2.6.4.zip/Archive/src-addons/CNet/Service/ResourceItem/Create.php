<?php
/* Developed by CNet Tools */
namespace CNet\Service\ResourceItem;
class Create extends XFCP_Create
{
	protected function setupResourceThreadCreation(\XF\Entity\Forum $_)
	{
		$__ = parent::setupResourceThreadCreation($_);
		$___ = $this->app->options();
		$____ = $__->getThread();
		$_____ = $this->getThreadMessage();
		if ($___->cnet_optimal_meta_data || $___->cnet_thread_detail)
			$____->setImage('', '', $_____);
		if (($___->cnet_optimal_meta_data || $___->cnet_thread_detail) && $_____)
			$____->setDescription($_____);
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */