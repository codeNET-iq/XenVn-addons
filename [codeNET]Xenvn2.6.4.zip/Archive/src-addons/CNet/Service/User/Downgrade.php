<?php
/* Developed by CNet Tools */
namespace CNet\Service\User;
class Downgrade extends XFCP_Downgrade
{
	public function downgrade()
	{
		$_ = parent::downgrade();
		$__ = $this->app;
		if ($__->options()->cnet_upgrade_notification && $_ != false) {
			$___ = $this->user;
			$____ = $___->user_id;
			$_____ = $this->app->finder('XF:User')
				->where('user_id', '<>', $____)
				->where('is_admin', true)
				->where('user_state', 'valid')
				->where('last_activity', '>', \XF::$time - 2592000)
				->fetchColumns('user_id');
			if ($_____ && count($_____)) {
				$______ = $this->getUpgrade()->title;
				$_______ = [];
				$_______['user_id'] = $____;
				$_______['link_url'] = $__->router('public')->buildLink('members', $___);
				$_______['link_title'] = $___->username;
				$_______['alert_body'] = htmlentities(\XF::phrase('cnet_downgrade_notice_admin', ['user' => '{link}', 'upgrade' => $______]));
				$________ = [];
				foreach ($_____ as $_________) {
					$________[] = $_________['user_id'];
				}
				if (count($________)) {
					$__->jobManager()->enqueueUnique(
						'cnetSentAlertDowngradeAdmin' . $____,
						'XF:UserAlert',
						['userIds' => $________, 'alert' => $_______],
						false
					);
				}
			}
		}
		return $_;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */