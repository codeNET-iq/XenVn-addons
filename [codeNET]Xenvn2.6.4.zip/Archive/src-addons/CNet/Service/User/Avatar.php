<?php
/* Developed by CNet Tools */
namespace CNet\Service\User;
use XF\Util\File;
class Avatar extends XFCP_Avatar
{
	protected $allowedTypes = [IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP];
	public function setImageFromUpload(\XF\Http\Upload $_)
	{
		if (\XF::$versionId < 2030035 && $this->app->options()->cnet_convert_avif) {
			$_->setOptimize(true);
		}
		return parent::setImageFromUpload($_);
	}
	public function convertToWebp()
	{
		$_ = $this->user->getAbstractedCustomAvatarPath('o');
		if (!$this->app->fs()->has($_))
			return $this->throwException(new \InvalidArgumentException("User does not have an 'o' avatar ($_)"));
		$__ = File::copyAbstractedPathToTempFile($_);
		if (!$this->setImage($__))
			return;
		$___ = $this->app->imageManager();
		$____ = $___->imageFromFile($this->fileName);
		if (!$____)
			return;
		$_____ = $____->getType();
		if ($_____ === IMAGETYPE_WEBP || $_____ === IMAGETYPE_GIF)
			return;
		$______ = $____->optimizeImage($this->fileName);
		if ($______)
			$this->updateAvatar();
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */