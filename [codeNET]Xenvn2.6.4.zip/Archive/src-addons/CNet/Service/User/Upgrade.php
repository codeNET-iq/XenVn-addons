<?php
/* Developed by CNet Tools */
namespace CNet\Service\User;
class Upgrade extends XFCP_Upgrade
{
	public function upgrade()
	{
		$_ = parent::upgrade();
		$__ = $this->app;
		if ($__->options()->cnet_upgrade_notification && $_ != false) {
			$___ = $this->user;
			$____ = $___->user_id;
			$_____ = $this->getUpgrade()->title;
			$______ = $_->end_date;
			if ($______)
				$_______ = \XF::language()->date($______);
			else
				$_______ = \XF::phrase('never');
			$________ = [];
			$________['user_id'] = $____;
			$________['link_url'] =  $this->app->router('public')->buildLink('account/upgrades');
			$________['link_title'] = $_____;
			$________['alert_body'] = htmlentities(\XF::phrase('cnet_upgrade_notice_user', ['upgrade' => '{link}', 'expires' => $_______]));
			$__->jobManager()->enqueueUnique(
				'cnetSentAlertUpgradeUser' . $____,
				'XF:UserAlert',
				['userIds' => [$____], 'alert' => $________],
				false
			);
			$_________ = $this->app->finder('XF:User')
				->where('user_id', '<>', $____)
				->where('is_admin', true)
				->where('user_state', 'valid')
				->where('last_activity', '>', \XF::$time - 2592000)
				->fetchColumns('user_id');
			if ($_________ && count($_________)) {
				$________ = [];
				$________['user_id'] = $____;
				$________['link_url'] = $__->router('public')->buildLink('members', $___);
				$__________ = $__->templater();
				$___________ = false;
				$________['link_title'] = $__________->fnUsernameIcon($__________, $___________, $___);
				$________['alert_body'] = htmlentities(\XF::phrase('cnet_upgrade_notice_admin', ['user' => '{link}', 'upgrade' => $_____, 'expires' => $_______]));
				$____________ = [];
				foreach ($_________ as $_____________) {
					$____________[] = $_____________['user_id'];
				}
				if (count($____________)) {
					$__->jobManager()->enqueueUnique(
						'cnetSentAlertUpgradeAdmin' . $____,
						'XF:UserAlert',
						['userIds' => $____________, 'alert' => $________],
						false
					);
				}
			}
		}
		return $_;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */