<?php
/* Developed by CNet Tools */
namespace CNet\Service;
use XF\Service\AbstractService;
class Health extends AbstractService
{
	public function fileCheck($_ = false)
	{
		$__ = $this->app;
		$___ = $__->addonManager()->getById("CNet");
		$____ = $___->getJson();
		$_____ = $___->getHashesPath();
		$______ = str_replace('\\', '/', \XF::getRootDirectory()) . '/';
		$_______ = [];
		$________ = [
			'error_type' => [],
			'version' => [],
			'missing' => [],
			'inconsistent' => [],
			'unknown' => [],
			'total_checked' => 0,
			'last_check' => \XF::$time
		];
		$_________ = [
			"\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x62\x75\x69\x6c\x64\x2e\x6a\x73\x6f\x6e",
			"\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x68\x61\x73\x68\x65\x73\x2e\x6a\x73\x6f\x6e",
			"\x6a\x73\x2fCNet\x2f\x73\x65\x74\x74\x69\x6e\x67\x2e\x6a\x73",
			"\x6a\x73\x2fCNet\x2f\x66\x6f\x72\x6d\x2e\x6a\x73",
			"\x6a\x73\x2fCNet\x2f\x6f\x70\x74\x69\x6d\x61\x6c\x2e\x6a\x73"
		];
		$__________ = [
			"\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x5f\x6f\x75\x74\x70\x75\x74",
			"\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x5f\x72\x65\x6c\x65\x61\x73\x65\x73"
		];
		$___________ = [
			"\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet",
			"\x6a\x73\x2fCNet",
			"\x73\x74\x79\x6c\x65\x73\x2fCNet"
		];
		$____________ = $this->repoUtility();
		$_____________ = @json_decode(file_get_contents($_____), true);
		if ($_____________) {
			$________['error_type']['hashes'] = 0;
			$______________ = false;
			foreach ((array)$_____________ as $_______________ => $________________) {
				$_________________ = $______ . $_______________;
				$________['total_checked']++;
				if (!is_file($_________________)) {
					$________['missing'][] = $_______________;
					if (!$______________ && preg_match('/src\/addons\/CNet\/(Listener|Setup|Option\/CNet Tools|Option\/Verify|Service\/Health)\.php/i', $_______________)) {
						$__->jobManager()->enqueueUnique(
							'cnetLogError',
							"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
							['job_type' => 'log_error', 'text' => 'default'],
							false
						);
						$______________ = true;
					}
				} else if ($____________->getHash($_________________) != $________________) {
					$________['inconsistent'][] = $_______________;
					if (!$______________ && preg_match('/src\/addons\/CNet\/(Listener|Setup|Option\/CNet Tools|Option\/Verify|Service\/Health)\.php/i', $_______________)) {
						$__->jobManager()->enqueueUnique(
							'cnetLogError',
							"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
							['job_type' => 'log_error', 'text' => 'default'],
							false
						);
						$______________ = true;
					}
				}
				$_______[] = $_______________;
				unset($_____________[$_______________]);
			}
			$__________________ = [];
			foreach ($___________ as $___________________) {
				$___________________ = $______ . $___________________;
				$__________________ = array_merge($__________________, $this->scanFiles($___________________, $______));
			}
			$__________________ = array_diff($__________________, $_______);
			foreach ($__________________ as $_______________) {
				if (in_array($_______________, $_________))
					continue;
				$____________________ = dirname($_______________);
				$_____________________ = false;
				foreach ($__________ as $______________________) {
					if (strpos($____________________, $______________________) === 0) {
						$_____________________ = true;
						break;
					}
				}
				if ($_____________________)
					continue;
				$________['unknown'][] = $_______________;
				$________['total_checked']++;
			}
		} else
			$________['error_type']['hashes'] = 1;
		$________['error_type']['file'] = count($________['missing']) + count($________['inconsistent']) + count($________['unknown']);
		$_______________________ = $this->getOnline($____['version_id']);
		$________['version']['current'] = $____['version_string'];
		$________['version']['latest'] = $_______________________['version_string'];
		$________['error_type']['upgrade'] = ($_______________________['version_id'] > $____['version_id'] ? $_______________________['version_string'] : 0);
		$____________->setCache('cnetFileCheck', $________);
		if ($_)
			return $________;
	}
	protected function getCurrentVersion()
	{
		$_ = $this->app->addonManager()->getById("CNet");
		$__ = $_->getJson();
		return $__['version_string'];
	}
	public function getResult()
	{
		$_ = $this->repoUtility()->getCache('cnetFileCheck');
		if (!$_)
			$_ = $this->fileCheck(true);
		else
			$_['version']['current'] = $this->getCurrentVersion();
		return $_;
	}
	public function getStatus()
	{
		$_ = $this->repoUtility()->getCache('cnetFileCheck');
		return ['error_type' => $_['error_type'] ?? []];
	}
	protected function scanFiles($_, $__)
	{
		$___ = [];
		$____ = scandir($_);
		unset($____[array_search('.', $____, true)]);
		unset($____[array_search('..', $____, true)]);
		if (count($____) < 1)
			return [];
		foreach ($____ as $_____) {
			if (is_dir($_ . '/' . $_____)) {
				$______ = $this->scanFiles($_ . '/' . $_____, $__);
				if (is_array($______))
					$___ = array_merge($______, $___);
			} else {
				$_______ = str_replace($__, '', $_ . '/' . $_____);
				$_______ = str_replace('\\', '/', $_______);
				$___[] = $_______;
			}
		}
		return $___;
	}
	public function getOnline($versionId)
	{
		$addon = $this->app->addonManager()->getById("CNet");
		$json = $addon ? $addon->getJson() : [];
		return ["version_id" => (int)($json["version_id"] ?? $versionId), "version_string" => (string)($json["version_string"] ?? "...")];
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */