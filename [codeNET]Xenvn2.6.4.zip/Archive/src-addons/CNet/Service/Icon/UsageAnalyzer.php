<?php
namespace CNet\Service\Icon;
class UsageAnalyzer extends XFCP_UsageAnalyzer
{
	protected function stepExtra(?int $_, float $__): ?int
	{
		$___ = $this->app->options();
		$____ = [];
		$_____ = $___->cnet_node_icon;
		if (is_array($_____) && count($_____))
			$____ = array_merge($____, array_values($_____));
		$______ = $___->cnet_nav_icon;
		if (is_array($______) && count($______))
			$____ = array_merge($____, array_values($______));
		$_______ = $___->cnet_group_icon;
		if (is_array($_______) && count($_______))
			$____ = array_merge($____, array_values(array_column($_______, 'icon')));
		$____ = array_unique($____);
		$this->recordIconsFromClassPairs('cnet_extra_option', $____);
		return parent::stepExtra($_, $__);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */