<?php
/* Developed by CNet Tools */
namespace CNet\Service;
use XF\Service\AbstractService;
use ZipArchive;
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;
use FilesystemIterator;
use XF\Util\File;
class Files extends AbstractService
{
	private $_ = '';
	private $__ = 0;
	public function initialize()
	{
		$this->_ = str_replace('\\', '/', \XF::getRootDirectory());
		$__ = intval(preg_replace_callback('/(\-?\d+)(.?)/', function ($___) {
			return $___[1] * pow(1024, strpos('BKMG', $___[2]));
		}, strtoupper(ini_get('memory_limit'))));
		$this->__ = $__ - intval(memory_get_usage());
	}
	private function deletePath($___)
	{
		if (is_dir($___)) {
			$____ = array_diff(scandir($___), ['.', '..']);
			foreach ($____ as $_____)
				$this->deletePath("$___/$_____");
			rmdir($___);
		} else if (is_file($___)) {
			unlink($___);
		}
	}
	public function getPath($___)
	{
		$_ = $this->_;
		$___ = str_replace('\\', '/', $___);
		return "$_/$___";
	}
	public function getList($___, $____, $_____)
	{
		$_ = $this->_;
		$___ = $this->getPath($___);
		$______ = $this->limitByPage($____, $_____);
		$_______ = $______['offset'];
		$______ = $______['limit'];
		if (is_dir($___)) {
			$________ = str_replace("$_/", '', $___);
			$________ = rtrim($________, '/');
			$_________ = [];
			$__________ = opendir($___);
			if (!$__________)
				return false;
			$___________ = $____________ = [];
			while (($_____________ = readdir($__________)) !== false) {
				if ($_____________ == '.' || $_____________ == '..')
					continue;
				$______________ = $___ . '/' . $_____________;
				if (is_dir($______________))
					array_push($___________, $______________);
				else
					array_push($____________, $______________);
			}
			closedir($__________);
			natcasesort($___________);
			natcasesort($____________);
			$_________ = array_merge($___________, $____________);
			unset($___________, $____________);
			$_______________ = count($_________);
			$____________ = array_slice($_________, $_______, $______);
			$_________ = [];
			$________________ = $this->repoUtility();
			foreach ($____________ as $_____________) {
				$_________________ = stat($_____________);
				$__________________ = $_________________['size'];
				$___________________ = basename($_____________);
				$____________________ = substr(sprintf('%o', fileperms($_____________)), -4);
				$_____________________ = is_dir($_____________);
				$______________________ = '--';
				if (!$_____________________ && $__________________ < $this->__)
					$______________________ = $________________->getHash($_____________);
				$_________[] = [
					'link' => $_____________,
					'is_dir' => $_____________________,
					'is_write' => is_writable($_____________),
					'time' => $_________________['mtime'],
					'size' => $__________________,
					'chmod' => $____________________,
					'name' => $___________________,
					'path' => trim("$________/$___________________", '/'),
					'sha256' => $______________________
				];
			}
			return ['list' => $_________, 'total' => $_______________, 'is_write' => is_writable($___)];
		} else
			return false;
	}
	public function deleteFile($___)
	{
		$___ = $this->getPath($___);
		$this->deletePath($___);
		return true;
	}
	public function renameFile($___, $____)
	{
		$___ = $this->getPath($___);
		$____ = $this->getPath($____);
		if ((is_dir($___) && !is_dir($____)) || (is_file($___) && !is_file($____))) {
			rename($___, $____);
			return true;
		}
		return false;
	}
	public function createFolder($___)
	{
		$____ = $this->getPath($___);
		if (!is_dir($____))
			mkdir($____);
	}
	public function createBackup()
	{
		$_ = $this->_;
		$___ = $this->app->addonManager()->getById("CNet");
		$____ = $___->getJson();
		$_____ = $____['version_string'];
		$______ = $____['title'];
		$_______ = File::canonicalizePath($this->app->config('internalDataPath'));
		$________ = "$_______/$______";
		$________ = str_replace('\\', '/', $________);
		if (!is_dir($________))
			mkdir($________);
		$_________ = "$________/index.html";
		if (!is_file($_________))
			file_put_contents($_________, '');
		$__________ =  \XF::$time;
		$___________ =  strval(date("Y-m-d", $__________));
		$____________ = ($_____ ? $_____ . "_$__________" . "_$___________" : "none_$__________" . "_$___________");
		$_____________ = "$________/$______-$____________.zip";
		$______________ = new ZipArchive();
		if ($______________->open($_____________, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true)
			return false;
		$_______________ = [
			"\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet",
			"\x6a\x73\x2fCNet",
			"\x73\x74\x79\x6c\x65\x73\x2fCNet"
		];
		foreach ($_______________ as $________________) {
			$________________ = "$_/$________________";
			if (!is_dir($________________))
				continue;
			$_________________ = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($________________, FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_PATHNAME | FilesystemIterator::KEY_AS_PATHNAME), RecursiveIteratorIterator::LEAVES_ONLY);
			$__________________ = false;
			if (method_exists($______________, 'setExternalAttributesName'))
				$__________________ = 0100644 << 16; 
			foreach ($_________________ as $_________) {
				$_________ = str_replace('\\', '/', $_________);
				$______ = str_replace("$_/", '', $_________);
				$______ = 'upload/' . $______;
				$______________->addFile($_________, $______);
				if ($__________________)
					$______________->setExternalAttributesName($______, \ZipArchive::OPSYS_UNIX, $__________________);
			}
		}
		$______________->close();
		if (is_file($_____________))
			return true;
		return false;
	}
	public function getOSInfo()
	{
		$___ = $____ = $_____ = $______ = $_______ = $________ = $_________ = $__________ = $___________ = $____________ = 0;
		$_____________ = [];
		$______________ = "/";
		$_______________ = realpath(\XF::getRootDirectory());
		$___________ = ini_get('open_basedir');
		if ($___________) {
			$____________ = explode(PATH_SEPARATOR, $___________);
			foreach ($____________ as $________________) {
				$_________________ = realpath($________________);
				if ($_________________ && stripos($_______________, $_________________) === 0) {
					$______________ = $_________________;
					break;
				}
			}
		}
		if (PHP_OS_FAMILY == 'Windows') {
			if (class_exists('COM')) {
				$__________________ = new \COM("Winmgmts://");
				$___________________ = $__________________->ExecQuery("SELECT Caption, TotalVisibleMemorySize, FreePhysicalMemory FROM Win32_OperatingSystem");
				foreach ($___________________ as $____________________) {
					$___ = $____________________->Caption;
					$_______ = round(intval($____________________->TotalVisibleMemorySize) * 1024);
					$________ = round(intval($____________________->FreePhysicalMemory) * 1024);
					break;
				}
				$_____________________ = $__________________->ExecQuery("SELECT Name, NumberOfCores, MaxClockSpeed FROM Win32_Processor");
				foreach ($_____________________ as $______________________) {
					$____ = trim($______________________->Name);
					$______ = $______________________->NumberOfCores;
					$_____ = round(floatval($______________________->MaxClockSpeed) * 0.001, 2);
					break;
				}
			} else {
				$_____________[] = 'COM class required. Enable this extension in php.ini: <i>extension=php_com_dotnet.dll</i>';
				$_____________[] = 'This file must exist: <i>php\ext\php_com_dotnet.dll</i>';
			}
		} else if (PHP_OS_FAMILY == 'Linux') {
			if (is_readable('/etc/os-release') && is_readable('/proc/cpuinfo') && is_readable('/proc/meminfo')) {
				$_______________________ = $this->repoUtility();
				$___________________ = file_get_contents('/etc/os-release');
				if (!$___________________)
					$___ = php_uname('s') . ' ' . php_uname('r');
				else {
					$________________________ = $_______________________->toArray($___________________);
					$_________________________ = [];
					foreach ($________________________ as $____________________) {
						if (strpos($____________________, '=') !== false) {
							[$__________________________, $___________________________] = explode('=', $____________________, 2);
							$_________________________[$__________________________] = trim($___________________________, '"');
						}
					}
					$___ = $_________________________['PRETTY_NAME'] ?? ($_________________________['NAME'] ?? php_uname('s') . ' ' . php_uname('r'));
				}
				$___________________ = file_get_contents('/proc/cpuinfo');
				if (preg_match('/model name\s+:\s+(.+)/', $___________________, $____________________________))
					$____ = trim($____________________________[1]);
				if (preg_match_all('/cpu MHz\s+:\s+([\d.]+)/', $___________________, $____________________________)) {
					$_____________________________ = max(array_map('floatval', (array) $____________________________[1]));
					$_____ = round($_____________________________ * 0.001, 2);
				}
				$______ = preg_match_all('/^processor\s+:/m', $___________________);
				$______________________________ = file_get_contents('/proc/meminfo');
				if (preg_match('/MemTotal:\s+(\d+)/', $______________________________, $____________________________))
					$_______ = round(intval($____________________________[1]) * 1024);
				if (preg_match('/MemAvailable:\s+(\d+)/', $______________________________, $____________________________))
					$________ = round(intval($____________________________[1]) * 1024);
			} else {
				$_____________[] = 'Need read permissions for directories: <i>/etc/os-release, /proc/cpuinfo, /proc/meminfo</i>';
				$_____________[] = 'The open_basedir configuration in php.ini must contain those paths';
				$_______________________________ = '/var/www:/tmp:/etc/os-release:/proc/cpuinfo:/proc/meminfo';
				if ($____________) {
					$_______________________________ = array_merge($____________, ['/etc/os-release', '/proc/cpuinfo', '/proc/meminfo']);
					$_______________________________ = array_unique($_______________________________);
					$_______________________________ = implode(PATH_SEPARATOR, $_______________________________);
				}
				$_____________[] = 'For example: <i>open_basedir = "' . $_______________________________ . '"</i>';
			}
		}
		if (is_readable($______________)) {
			if (function_exists('disk_total_space') && function_exists('disk_free_space')) {
				$_________ = disk_total_space($______________);
				$__________ = disk_free_space($______________);
			} else
				$_____________[] = 'Function requirements: <i>disk_total_space, disk_free_space</i>';
		} else
			$_____________[] = 'Unable to read path: ' . $______________;
		if (count($_____________))
			$_____________ = implode('<br />', $_____________);
		return [$___, $____, $_____, $______, $_______, $________, $_________, $__________, $___________, $_____________];
	}
	public function getSqlQuery($___, $____)
	{
		$_____ = $______ = '';
		$____ = trim($____);
		try {
			$_______ = $___->query($____);
			$________ = $_______->rowsAffected();
			if (stripos($____, 'SELECT') === 0 || stripos($____, 'SHOW') === 0) {
				$_______ = $_______->fetchAll();
				$_____ .= '[Total Rows: ' . $________ . "]\n";
				foreach ($_______ as $_________ => $__________) {
					$_____ .= "\n" . '[Row: ' . $_________ . "]\n";
					foreach ($__________ as $___________ => $____________) {
						$_____ .= "\t" . $___________ . ' => ' . $____________ . "\n";
					}
				}
			} else {
				$_____ = '[Rows Affected: ' . $________ . ']';
			}
		} catch (\Throwable $_____________) {
			$_____ = $_____________;
			$______ = true;
		}
		return [$____, $_____, $______];
	}
	public function writeFile($___, $____, $_____, $______, $_______, $________)
	{
		$_____ = trim($_____);
		if ($____ != $_____ && !empty($_____)) {
			$_________ = "$_______/$_____";
			if ($this->renameFile($___, $_________))
				$___ = $_________;
		}
		if ($______ !== false && $______ != $________) {
			file_put_contents($___, $________, LOCK_EX | LOCK_NB);
		}
	}
	private function limitByPage($___, $____)
	{
		$___ = intval($___);
		if ($___ < 1) {
			$___ = 1;
		}
		$____ = intval($____);
		if ($____ < 1) {
			$____ = 1;
		}
		$_____ = ($___ - 1) * $____;
		$______ = $____;
		return ['offset' => $_____, 'limit' => $______];
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */