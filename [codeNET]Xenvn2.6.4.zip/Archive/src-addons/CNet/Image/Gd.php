<?php
/* Developed by CNet Tools */
namespace CNet\Image;
class Gd extends XFCP_Gd
{
	public function imageFromFile($_)
	{
		if (\XF::$versionId >= 2030035)
			return parent::imageFromFile($_);
		if (!is_file($_) || !is_readable($_))
			throw new \InvalidArgumentException("File '$_' is invalid");
		if (!filesize($_))
			throw new \InvalidArgumentException("File '$_' is an empty file");
		$__ = @getimagesize($_);
		if (!$__)
			throw new \InvalidArgumentException("File '$_' is not a valid image");
		$___ = $__[2];
		switch ($___) {
			case IMAGETYPE_GIF:
			case IMAGETYPE_JPEG:
			case IMAGETYPE_PNG:
			case IMAGETYPE_WEBP:
				break;
			default:
				throw new \InvalidArgumentException("File '$_' is not a valid image type");
		}
		$this->type = $___;
		$this->width = $__[0];
		$this->height = $__[1];
		if ($___ !== IMAGETYPE_WEBP)
			return $this->_imageFromFile($_, $___);
		$this->image = null;
		$____ = null;
		$_____ = ($this->width * $this->height * 5) * 1.2 * 2;
		$______ = \XF::getAvailableMemory();
		if ($______ && $______ < $_____)
			\XF::increaseMemoryLimit($_____ - $______);
		if (!function_exists('imagecreatefromwebp'))
			return false;
		$____ = @imagecreatefromwebp($_);
		if (!$____)
			return false;
		$this->setImage($____);
		return true;
	}
	protected function supportsWebP(): bool
	{
		if (\XF::$versionId >= 2030035)
			return parent::supportsWebP();
		return function_exists('imagewebp');
	}
	protected function supportsAnimatedWebP(): bool
	{
		if (\XF::$versionId >= 2030035)
			return parent::supportsAnimatedWebP();
		return false;
	}
	public function optimizeImage(string $_, ?int $__ = null): bool
	{
		if (\XF::$versionId >= 2030035)
			return parent::optimizeImage($_, $__);
		if (!$this->supportsWebP())
			return false;
		if ($this->type === IMAGETYPE_GIF && !$this->supportsAnimatedWebP())
			return false;
		if ($__ === null)
			$__ = 85;
		imagepalettetotruecolor($this->image);
		$___ = imagewebp($this->image, $_, $__);
		if ($___) {
			$this->setImage($this->image);
			$this->type = IMAGETYPE_WEBP;
		}
		return $___;
	}
	public function getDataUri($_)
	{
		if (\XF::$versionId >= 2030035 || $this->type !== IMAGETYPE_WEBP)
			return parent::getDataUri($_);
		$this->save($_);
		$__ = 'image/webp';
		$___ = file_get_contents($_);
		return 'data:' . $__ . ';base64,' . base64_encode($___);
	}
	public function save($_, $__ = null, $___ = null)
	{
		if ($__ === null)
			$__ = $this->type;
		if (\XF::$versionId >= 2030035 ||  $__ !== IMAGETYPE_WEBP)
			return parent::save($_, $__, $___);
		if ($___ === null)
			$___ = 85;
		imagealphablending($this->image, false);
		imagesavealpha($this->image, true);
		return imagewebp($this->image, $_, $___);
	}
	public function output($_ = null, $__ = null)
	{
		if ($_ === null)
			$_ = $this->type;
		if (\XF::$versionId >= 2030035 || $_ !== IMAGETYPE_WEBP)
			return parent::output($_, $__);
		if ($__ === null)
			$__ = 85;
		return imagewebp($this->image, null, $__);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */