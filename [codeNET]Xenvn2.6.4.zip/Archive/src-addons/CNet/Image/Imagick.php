<?php
/* Developed by CNet Tools */
namespace CNet\Image;
use ImagickException;
class Imagick extends XFCP_Imagick
{
	public function imageFromFile($_)
	{
		if (\XF::$versionId >= 2030035)
			return parent::imageFromFile($_);
		if (!is_file($_) || !is_readable($_))
			throw new \InvalidArgumentException("File '$_' is invalid");
		if (!filesize($_))
			throw new \InvalidArgumentException("File '$_' is an empty file");
		$__ = @getimagesize($_);
		if (!$__)
			throw new \InvalidArgumentException("File '$_' is not a valid image");
		$___ = $__[2];
		switch ($___) {
			case IMAGETYPE_GIF:
			case IMAGETYPE_JPEG:
			case IMAGETYPE_PNG:
			case IMAGETYPE_WEBP:
				break;
			default:
				throw new \InvalidArgumentException("File '$_' is not a valid image type");
		}
		$this->type = $___;
		$this->width = $__[0];
		$this->height = $__[1];
		if ($___ !== IMAGETYPE_WEBP)
			return $this->_imageFromFile($_, $___);
		$____ = new \Imagick($_);
		$this->setImage($____);
		return true;
	}
	protected function supportsWebP(): bool
	{
		if (\XF::$versionId >= 2030035)
			return parent::supportsWebP();
		return method_exists($this->imagick, 'queryFormats') && in_array('WEBP', $this->imagick->queryFormats());
	}
	protected function supportsAnimatedWebP(): bool
	{
		if (\XF::$versionId >= 2030035)
			return parent::supportsAnimatedWebP();
		$_ = $this->imagick->getVersion();
		if (!preg_match('#ImageMagick (\d+\.\d+\.\d+)-(\d+)#i', $_['versionString'], $__))
			return false;
		if (version_compare($__[1], '7.0.8', '<'))
			return false;
		if (version_compare($__[1], '7.0.8', '==') && intval($__[2]) < 68)
			return false;
		return true;
	}
	public function optimizeImage(string $_, ?int $__ = null): bool
	{
		if (\XF::$versionId >= 2030035)
			return parent::optimizeImage($_, $__);
		if (!$this->supportsWebP())
			return false;
		if ($this->type === IMAGETYPE_GIF && !$this->supportsAnimatedWebP())
			return false;
		$___ = $this->imagick->setImageFormat('webp');
		if ($___)
			$this->type = IMAGETYPE_WEBP;
		return $___;
	}
	public function getDataUri($_)
	{
		if (\XF::$versionId >= 2030035 || $this->type !== IMAGETYPE_WEBP)
			return parent::getDataUri($_);
		$this->save($_);
		$__ = 'image/webp';
		$___ = file_get_contents($_);
		return 'data:' . $__ . ';base64,' . base64_encode($___);
	}
	public function save($_, $__ = null, $___ = null)
	{
		if ($__ === null)
			$__ = $this->type;
		if (\XF::$versionId >= 2030035 || $__ !== IMAGETYPE_WEBP)
			return parent::save($_, $__, $___);
		if ($___ === null)
			$___ = 85;
		if (method_exists($this->imagick, 'getImageProfiles')) {
			$____ = $this->imagick->getImageProfiles('icc');
			$this->imagick->stripImage();
			if ($____ && !empty($____['icc']))
				$this->imagick->setImageProfile('icc', $____['icc']);
		} else
			$this->imagick->stripImage();
		$_____ = $this->imagick->setImageFormat('webp');
		if ($_____) {
			try {
				return $this->imagick->writeImages($_, true);
			} catch (ImagickException $______) {
			}
		}
		return false;
	}
	public function output($_ = null, $__ = null)
	{
		if ($_ === null)
			$_ = $this->type;
		if (\XF::$versionId >= 2030035 || $_ !== IMAGETYPE_WEBP)
			return parent::output($_, $__);
		if ($__ === null)
			$__ = 85;
		$this->imagick->stripImage();
		$___ = $this->imagick->setImageFormat('webp');
		if ($___) {
			try {
				echo $this->imagick->getImagesBlob();
			} catch (ImagickException $____) {
			}
		}
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */