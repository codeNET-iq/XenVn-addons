<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractRebuildJob;
use XF\Util\File;
class Watermark extends AbstractRebuildJob
{
	public function run($_)
	{
		$__ = $this->app->options()->cnet_image_watermark;
		if (!$__)
			return $this->complete();
		File::cleanUpTempFiles();
		$___ = parent::run($_);
		return $___;
	}
	protected function rebuildById($_): void
	{
		$__ = $this->app->imageManager();
		$___ = $this->app->em()->findOne('XF:Attachment', ['data_id', $_], ['Data']);
		if (!$___)
			return;
		$____ = $___->Data;
		if (!$____ || !$____->has_thumbnail)
			return;
		$_____ = $this->repoUtility();
		$______ = $_____->findAttachmentDataPath($___);
		if (!$______)
			return;
		$_______ = File::getTempFile();
		copy($______, $_______);
		if (!$_______ || !filesize($_______))
			return;
		$________ = $__->imageFromFile($_______);
		if ($________ && $________->getType() !== IMAGETYPE_GIF) {
			$_____->addWatermark($________);
			if ($________->save($_______)) {
				if (\XF::$versionId < 2030035) {
					$_________ = \XF::extendClass('\CNet\FileWrapper');
					$__________ = new $_________($_______, $____->filename);
				} else
					$__________ = new \XF\FileWrapper($_______, $____->filename);
				$___________ = $this->app->service('XF:Attachment\Preparer');
				$___________->updateDataFromFile($____, $__________);
			}
		}
	}
	protected function getNextIds($_, $__): array
	{
		$___ = $this->app->db();
		return $___->fetchAllColumn($___->limit(
			"
				SELECT data_id 
				FROM xf_attachment_data
				WHERE data_id  > ? AND width > 0 AND height > 0 AND attach_count > 0
				ORDER BY data_id 
			",
			$__
		), $_);
	}
	public function getStatusMessage(): string
	{
		$_ = \XF::phrase('rebuilding');
		$__ = $this->getStatusType();
		return sprintf('%s... %s (%s)', $_, $__, $this->data['start']);
	}
	protected function getStatusType(): string
	{
		return 'Rebuild images watermark';
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */