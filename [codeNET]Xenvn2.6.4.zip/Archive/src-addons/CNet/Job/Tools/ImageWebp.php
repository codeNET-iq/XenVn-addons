<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractJob;
use XF\Util\File;
class ImageWebp extends AbstractJob
{
	protected $defaultData = [
		'start' => 0,
		'batch' => 50,
		'type' => 'attachment'
	];
	public function run($_)
	{
		$__ = $this->app;
		if (\XF::$versionId >= 2030035 || !$__->options()->cnet_convert_avif || !defined('IMAGETYPE_WEBP'))
			return $this->complete();
		$___ = microtime(true);
		$____ = $__->db();
		$_____ = $__->em();
		$______ = 0;
		if ($this->data['type'] == 'attachment') {
			$_______ = $____->fetchAllColumn($____->limit(
				"
					SELECT data_id 
					FROM xf_attachment_data
					WHERE data_id > ? AND width > 0 AND height > 0 AND attach_count > 0
					ORDER BY data_id 
				",
				$this->data['batch']
			), $this->data['start']);
			if (!$_______) {
				$this->data['start'] = 0;
				$this->data['type'] = 'avatar';
				return $this->resume();
			}
			$________ = $__->addonManager()->getById('XFRM');
			$_________ = ($________ && $________->isActive());
			$__________ = $__->imageManager();
			$___________ = \XF::extendClass('\CNet\FileWrapper');
			foreach ($_______ as $____________) {
				$this->data['start'] = $____________;
				$_____________ = $__->em()->findOne('XF:Attachment', ['data_id', $____________], ['Data']);
				if (!$_____________)
					continue;
				$______________ = $_____________->Data;
				if (!$______________ || !$______________->has_thumbnail || $______________->extension == 'webp' || $______________->extension == 'gif')
					continue;
				$_______________ = $this->repoUtility();
				$________________ = $_______________->findAttachmentDataPath($_____________);
				if (!$________________)
					continue;
				$_________________ = $__->router('public')->buildLink('full:attachments', $_____________);
				$__________________ = $_____________->filename;
				$___________________ = File::getTempFile();
				copy($________________, $___________________);
				if (!$___________________ || !filesize($___________________))
					continue;
				$____________________ = $__________->imageFromFile($___________________);
				if ($____________________ && $____________________->optimizeImage($___________________)) {
					if ($____________________->save($___________________)) {
						$_____________________ = pathinfo($______________->filename, PATHINFO_FILENAME) . '.webp';
						$______________->filename = $_____________________;
						$______________________ = new $___________($___________________, $______________->filename);
						$_______________________ = $__->service('XF:Attachment\Preparer');
						$_______________________->updateDataFromFile($______________, $______________________);
						$________________________ = $__->router('public')->buildLink('full:attachments', $_____________);
						$_________________________ = preg_replace('/\?hash=\w+$/i', '',  $_____________->getThumbnailUrlFull());
						$__________________________ = $__->finder('XF:Thread')->where('image', $_________________)->with(['FirstPost'])->fetch();
						if (count($__________________________)) {
							foreach ($__________________________ as $___________________________) {
								$___________________________->set('image', $________________________, ['forceSet' => true]);
								$___________________________->set('icon', $_________________________, ['forceSet' => true]);
								$____________________________ = $___________________________->FirstPost;
								$_____________________________ = $____________________________->message;
								$_____________________________ = str_replace($__________________, $_____________________, $_____________________________, $______________________________);
								$_____________________________ = str_replace($_________________, $________________________, $_____________________________, $_______________________________);
								if ($______________________________ || $_______________________________) {
									$____________________________->message = $_____________________________;
									$____________________________->save(true, false);
								}
								$___________________________->save(true, false);
							}
						}
						if ($_________) {
							$________________________________ = $__->finder('XFRM:ResourceItem')->where('image', $_________________)->with(['Description'])->fetch();
							if (count($________________________________)) {
								foreach ($________________________________ as $_________________________________) {
									$_________________________________->set('image', $________________________, ['forceSet' => true]);
									$_________________________________->set('icon', $_________________________, ['forceSet' => true]);
									$__________________________________ = $_________________________________->Description;
									$_____________________________ = $__________________________________->message;
									$_____________________________ = str_replace($__________________, $_____________________, $_____________________________, $______________________________);
									$_____________________________ = str_replace($_________________, $________________________, $_____________________________, $_______________________________);
									if ($______________________________ || $_______________________________) {
										$__________________________________->message = $_____________________________;
										$__________________________________->save(true, false);
									}
									$_________________________________->save(true, false);
								}
							}
						}
					}
				}
				$______++;
				if (microtime(true) - $___ >= $_)
					break;
			}
		} else if ($this->data['type'] == 'avatar') {
			$___________________________________ = $____->fetchAllColumn($____->limit(
				"
					SELECT user_id
					FROM xf_user
					WHERE user_id > ? AND avatar_date > 0
					ORDER BY user_id
				",
				$this->data['batch']
			), $this->data['start']);
			if (!$___________________________________) {
				$this->data['start'] = 0;
				$this->data['type'] = 'banner';
				return $this->resume();
			}
			foreach ($___________________________________ as $____________________________________) {
				$this->data['start'] = $____________________________________;
				$_____________________________________ = $_____->find('XF:User', $____________________________________);
				$______________________________________ = $this->app->service('XF:User\Avatar', $_____________________________________);
				$______________________________________->silentRunning(true);
				$______________________________________->logIp(false);
				$______________________________________->convertToWebp();
				$______++;
				if (microtime(true) - $___ >= $_)
					break;
			}
		} else if ($this->data['type'] == 'banner') {
			$___________________________________ = $____->fetchAllColumn($____->limit(
				"
					SELECT user_id
					FROM xf_user_profile
					WHERE user_id > ? AND banner_date > 0
					ORDER BY user_id
				",
				$this->data['batch']
			), $this->data['start']);
			if (!$___________________________________) {
				$this->data['start'] = 0;
				$this->data['type'] = 'resource';
				return $this->resume();
			}
			foreach ($___________________________________ as $____________________________________) {
				$this->data['start'] = $____________________________________;
				$_____________________________________ = $_____->find('XF:User', $____________________________________);
				$_______________________________________ = $this->app->service('XF:User\ProfileBanner', $_____________________________________);
				$_______________________________________->silentRunning(true);
				$_______________________________________->logIp(false);
				$_______________________________________->convertToWebp();
				$______++;
				if (microtime(true) - $___ >= $_)
					break;
			}
		} else if ($this->data['type'] == 'resource') {
			$________ = $this->app->addonManager()->getById('XFRM');
			if (!$________ || !$________->isActive())
				return $this->complete();
			$________________________________________ = $____->fetchAllColumn($____->limit(
				"
					SELECT resource_id
						FROM xf_rm_resource
						WHERE resource_id > ?
							AND icon_date > 0
						ORDER BY resource_id
					",
				$this->data['batch']
			), $this->data['start']);
			if (!$________________________________________)
				return $this->complete();
			foreach ($________________________________________ as $_________________________________________) {
				$this->data['start'] = $_________________________________________;
				$_________________________________ = $this->app->find('XFRM:ResourceItem', $_________________________________________);
				$__________________________________________ = $this->app->service('XFRM:ResourceItem\Icon', $_________________________________);
				$__________________________________________->logIp(false);
				$__________________________________________->convertToWebp();
				$______++;
				if (microtime(true) - $___ >= $_)
					break;
			}
		}
		File::cleanUpTempFiles();
		$this->data['batch'] = $this->calculateOptimalBatch($this->data['batch'], $______, $___, $_, 30);
		return $this->resume();
	}
	public function getStatusMessage()
	{
		$_ = $this->data['start'];
		$__ = $this->data['type'];
		return "Converting Images To WebP ($__: $_)";
	}
	public function canCancel()
	{
		return true;
	}
	public function canTriggerByChoice()
	{
		return true;
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */