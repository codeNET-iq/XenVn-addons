<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractRebuildJob;
use XF\Util\File;
class ImageSize extends AbstractRebuildJob
{
	protected $defaultData = [
		'maxWidth' => 0,
		'maxHeight' => 0
	];
	public function run($_)
	{
		$__ = $this->app->options()->attachmentMaxDimensions;
		if (!$__ || (!$__['width'] && !$__['height']))
			return $this->complete();
		$this->data['maxWidth'] = $__['width'] ?: 0;
		$this->data['maxHeight'] = $__['height'] ?: 0;
		File::cleanUpTempFiles();
		$___ = parent::run($_);
		return $___;
	}
	protected function rebuildById($_): void
	{
		$__ = $this->app->em()->findOne('XF:Attachment', ['data_id', $_], ['Data']);
		if (!$__)
			return;
		$___ = $__->Data;
		if (!$___ || !$___->has_thumbnail)
			return;
		$____ = $this->app->imageManager();
		$_____ = $this->data['maxWidth'];
		$______ = $this->data['maxHeight'];
		$_______ = $___->width;
		$________ = $___->height;
		$_________ = (($_____ && $_______ > $_____) || ($______ && $________ > $______));
		if ($_________ && $____->canResize($_______, $________)) {
			$__________ = $this->repoUtility();
			$___________ = $__________->findAttachmentDataPath($__);
			if (!$___________)
				return;
			$____________ = File::getTempFile();
			copy($___________, $____________);
			if (!$____________ || !filesize($____________))
				return;
			$_____________ = $____->imageFromFile($____________);
			if ($_____________) {
				$_____________->resize($_____ ?: $______, $______ ?: null);
				if ($_____________->save($____________)) {
					if (\XF::$versionId < 2030035) {
						$______________ = \XF::extendClass('\CNet\FileWrapper');
						$_______________ = new $______________($____________, $___->filename);
					} else {
						$_______________ = new \XF\FileWrapper($____________, $___->filename);
					}
					$________________ = $this->app->service('XF:Attachment\Preparer');
					$________________->updateDataFromFile($___, $_______________);
				}
			}
		}
	}
	protected function getNextIds($_, $__): array
	{
		$___ = $this->app->db();
		return $___->fetchAllColumn($___->limit(
			"
				SELECT data_id 
				FROM xf_attachment_data
				WHERE data_id  > ? AND width > 0 AND height > 0 AND (width > ? OR height > ?) AND attach_count > 0
				ORDER BY data_id 
			",
			$__
		), [$_, $this->data['maxWidth'], $this->data['maxHeight']]);
	}
	public function getStatusMessage(): string
	{
		$_ = \XF::phrase('rebuilding');
		$__ = $this->getStatusType();
		return sprintf('%s... %s (%s)', $_, $__, $this->data['start']);
	}
	protected function getStatusType(): string
	{
		return 'Optimize image size';
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */