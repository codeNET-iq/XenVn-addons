<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractJob;
class CleanCache extends AbstractJob
{
	protected $defaultData = [];
	public function run($_)
	{
		$__ = $this->app;
		$___ = \XF::$versionId;
		$____ = $__->registry();
		$____->set("cnet\x43\x61\x63\x68\x65", []);
		if ($___ < 2030035) {
			$____->set('cnetFontAwesome', '');
			$____->set('cnetFontAwesomeCache', []);
			$____->set('cnetCodePoints', []);
		}
		return $this->complete();
	}
	public function getStatusMessage()
	{
		return 'Clean CNet Cache';
	}
	public function canCancel()
	{
		return true;
	}
	public function canTriggerByChoice()
	{
		return true;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */