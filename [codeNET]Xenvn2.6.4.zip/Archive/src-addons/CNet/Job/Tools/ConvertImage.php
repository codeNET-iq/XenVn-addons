<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractJob;
use XF\Util\File;
class ConvertImage extends AbstractJob
{
	protected $defaultData = [
		'list' => [],
		'type' => '',
		'id' => 0,
		'start' => 0,
		'count' => 0,
		'attachCount' => 0,
		'attachmentId' => [],
		'attachBBcode' => [],
		'imgBBcode' => [],
		'entityId' => 0,
		'entityTitle' => ''
	];
	public function run($_)
	{
		$__ = microtime(true);
		$___ = $this->data['start'];
		$____ = $this->data['id'];
		$_____ = $this->data['type'];
		if (!$____ || !$_____)
			return $this->complete();
		if ($___ == 0) {
			$this->getEntityData();
			$______ = $this->data['list'];
			if (!$______ || count($______) == 0)
				return $this->complete();
			$this->data['start'] = 1;
		} else {
			$_______ = $this->app->options()->attachmentMaxPerMessage;
			$______ = $this->data['list'];
			$______ = array_slice($______, $___ - 1, 5);
			if (!$______ || count($______) == 0 || $this->data['attachCount'] >= $_______) {
				$this->updateEntityData();
				return $this->complete();
			}
			$________ = $this->repoUtility();
			$_________ = $this->app->repository('XF:Attachment');
			$__________ = $_________->getDefaultAttachmentConstraints();
			$___________ = $_________->getAttachmentHandler($_____);
			$____________ = $this->app->service('XF:Attachment\Preparer');
			$_____________ = \XF::extendClass('\XF\Http\Upload');
			if (\XF::$versionId >= 2030035)
				$______________ = \XF::extendClass('\XF\FileWrapper');
			else
				$______________ = \XF::extendClass('\CNet\FileWrapper');
			$_______________ = \XF::visitor();
			foreach ($______ as $________________) {
				$_________________ = $this->data['start'];
				$this->data['count'] = $_________________;
				$this->data['start']++;
				if (preg_match("#\[IMG.*\](https?://.+)\[/IMG\]#isU", $________________, $__________________)) {
					if (microtime(true) - $__ >= $_)
						break;
					$___________________ = $__________________[1];
					$___________________ = trim($___________________);
					$___________________ = str_replace(' ', '%20', $___________________);
					if (empty($___________________) || !preg_match('/^(https?:\/\/|www\.)\S+\.\S+.*/i', $___________________) || strpos($___________________, '"') !== false)
						continue;
					[$____________________, $_____________________] = $________->getCurl($___________________);
					if ($_____________________)
						continue;
					$______________________ = File::getTempFile();
					if (file_put_contents($______________________, $____________________) === false)
						continue;
					$_______________________ = @getimagesizefromstring($____________________);
					$________________________ = $_______________________['mime'] ?? '';
					$_________________________ = '';
					switch ($________________________) {
						case 'image/gif':
							$_________________________ = '.gif';
							break;
						case 'image/jpeg':
							$_________________________ = '.jpg';
							break;
						case 'image/png':
							$_________________________ = '.png';
							break;
						case 'image/webp':
							$_________________________ = '.webp';
							break;
						case 'image/avif':
							$_________________________ = '.avif';
							break;
						default:
							break;
					}
					if (!$_________________________)
						continue;
					$__________________________ = $this->data['entityTitle'] . '-' . $_________________;
					$___________________________ = $__________________________ . $_________________________;
					$____________________________ = new $_____________($______________________, $___________________________);
					$____________________________->applyConstraints($__________);
					$____________________________->requireImage();
					$_____________________________ = [];
					if (!$____________________________->isValid($_____________________________))
						continue;
					$___________________________ = $__________________________ . '.' . $____________________________->getExtension();
					$______________________________ = new $______________($______________________, $___________________________);
					$_______________________________ =  md5_file($______________________);
					$________________________________ = $____________->insertAttachment(
						$___________,
						$______________________________,
						$_______________,
						$_______________________________
					);
					$_________________________________ = $________________________________->attachment_id;
					if (!$_________________________________)
						continue;
					$this->data['attachmentId'][] = $_________________________________;
					$this->data['attachBBcode'][] = '[ATTACH=full]' . $_________________________________ . '[/ATTACH]';
					$this->data['imgBBcode'][] = $________________;
					$this->data['attachCount']++;
					if ($this->data['attachCount'] >= $_______) {
						$this->data['list'] = [];
						break;
					}
					if (microtime(true) - $__ >= $_)
						break;
				}
			}
			File::cleanUpTempFiles();
		}
		return $this->resume();
	}
	protected function updateEntityData()
	{
		$_ = $this->data['entityId'];
		$__ = $this->data['type'];
		if (!$_ || !$__)
			return false;
		$___ = $this->data['attachBBcode'];
		$____ = $this->data['imgBBcode'];
		$_____ = $this->data['attachmentId'];
		$______ = $_______ = '';
		if (count($___) > 0 && count($____) > 0 && count($_____) > 0) {
			$________ = '';
			if ($__ == 'post') {
				$________ = $this->app->em()->find('XF:Post', $_, ['Thread']);
				$______ = $________->Thread;
				$_________ = $______->image;
			} else if ($__ == 'resource_update') {
				$________ = $this->app->em()->find('XFRM:ResourceUpdate', $_, ['Resource']);
				$_______ = $________->Resource;
				$_________ = $_______->image;
			}
			if (!$________) {
				if ($_____ && count($_____) > 0) {
					$__________ = $this->app->finder('XF:Attachment')->whereIds($_____)->fetch();
					foreach ($__________ as $___________) {
						$___________->delete(true, false);
					}
				}
				return false;
			}
			$____________ = $________->message;
			$_____________ = '';
			$______________ = '';
			if ($__ == 'resource_update') {
				$_______________ = $_______->Discussion;
				if ($_______________) {
					$______________ = $_______________->LastPost;
					if ($______________)
						$_____________ = $______________->message;
				}
			}
			foreach ($____ as $________________ => $_________________) {
				$__________________ = preg_quote($_________________);
				$____________ = preg_replace("#(?s)(\[(?:icode|code)[^\]]*\].*\[\/(?:icode|code)\])(*SKIP)(*F)|$__________________#isU", $___[$________________], $____________);
				if ($_____________)
					$_____________ = preg_replace("#(?s)(\[(?:icode|code)[^\]]*\].*\[\/(?:icode|code)\])(*SKIP)(*F)|$__________________#isU", $___[$________________], $_____________);
			}
			$___________________ = false;
			foreach ($___ as $________________ => $_________________) {
				$___________ = $this->app->em()->find('XF:Attachment', $_____[$________________]);
				if (!$___________)
					continue;
				if (stripos($____________, $_________________) !== false) {
					preg_match_all('#\[URL=.+\](.+)\[/URL\]#isU', $____________, $____________________, PREG_SET_ORDER);
					if (isset($____________________[0])) {
						$_____________________ = count($____________________);
						for ($______________________ = 0; $______________________ < $_____________________; $______________________++) {
							if (stripos($____________________[$______________________][1], $_________________) !== false)
								$____________ = str_ireplace($____________________[$______________________][0], $____________________[$______________________][1], $____________);
						}
					}
					if ($_____________) {
						preg_match_all('#\[URL=.+\](.+)\[/URL\]#isU', $_____________, $____________________, PREG_SET_ORDER);
						if (isset($____________________[0])) {
							$_____________________ = count($____________________);
							for ($______________________ = 0; $______________________ < $_____________________; $______________________++) {
								if (stripos($____________________[$______________________][1], $_________________) !== false)
									$_____________ = str_ireplace($____________________[$______________________][0], $____________________[$______________________][1], $_____________);
							}
						}
					}
					if (!$___________________) {
						$_______________________ = preg_replace("#\[IMG.*\](https?://.+)\[/IMG\]#isU", "$1", $____[$________________]);
						$________________________ = $this->app->router('public')->buildLink('full:attachments', $___________);
						if ($_________ == $_______________________) {
							if ($__ == 'post') {
								$______->set('image', $________________________, ['forceSet' => true]);
								$______->set('icon', preg_replace('/\?hash=\w+$/i', '', $___________->getThumbnailUrlFull()), ['forceSet' => true]);
								$______->save(true, false);
							} else if ($__ == 'resource_update') {
								$_______->set('image', $________________________, ['forceSet' => true]);
								$_______->set('icon', preg_replace('/\?hash=\w+$/i', '', $___________->getThumbnailUrlFull()), ['forceSet' => true]);
								$_______->save(true, false);
							}
							$___________________ = true;
						}
					}
					$___________->content_type = $__;
					$___________->content_id = $_;
					$___________->temp_hash = '';
					$___________->unassociated = 0;
					$___________->save(true, false);
					$___________->getHandler()->onAssociation($___________, $___________->getContainer());
				} else {
					$___________->delete(true, false);
					if ($this->data['attachCount'] > 0)
						$this->data['attachCount']--;
				}
			}
			$_________________________ = '';
			preg_match_all("#\[ATTACH.*\](.+)\[/ATTACH\]#isU", $____________, $__________________________);
			if (isset($__________________________[1])) {
				$___________________________ = array_combine($__________________________[1], $__________________________[1]);
				foreach ($___________________________ as $____________________________ => $_____________________________) {
					$___________________________[$_____________________________] = intval($_____________________________);
				}
				$___________________________ = array_unique($___________________________);
				$_________________________ = array(
					'attachments' => $___________________________
				);
			}
			$________->message = $____________;
			$________->attach_count = $this->data['attachCount'];
			$________->embed_metadata = $_________________________;
			$________->save(true, false);
			if ($______________ && $_____________) {
				$______________->message = $_____________;
				$______________->save(true, false);
			}
		}
	}
	protected function getEntityData()
	{
		$_ = $this->data['id'];
		$__ = $this->data['type'];
		if (!$_ || !$__)
			return false;
		$___ = '';
		$____ = '';
		if ($__ == 'post') {
			$___ = $this->app->em()->find('XF:Post', $_);
			if (!$___)
				return false;
			$this->data['entityId'] = $___->post_id;
			$____ = $___->Thread->title;
		} else if ($__ == 'resource_update') {
			$___ = $this->app->em()->find('XFRM:ResourceUpdate', $_);
			if (!$___)
				return false;
			$this->data['entityId'] = $___->resource_update_id;
			$____ = $___->Resource->title;
		}
		$this->data['entityTitle'] = preg_replace('/[\p{P}]/u', '', $____);
		$this->data['attachCount'] = $___->attach_count;
		$_____ = [];
		$______ = $this->repoUtility()->checkExtImages($___->message, true);
		if ($______) {
			$_______ = count($______[2]);
			for ($________ = 0; $________ < $_______; $________++) {
				$_____[] = $______[0][$________];
			}
			$_____ = array_unique($_____);
		}
		$this->data['list'] = $_____;
	}
	public function getStatusMessage()
	{
		return \XF::phrase('cnet_convert_external_images_x', ['count' => $this->data['count'], 'total' => count($this->data['list'])]);
	}
	public function canCancel()
	{
		return true;
	}
	public function canTriggerByChoice()
	{
		return true;
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */