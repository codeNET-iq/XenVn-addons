<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractRebuildJob;
class MetaData extends AbstractRebuildJob
{
	protected $defaultData = [
		'type' => 'thread'
	];
	protected function rebuildById($_): void
	{
		if ($this->data['type'] == 'thread') {
			$__ = $this->app->em()->find('XF:Thread', $_);
			if ($__) {
				$__->setImage();
				$__->setDescription();
				$__->save(true, false);
			}
		} else if ($this->data['type'] == 'resource') {
			$___ = $this->app->em()->find('XFRM:ResourceItem', $_);
			if ($___) {
				$___->setImage();
				$___->setDescription();
				$___->save(true, false);
			}
		}
	}
	protected function getNextIds($_, $__): array
	{
		$___ = $this->app->db();
		$____ = 0;
		if ($this->data['type'] == 'thread') {
			$____ = $___->fetchAllColumn($___->limit(
				"
				SELECT thread_id
				FROM xf_thread
				WHERE thread_id > ?
				ORDER BY thread_id
			",
				$__
			), $_);
		}
		if (!$____ && $this->data['type'] == 'thread') {
			$_____ = $this->app->addonManager()->getById('XFRM');
			if ($_____ && $_____->isActive()) {
				$this->data['type'] = 'resource';
				$this->data['start'] = 0;
				$_ = 0;
			}
		}
		if ($this->data['type'] == 'resource') {
			$____ = $___->fetchAllColumn($___->limit(
				"
				SELECT resource_id
				FROM xf_rm_resource
				WHERE resource_id > ?
				ORDER BY resource_id
			",
				$__
			), $_);
		}
		return $____;
	}
	public function getStatusMessage(): string
	{
		$_ = \XF::phrase('rebuilding');
		$__ = $this->getStatusType();
		return sprintf('%s... %s (%s)', $_, $__, $this->data['start']);
	}
	protected function getStatusType(): string
	{
		return 'Rebuild Threads / Resources metadata';
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */