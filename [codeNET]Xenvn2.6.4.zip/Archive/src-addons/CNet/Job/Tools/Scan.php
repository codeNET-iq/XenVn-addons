<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractRebuildJob;
use XF\Util\File;
class Scan extends AbstractRebuildJob
{
	public function run($_)
	{
		if (empty($this->app->options()->cnet_malware_scanner))
			return $this->complete();
		$__ = parent::run($_);
		File::cleanUpTempFiles();
		return $__;
	}
	protected function rebuildById($_): void
	{
		$__ = $this->app->em()->findOne('XF:Attachment', ['data_id', $_], ['Data']);
		if (!$__)
			return;
		$___ = $__->Data;
		if (!$___ || !in_array($___->extension, ['php', 'zip', 'txt']))
			return;
		$____ = $this->repoUtility()->scanAttachment($__, $___);
		if ($__->scan != $____) {
			$__->set('scan', $____, ['forceSet' => true]);
			$__->save(true, false);
		}
	}
	protected function getNextIds($_, $__): array
	{
		$___ = $this->app->db();
		return $___->fetchAllColumn($___->limit(
			"
				SELECT data_id 
				FROM xf_attachment_data
				WHERE data_id  > ? AND width = 0 AND height = 0 AND attach_count > 0
				ORDER BY data_id 
			",
			$__
		), $_);
	}
	public function getStatusMessage(): string
	{
		$_ = \XF::phrase('processing');
		$__ = $this->getStatusType();
		return sprintf('%s... %s (%s)', $_, $__, $this->data['start']);
	}
	protected function getStatusType(): string
	{
		return 'Scan attachments for malware';
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */