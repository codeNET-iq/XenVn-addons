<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractJob;
class Scheduled extends AbstractJob
{
	protected $defaultData = [];
	public function run($_)
	{
		$__ = $this->data['type'];
		$___ = $this->data['id'];
		if ($__ == 'thread') {
			$____ = $this->app->finder('XF:Thread')
				->where('thread_id', $___)
				->where('scheduled', '>', 0)
				->fetchOne();
			if ($____) {
				if ($____->discussion_state == 'moderated') {
					$_____ = $____->FirstPost;
					$______ = $_____->User;
					$_______ = 'allowed';
					$________ = $____->thread_id;
					if ($______->isSpamCheckRequired()) {
						$_________ = $____->title . "\n" . $_____->message;
						$__________ = $this->app->spam()->contentChecker();
						$__________->check($______, $_________, [
							'permalink' => $this->app->router('public')->buildLink('canonical:threads', $____),
							'content_type' => 'thread',
							'content_id' => $________,
						]);
						$_______ = $__________->getFinalDecision();
					}
					if ($_______ == 'allowed') {
						$___________ = $____->scheduled;
						$____->discussion_state = 'visible';
						$____->post_date = $___________;
						$____->last_post_date = $___________;
						$____->set('scheduled', 0, ['forceSet' => true]);
						$____->save(true, false);
						$_____->post_date = $___________;
						$_____->save(true, false);
						$____________ = $this->app->service('XF:Post\Notifier', $_____, 'thread');
						$____________->notifyAndEnqueue(3);
						$_____________ = $this->app->repository('XF:Thread');
						$_____________->markThreadReadByUser($____, $____->User, $___________);
					} else {
						$____->set('scheduled', 0, ['forceSet' => true]);
						$____->save(true, false);
					}
				} else {
					$____->set('scheduled', 0, ['forceSet' => true]);
					$____->save(true, false);
				}
			}
		} else if ($__ == 'resource') {
			$______________ = $this->app->finder('XFRM:ResourceItem')
				->where('resource_id', $___)
				->where('scheduled', '>', 0)
				->fetchOne();
			if ($______________) {
				if ($______________->resource_state == 'moderated') {
					$_______________ = $______________->Description;
					$______ = $______________->User;
					$_______ = 'allowed';
					if ($______->isSpamCheckRequired()) {
						$_________ = $_______________->title . "\n" . $_______________->message;
						$__________ = $this->app->spam()->contentChecker();
						$__________->check($______, $_________, [
							'permalink' => $this->app->router('public')->buildLink('canonical:resources', $______________),
							'content_type' => 'resource_update',
							'content_id' => $_______________->resource_update_id,
						]);
						$_______ = $__________->getFinalDecision();
					}
					if ($_______ == 'allowed') {
						$___________ = $______________->scheduled;
						$______________->resource_state = 'visible';
						$______________->resource_date = $___________;
						$______________->last_update = $___________;
						$______________->set('scheduled', 0, ['forceSet' => true]);
						$______________->save(true, false);
						$________________ = $______________->Discussion;
						if ($________________) {
							$______ = $________________->User;
							$_____ = $________________->FirstPost;
							$_______ = 'allowed';
							if ($______->isSpamCheckRequired()) {
								$_________ = $________________->title . "\n" . $_____->message;
								$__________ = $this->app->spam()->contentChecker();
								$__________->check($______, $_________, [
									'permalink' => $this->app->router('public')->buildLink('canonical:threads', $________________),
									'content_type' => 'thread',
									'content_id' => $________________->thread_id,
								]);
								$_______ = $__________->getFinalDecision();
							}
							if ($_______ == 'allowed') {
								$________________->discussion_state = 'visible';
								$________________->post_date = $___________;
								$________________->last_post_date = $___________;
								$________________->save(true, false);
								$_____->post_date = $___________;
								$_____->save(true, false);
							}
						}
						$____________ = $this->app->service('XFRM:ResourceUpdate\Notify', $_______________, 'resource');
						$____________->notifyAndEnqueue(3);
					} else {
						$______________->set('scheduled', 0, ['forceSet' => true]);
						$______________->save(true, false);
					}
				} else {
					$______________->set('scheduled', 0, ['forceSet' => true]);
					$______________->save(true, false);
				}
			}
		}
		return $this->complete();
	}
	public function getStatusMessage()
	{
		return 'Schedule Thread / Resource Publishing';
	}
	public function canCancel()
	{
		return true;
	}
	public function canTriggerByChoice()
	{
		return true;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */