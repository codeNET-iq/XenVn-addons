<?php
/* Developed by CNet Tools */
namespace CNet\Job\Tools;
use XF\Job\AbstractJob;
class ExternalStorage extends AbstractJob
{
	protected $defaultData = [
		'start' => 0,
		'batch' => 10,
		'type' => 'post',
		'query' => 0,
		'delete' => '',
		'cron' => 0
	];
	public function run($_)
	{
		$__ = $this->app->options();
		$___ = $this->repoUtility();
		$____ = ($this->data['query'] != 'Restore');
		if (!$__->cnet_external_storage)
			return $this->complete();
		if ($this->data['delete']) {
			$___->deleteInExternalStorage($this->data['delete']);
			return $this->complete();
		}
		$_____ = explode(',', $__->cnet_external_storage_ext);
		$______ = intval($__->cnet_external_storage_minsize) * 1024;
		$_______ = 0;
		$________ = microtime(true);
		$_________ = $this->data['start'];
		$__________ = ($this->data['cron'] ? 1 : $this->data['batch']);
		$___________ = '';
		$____________ = [
			['attachment_id', '>', $_________],
			['attach_date', '<', (\XF::$time - 300)],
			['temp_hash', '=', ''],
			['Data.file_size', '>=', $______]
		];
		if ($____)
			$____________[] = ['storage', '<>', 1];
		else
			$____________[] = ['storage', '=', 1];
		if ($this->data['type'] == 'post') {
			$_____________ = [];
			foreach ($__->cnet_external_storage_category as $______________) {
				if (strpos($______________, 'RM') === false)
					$_____________[] = ['Post.Thread.node_id', '=', $______________];
			}
			if (count($_____________)) {
				$___________ = $this->app->finder('XF:Attachment')
					->where('content_type', '=', 'post')
					->where($____________)
					->whereOr($_____________)
					->with('Data')
					->order('attachment_id', 'ASC')
					->limit($__________)
					->fetch();
			}
			if (!count($_____________) || !count($___________)) {
				$this->data['type'] = 'resource_update';
				$this->data['start'] = 0;
				return $this->resume();
			}
			$this->doAction($___________, $____, $_______, $___, $_____, $________, $_);
		} else if ($this->data['type'] == 'resource_update') {
			$_____________ = [];
			foreach ($__->cnet_external_storage_category as $______________) {
				if (strpos($______________, 'RM') !== false) {
					$______________ = intval(str_replace('RM', '', $______________));
					$_____________[] = ['ResourceUpdate.Resource.resource_category_id', '=', $______________];
				}
			}
			if (count($_____________)) {
				$___________ = $this->app->finder('XF:Attachment')
					->where('content_type', '=', 'resource_update')
					->where($____________)
					->whereOr($_____________)
					->with('Data')
					->order('attachment_id', 'ASC')
					->limit($__________)
					->fetch();
			}
			if (!count($_____________) || !count($___________)) {
				$this->data['type'] = 'resource_version';
				$this->data['start'] = 0;
				return $this->resume();
			}
			$this->doAction($___________, $____, $_______, $___, $_____, $________, $_);
		} else if ($this->data['type'] == 'resource_version') {
			$_____________ = [];
			foreach ($__->cnet_external_storage_category as $______________) {
				if (strpos($______________, 'RM') !== false) {
					$______________ = intval(str_replace('RM', '', $______________));
					$_____________[] = ['ResourceVersion.Resource.resource_category_id', '=', $______________];
				}
			}
			if (count($_____________)) {
				$___________ = $this->app->finder('XF:Attachment')
					->where('content_type', '=', 'resource_version')
					->where($____________)
					->whereOr($_____________)
					->with('Data')
					->order('attachment_id', 'ASC')
					->limit($__________)
					->fetch();
			}
			if (!count($_____________) || !count($___________)) {
				$this->data['type'] = 'conversation_message';
				$this->data['start'] = 0;
				return $this->resume();
			}
			$this->doAction($___________, $____, $_______, $___, $_____, $________, $_);
		} else if ($this->data['type'] == 'conversation_message') {
			if ($__->cnet_external_storage_message) {
				$___________ = $this->app->finder('XF:Attachment')
					->where('content_type', '=', 'conversation_message')
					->where($____________)
					->with('Data')
					->order('attachment_id', 'ASC')
					->limit($__________)
					->fetch();
			}
			if (!$__->cnet_external_storage_message || !count($___________)) {
				$this->data['type'] = 'profile_post';
				$this->data['start'] = 0;
				return $this->resume();
			}
			$this->doAction($___________, $____, $_______, $___, $_____, $________, $_);
		} else if ($this->data['type'] == 'profile_post') {
			if ($__->cnet_external_storage_message) {
				$___________ = $this->app->finder('XF:Attachment')
					->where('content_type', '=', 'profile_post')
					->where($____________)
					->with('Data')
					->order('attachment_id', 'ASC')
					->limit($__________)
					->fetch();
			}
			if (!$__->cnet_external_storage_message || !count($___________)) {
				$this->data['type'] = '';
				$this->data['start'] = 0;
				return $this->complete();
			}
			$this->doAction($___________, $____, $_______, $___, $_____, $________, $_);
		}
		$this->data['batch'] = $this->calculateOptimalBatch($this->data['batch'], $_______, $________, $_, 1000);
		if ($this->data['cron'])
			return $this->complete();
		return $this->resume();
	}
	protected function doAction($_, $__, &$___, $____, $_____, $______, $_______)
	{
		foreach ($_ as $________) {
			$this->data['start'] = $________->attachment_id;
			$_________ = $________->Data;
			if (!$_________)
				continue;
			$__________ = $________->getRealFilePath();
			if ($__) {
				if (in_array($_________->extension, $_____)) {
					if ($____->uploadToExternalStorage($__________)) {
						$________->set('storage', 1, ['forceSet' => true]);
						$___________ = fopen($__________, 'c');
						if ($___________) {
							if (flock($___________, LOCK_EX | LOCK_NB)) {
								ftruncate($___________, 0);
								flock($___________, LOCK_UN);
								$________->save(true, false);
							}
							fclose($___________);
						}
					}
				}
			} else {
				if ($____->restoreToInternalStorage($__________, $________->filename)) {
					$________->set('storage', 0, ['forceSet' => true]);
					$________->save(true, false);
				}
			}
			$___++;
			if (microtime(true) - $______ >= $_______)
				break;
		}
	}
	public function getStatusMessage()
	{
		$_ = $this->data['type'];
		$__ = $this->data['start'];
		return "Updating External Storage ($_ / attachment_id: $__)";
	}
	public function canCancel()
	{
		return true;
	}
	public function canTriggerByChoice()
	{
		return true;
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */