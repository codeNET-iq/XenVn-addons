<?php
/* Developed by CNet Tools */
namespace CNet\Attachment;
class ResourceUpdate extends XFCP_ResourceUpdate
{
	public function getConstraints(array $_)
	{
		$__ = parent::getConstraints($_);
		if (!in_array('webp', $__['extensions']))
			$__['extensions'][] = 'webp';
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */