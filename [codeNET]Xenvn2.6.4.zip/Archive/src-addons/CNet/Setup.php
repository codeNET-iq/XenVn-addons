<?php
/* Developed by CNet Tools */
namespace CNet;
use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;
class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;
	public function installStep1()
	{
		$_ = str_replace('\\', '/', \XF::getRootDirectory()) . "\x2f\x73\x72\x63\x2f\x61\x64\x64\x6f\x6e\x73\x2fCNet\x2f\x61\x64\x64\x6f\x6e\x2e\x6a\x73\x6f\x6e";
		$__ = (is_file($_) ? file_get_contents($_) : '');
		if (!$__ || stripos($__, "CNet") === false)
			return;
		$___ = $this->schemaManager();
		$___->alterTable('xf_attachment', function (Alter $____) {
			$____->addColumn('storage', 'boolean')->setDefault(0);
			$____->addColumn('scan', 'varchar', 500)->setDefault('');
		});
		$___->alterTable('xf_thread', function (Alter $____) {
			$____->addColumn('suffix', 'varchar', 50)->setDefault('');
			$____->addColumn('image', 'varchar', 500)->setDefault('');
			$____->addColumn('icon', 'varchar', 500)->setDefault('');
			$____->addColumn('description', 'varchar', 500)->setDefault('');
			$____->addColumn('scheduled', 'int')->setDefault(0);
			$____->addColumn('translation_group', 'int')->setDefault(0);
		});
		$___->alterTable('xf_user', function (Alter $____) {
			$____->addColumn('phone', 'varchar', 50)->setDefault('');
		});
		$____ = 'xf_rm_resource';
		if ($___->tableExists($____)) {
			$___->alterTable($____, function (Alter $____) {
				$____->addColumn('image', 'varchar', 500)->setDefault('');
				$____->addColumn('icon', 'varchar', 500)->setDefault('');
				$____->addColumn('description', 'varchar', 500)->setDefault('');
				$____->addColumn('scheduled', 'int')->setDefault(0);
				$____->addColumn('translation_group', 'int')->setDefault(0);
			});
		}
	}
	public function installStep2()
	{
		$_ = $this->schemaManager();
		$__ = 'xf_translation';
		if ($_->tableExists($__))
			$_->dropTable($__);
		$_->createTable($__, function (Create $__) {
			$__->addColumn('translation_id', 'int')->autoIncrement();
			$__->addColumn('group_id', 'int')->setDefault(0);
			$__->addColumn('content_id', 'int')->setDefault(0);
			$__->addColumn('content_type', 'varchar', 50)->setDefault('');
			$__->addColumn('language_code', 'varchar', 50)->setDefault('');
		});
		$__ = 'xf_download_log';
		if ($_->tableExists($__))
			$_->dropTable($__);
		$_->createTable($__, function (Create $__) {
			$__->addColumn('log_id', 'int')->autoIncrement();
			$__->addColumn('user_id', 'int')->setDefault(0);
			$__->addColumn('attachment_id', 'int')->setDefault(0);
			$__->addColumn('content_id', 'int')->setDefault(0);
			$__->addColumn('category_id', 'int')->setDefault(0);
			$__->addColumn('type', 'varchar', 50)->setDefault('');
			$__->addColumn('ip', 'varchar', 50)->setDefault('');
			$__->addColumn('log_time', 'int')->setDefault(0);
		});
	}
	public function uninstallStep1()
	{
		$_ = $this->schemaManager();
		$_->alterTable('xf_attachment', function (Alter $__) {
			$__->dropColumns('storage');
			$__->dropColumns('scan');
		});
		$_->alterTable('xf_thread', function (Alter $__) {
			$__->dropColumns('suffix');
			$__->dropColumns('image');
			$__->dropColumns('icon');
			$__->dropColumns('description');
			$__->dropColumns('scheduled');
			$__->dropColumns('translation_group');
		});
		$_->alterTable('xf_user', function (Alter $__) {
			$__->dropColumns('phone');
		});
		$__ = 'xf_rm_resource';
		if ($_->tableExists($__)) {
			$_->alterTable($__, function (Alter $__) {
				$__->dropColumns('image');
				$__->dropColumns('icon');
				$__->dropColumns('description');
				$__->dropColumns('scheduled');
				$__->dropColumns('translation_group');
			});
		}
	}
	public function uninstallStep2()
	{
		$_ = $this->schemaManager();
		$__ = 'xf_translation';
		if ($_->tableExists($__))
			$_->dropTable($__);
		$__ = 'xf_download_log';
		if ($_->tableExists($__))
			$_->dropTable($__);
		$___ = $this->app;
		$____ = $___->registry();
		$____->delete(["cnet\x43\x61\x63\x68\x65", 'cnetFontAwesome', 'cnetFontAwesomeCache', 'cnetCodePoints']);
		if (isset($___->options()->captcha)) {
			if ($___->options()->captcha == "CNet\x3a\x49\x6d\x61\x67\x65\x43\x61\x70\x74\x63\x68\x61") {
				$_____ = $___->repository('XF:Option');
				$_____->updateOption('captcha', 'HCaptcha');
			}
		}
	}
	public function upgrade2460Step1()
	{
		$_ = $this->schemaManager();
		if ($_->columnExists('xf_attachment', 'storage')) {
			$_->alterTable('xf_attachment', function (Alter $__) {
				$__->changeColumn('storage', 'boolean')->setDefault(0);
			});
		} else {
			$_->alterTable('xf_attachment', function (Alter $__) {
				$__->addColumn('storage', 'boolean')->setDefault(0);
			});
		}
		$_->alterTable('xf_thread', function (Alter $__) {
			$__->changeColumn('suffix', 'varchar', 50)->setDefault('');
			$__->changeColumn('image', 'varchar', 500)->setDefault('');
			$__->changeColumn('icon', 'varchar', 500)->setDefault('');
			$__->changeColumn('description', 'varchar', 500)->setDefault('');
			$__->changeColumn('scheduled', 'int')->setDefault(0);
		});
		$__ = 'xf_rm_resource';
		if ($_->tableExists($__)) {
			$_->alterTable($__, function (Alter $__) {
				$__->changeColumn('image', 'varchar', 500)->setDefault('');
				$__->changeColumn('description', 'varchar', 500)->setDefault('');
				$__->changeColumn('scheduled', 'int')->setDefault(0);
			});
		}
		$__ = 'xf_download_log';
		if ($_->tableExists($__)) {
			$_->alterTable($__, function (Alter $__) {
				$__->changeColumn('user_id', 'int')->setDefault(0);
				$__->changeColumn('attachment_id', 'int')->setDefault(0);
				$__->changeColumn('content_id', 'int')->setDefault(0);
				$__->changeColumn('category_id', 'int')->setDefault(0);
				$__->changeColumn('type', 'varchar', 50)->setDefault('');
				$__->changeColumn('ip', 'varchar', 50)->setDefault('');
				$__->changeColumn('log_time', 'int')->setDefault(0);
			});
		}
	}
	public function upgrade2490Step1()
	{
		$_ = $this->schemaManager();
		$_->alterTable('xf_attachment', function (Alter $__) {
			$__->addColumn('scan', 'varchar', 500)->setDefault('')->after('storage');
		});
	}
	public function upgrade2500Step1()
	{
		$_ = $this->app;
		$__ = $_->cache();
		if ($__) {
			$__->delete('cnet_patterns_raw');
			$__->delete('cnet_patterns_re');
		}
	}
	public function upgrade2520Step1()
	{
		$_ = $this->schemaManager();
		$_->alterTable('xf_thread', function (Alter $__) {
			$__->dropColumns('dmca');
		});
		$__ = 'xf_rm_resource';
		if ($_->tableExists($__)) {
			$_->alterTable($__, function (Alter $__) {
				$__->dropColumns('dmca');
			});
		}
	}
	public function upgrade2550Step1()
	{
		$_ = $this->schemaManager();
		$__ = 'xf_rm_resource';
		if ($_->tableExists($__) && !$_->columnExists($__, 'icon')) {
			$_->alterTable($__, function (Alter $__) {
				$__->addColumn('icon', 'varchar', 500)->setDefault('')->after('image');
			});
		}
	}
	public function upgrade2580Step1()
	{
		$_ = $this->schemaManager();
		$__ = 'xf_user';
		if ($_->tableExists($__) && !$_->columnExists($__, 'phone')) {
			$_->alterTable($__, function (Alter $__) {
				$__->addColumn('phone', 'varchar', 50)->setDefault('');
			});
		}
	}
	public function upgrade2590Step1()
	{
		$_ = $this->app;
		$__ = $_->cache();
		if ($__) {
			$__->delete("cnet\x43\x61\x63\x68\x65");
			$__->delete('cnetFontAwesome');
		}
	}
	public function upgrade2600Step1()
	{
		$_ = $this->schemaManager();
		$__ = 'xf_thread';
		if (!$_->columnExists($__, 'translation_group')) {
			$_->alterTable($__, function (Alter $__) {
				$__->addColumn('translation_group', 'int')->setDefault(0)->after('scheduled');
			});
		}
		$__ = 'xf_rm_resource';
		if ($_->tableExists($__) && !$_->columnExists($__, 'translation_group')) {
			$_->alterTable($__, function (Alter $__) {
				$__->addColumn('translation_group', 'int')->setDefault(0)->after('scheduled');
			});
		}
		$__ = 'xf_translation';
		if (!$_->tableExists($__)) {
			$_->createTable($__, function (Create $__) {
				$__->addColumn('translation_id', 'int')->autoIncrement();
				$__->addColumn('group_id', 'int')->setDefault(0);
				$__->addColumn('content_id', 'int')->setDefault(0);
				$__->addColumn('content_type', 'varchar', 50)->setDefault('');
				$__->addColumn('language_code', 'varchar', 50)->setDefault('');
			});
		}
		$___ = $this->app();
		$____ = $___->db();
		$____->update('xf_class_extension', ["\x61\x63\x74\x69\x76\x65" => 1], 'to_class=?  AND addon_id=?', ['CNet\Service\Asset\Upload', "CNet"]);
		$___->jobManager()->enqueueUnique(
			'cnetRebuildClassExtension',
			"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
			['job_type' => 'rebuild_class_extensions'],
			false
		);
	}
public function upgrade2611Step1()
{
$___ = $this->schemaManager();
$this->ensureColumns($___, 'xf_attachment', [
'storage' => ['boolean', null, 0],
'scan' => ['varchar', 500, '']
]);
$this->ensureColumns($___, 'xf_thread', [
'suffix' => ['varchar', 50, ''],
'image' => ['varchar', 500, ''],
'icon' => ['varchar', 500, ''],
'description' => ['varchar', 500, ''],
'scheduled' => ['int', null, 0],
'translation_group' => ['int', null, 0]
]);
$this->ensureColumns($___, 'xf_user', [
'phone' => ['varchar', 50, '']
]);
$__ = 'xf_rm_resource';
if ($___->tableExists($__)) {
$this->ensureColumns($___, $__, [
'image' => ['varchar', 500, ''],
'icon' => ['varchar', 500, ''],
'description' => ['varchar', 500, ''],
'scheduled' => ['int', null, 0],
'translation_group' => ['int', null, 0]
]);
}

/*
 * Some earlier CNet/XenVn builds created prefixed columns.  XF does not
 * include those fields in its INSERT statements, so strict MySQL mode
 * rejects new threads and temporary attachments when they are NOT NULL.
 * Keep them harmless for existing installations while the active entities
 * use the canonical XF-compatible column names above.
 */
$this->setLegacyDefaults($___, 'xf_thread', [
'cnet_suffix' => ['varchar', 50, ''],
'cnet_image' => ['varchar', 500, ''],
'cnet_icon' => ['varchar', 500, ''],
'cnet_description' => ['varchar', 500, ''],
'cnet_scheduled' => ['int', null, 0],
'cnet_scheduled_at' => ['int', null, 0],
'cnet_translation_group' => ['int', null, 0]
]);
$this->setLegacyDefaults($___, 'xf_attachment', [
'cnet_storage' => ['boolean', null, 0],
'cnet_scan' => ['varchar', 500, '']
]);
}
public function upgrade2612Step1()
{
/*
 * 2.6.1.1 was distributed before the compatibility migration was reliably
 * reached by every XF upgrade path. Run the legacy-column repair again under
 * a new version ID, using only columns that are actually present.
 */
$___ = $this->schemaManager();
$this->setLegacyDefaults($___, 'xf_thread', [
'cnet_scheduled_at' => ['int', null, 0],
'cnet_scheduled' => ['int', null, 0]
]);
$this->setLegacyDefaults($___, 'xf_attachment', [
'cnet_storage' => ['boolean', null, 0]
]);
}
protected function ensureColumns($schema, $table, array $columns)
{
if (!$schema->tableExists($table)) {
return;
}
$schema->alterTable($table, function (Alter $alter) use ($schema, $table, $columns) {
foreach ($columns as $name => $definition) {
$type = $definition[0];
$length = $definition[1] ?? null;
$default = $definition[2] ?? ($length ?? 0);
if ($schema->columnExists($table, $name)) {
if ($length === null) {
$alter->changeColumn($name, $type)->setDefault($default);
} else {
$alter->changeColumn($name, $type, $length)->setDefault($default);
}
} else if ($length === null) {
$alter->addColumn($name, $type)->setDefault($default);
} else {
$alter->addColumn($name, $type, $length)->setDefault($default);
}
}
});
}
protected function setLegacyDefaults($schema, $table, array $columns)
{
if (!$schema->tableExists($table)) {
return;
}
$schema->alterTable($table, function (Alter $alter) use ($schema, $table, $columns) {
foreach ($columns as $name => $definition) {
if (!$schema->columnExists($table, $name)) {
continue;
}
$type = $definition[0];
$length = $definition[1] ?? null;
$default = $definition[2] ?? ($length ?? 0);
if ($length === null) {
$alter->changeColumn($name, $type)->setDefault($default);
} else {
$alter->changeColumn($name, $type, $length)->setDefault($default);
}
}
});
}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */