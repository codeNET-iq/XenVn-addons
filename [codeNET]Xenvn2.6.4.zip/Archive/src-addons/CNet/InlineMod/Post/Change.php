<?php
/* Developed by CNet Tools */
namespace CNet\InlineMod\Post;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
class Change extends AbstractAction
{
	public function getTitle()
	{
		return \XF::phrase('posting_user...');
	}
	protected function canApplyToEntity(Entity $_, array $__, &$___ = null)
	{
		$____ = \XF::visitor();
		return ($this->app()->options()->cnet_change_post && ($____->is_admin || $____->is_moderator) && $_->canEdit($___));
	}
	protected function applyToEntity(Entity $_, array $__)
	{
		$___ = $_->username;
		$____ = trim($__['new_author']);
		if (!empty($____) && $___ != $____) {
			$_____ = $this->app()->service("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x43\x68\x61\x6e\x67\x65");
			$______ = $this->app()->em()->findOne('XF:User', ['username' => $____]);
			if ($______)
				$_____->updateAuthor($_, $______);
		}
	}
	public function getBaseOptions()
	{
		return [
			'new_author' => ''
		];
	}
	public function renderForm(AbstractCollection $_, Controller $__)
	{
		$___ = \XF::visitor()->timezone;
		date_default_timezone_set($___);
		$____ = [
			'inlinePostChange' => true,
			'time' => time(),
			'posts' => $_,
			'total' => count($_)
		];
		return $__->view("CNet\x3a\x50\x75\x62\x6c\x69\x63\x3a\x49\x6e\x6c\x69\x6e\x65\x4d\x6f\x64\x5c\x50\x6f\x73\x74\x5c\x43\x68\x61\x6e\x67\x65", 'cnet_change_content', $____);
	}
	public function getFormOptions(AbstractCollection $_, Request $__)
	{
		return [
			'new_author' => $__->filter('new_author', 'str')
		];
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */