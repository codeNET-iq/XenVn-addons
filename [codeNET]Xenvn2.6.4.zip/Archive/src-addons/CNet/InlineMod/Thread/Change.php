<?php
/* Developed by CNet Tools */
namespace CNet\InlineMod\Thread;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
class Change extends AbstractAction
{
	public function getTitle()
	{
		return \XF::phrase('thread_starter') . ' & ' . \XF::phrase('edit_date...');
	}
	protected function canApplyToEntity(Entity $_, array $__, &$___ = null)
	{
		$____ = \XF::visitor();
		return ($this->app()->options()->cnet_change_post && ($____->is_admin || $____->is_moderator) && $_->canEdit($___));
	}
	protected function applyToEntity(Entity $_, array $__)
	{
		$___ = $_->FirstPost;
		$____ = $_->username;
		$_____ = trim($__['new_author']);
		if (!empty($_____) && $____ != $_____) {
			$______ = $this->app()->service("CNet\x3a\x54\x68\x72\x65\x61\x64\x5c\x43\x68\x61\x6e\x67\x65");
			$_______ = $this->app()->em()->findOne('XF:User', ['username' => $_____]);
			if ($_______)
				$______->updateAuthor($___, $_______);
		}
		if ($__['change_date']) {
			$________ = $__['new_date'];
			$_________ = $__['new_time'];
			if (!empty($________) && !empty($_________)) {
				$________ = date_parse($________);
				$_________ = date_parse($_________);
				$__________ = \XF::visitor()->timezone;
				$___________ = (new \DateTime())->setTimezone(new \DateTimeZone($__________))
					->setDate($________['year'], $________['month'], $________['day'])
					->setTime($_________['hour'], $_________['minute'])
					->getTimestamp();
				if ($_->post_date != $___________ && $___________ > 0 && $___________ <= \XF::$time) {
					$_->post_date = $___________;
					$_->last_post_date = $___________;
					$_->save(true, false);
					if (!empty($___->last_edit_date)) {
						$___->last_edit_date = $___________;
						$___->save(true, false);
					}
					$____________ = $this->app()->repository('XF:Thread');
					$____________->markThreadReadByVisitor($_, $___________);
				}
			}
		}
	}
	public function getBaseOptions()
	{
		return [
			'new_author' => '',
			'new_date' => '',
			'new_time' => '',
			'change_date' => false
		];
	}
	public function renderForm(AbstractCollection $_, Controller $__)
	{
		$___ = \XF::visitor()->timezone;
		date_default_timezone_set($___);
		$____ = [
			'inlineThreadChange' => true,
			'time' => time(),
			'threads' => $_,
			'total' => count($_)
		];
		return $__->view("CNet\x3a\x50\x75\x62\x6c\x69\x63\x3a\x49\x6e\x6c\x69\x6e\x65\x4d\x6f\x64\x5c\x54\x68\x72\x65\x61\x64\x5c\x43\x68\x61\x6e\x67\x65", 'cnet_change_content', $____);
	}
	public function getFormOptions(AbstractCollection $_, Request $__)
	{
		return [
			'new_author' => $__->filter('new_author', 'str'),
			'new_date' => $__->filter('new_date', 'str'),
			'new_time' => $__->filter('new_time', 'str'),
			'change_date' => $__->filter('change_date', 'bool')
		];
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */