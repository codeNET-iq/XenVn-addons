<?php
/* Developed by CNet Tools */
namespace CNet\InlineMod\ResourceItem;
use XF\Http\Request;
use XF\InlineMod\AbstractAction;
use XF\Mvc\Controller;
use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Entity;
class Change extends AbstractAction
{
	public function getTitle()
	{
		return \XF::phrase('edit_date...');
	}
	protected function canApplyToEntity(Entity $_, array $__, &$___ = null)
	{
		$____ = \XF::visitor();
		return ($this->app()->options()->cnet_change_post && ($____->is_admin || $____->is_moderator) && $_->canEdit($___));
	}
	protected function applyToEntity(Entity $_, array $__)
	{
		$___ = $__['new_date'];
		$____ = $__['new_time'];
		if (!empty($___) && !empty($____)) {
			$___ = date_parse($___);
			$____ = date_parse($____);
			$_____ = \XF::visitor()->timezone;
			$______ = (new \DateTime())->setTimezone(new \DateTimeZone($_____))
				->setDate($___['year'], $___['month'], $___['day'])
				->setTime($____['hour'], $____['minute'])
				->getTimestamp();
			if ($_->resource_date != $______ && $______ > 0 && $______ <= \XF::$time) {
				$_->resource_date = $______;
				$_->last_update = $______;
				$_->save(true, false);
				$_______ = $_->Description;
				if (!empty($_______->last_edit_date)) {
					$_______->last_edit_date = $______;
					$_______->save(true, false);
				}
			}
		}
	}
	public function getBaseOptions()
	{
		return [
			'new_date' => '',
			'new_time' => ''
		];
	}
	public function renderForm(AbstractCollection $_, Controller $__)
	{
		$___ = \XF::visitor()->timezone;
		date_default_timezone_set($___);
		$____ = [
			'inlineResourceChange' => true,
			'time' => time(),
			'resources' => $_,
			'total' => count($_)
		];
		return $__->view("CNet\x3a\x50\x75\x62\x6c\x69\x63\x3a\x49\x6e\x6c\x69\x6e\x65\x4d\x6f\x64\x5c\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x43\x68\x61\x6e\x67\x65", 'cnet_change_content', $____);
	}
	public function getFormOptions(AbstractCollection $_, Request $__)
	{
		return [
			'new_date' => $__->filter('new_date', 'str'),
			'new_time' => $__->filter('new_time', 'str')
		];
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */