<?php
/* Developed by CNet Tools */
namespace CNet\InlineMod;
class ResourceItem extends XFCP_ResourceItem
{
	public function getPossibleActions()
	{
		$_ = parent::getPossibleActions();
		$__ = \XF::visitor();
		if ($this->app()->options()->cnet_change_post && ($__->is_admin || $__->is_moderator))
			$_['change'] = $this->getActionHandler("CNet\x3a\x52\x65\x73\x6f\x75\x72\x63\x65\x49\x74\x65\x6d\x5c\x43\x68\x61\x6e\x67\x65");
		return $_;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */