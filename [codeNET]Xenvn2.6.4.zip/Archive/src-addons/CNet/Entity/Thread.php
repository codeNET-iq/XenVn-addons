<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
use XF\Entity\Post;
use XF\Mvc\Entity\Structure;
class Thread extends XFCP_Thread
{
	public function getLdStructuredData(Post $_, int $__ = 1, array $___ = [])
	{
		$____ = parent::getLdStructuredData($_, $__, $___);
		if ($____['datePublished'] > $____['dateModified'])
			$____['dateModified'] = $____['datePublished'];
		if ($this->app()->options()->cnet_optimal_meta_data)
			$____['image'] = $this->image;
		return $____;
	}
	public function canUpdate()
	{
		$_ = \XF::visitor();
		if (!$_->user_id || $_->user_state != 'valid')
			return false;
		if (!$this->canEdit() && !$_->hasNodePermission($this->node_id, 'update_any_thread'))
			return false;
		$__ = $this->app()->options();
		if ($__->cnet_uptop_time || $__->cnet_update_attachment || $__->cnet_optimal_meta_data || $__->cnet_thread_detail || $__->cnet_multilingual_content)
			return true;
		return false;
	}
	public function canSyncLanguage()
	{
		$_ = \XF::visitor();
		if (!$_->user_id || $_->user_state != 'valid')
			return false;
		if (!$this->canEdit())
			return false;
		$__ = $this->app()->options();
		if ($__->cnet_multilingual_content && ($__->cnet_uptop_time || $__->cnet_thread_suffix) && ($_->is_admin || ($this->user_id == $_->user_id)))
			return true;
		return false;
	}
	public function canLanguage($_ = false)
	{
		$__ = $this->app()->options();
		if (!$__->cnet_multilingual_content)
			return false;
		if ($this->translation_group) {
			if ($_) {
				$___ = \XF::visitor();
				if (!$___->user_id || $___->user_state != 'valid')
					return false;
				if (!$this->canEdit())
					return false;
				if ($this->user_id == $___->user_id || $___->is_admin)
					return true;
				return false;
			}
			return true;
		}
		return false;
	}
	public function canUptop()
	{
		$_ = \XF::$time;
		$__ = false;
		$___ = $this->app()->options()->cnet_uptop_time;
		if ($___) {
			$___ = min($___, 720);
			$___ = $___ * 3600;
			$____ = $this->post_date + $___;
			$_____ = round(($____ - $_) / 60);
			$______ = $this->repoUtility()->convertWaitTime($_____);
			$__ = \XF::phrase('cnet_please_wait_x', ['text' => $______]);
			if ($____ <= $_)
				$__ = '';
		}
		return $__;
	}
	public function isDisableUptop()
	{
		$_ = $this->app()['session.public'];
		return $_->get('cnet_disable_uptop');
	}
	public function getTextLimit()
	{
		$_ = $this->app()->options();
		$__ = \XF::visitor();
		$___ = $__->user_id;
		if (!$_->cnet_limit_download || !$___ || $__->user_state != 'valid' || !in_array($this->node_id, (array)$_->cnet_limit_category))
			return '';
		$____ = $_____ = '';
		if ($this->user_id == $___ || $__->is_admin) {
			$______ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
			$______->setType('Thread');
			$_______ = $______->downloadLogs($this->thread_id, false);
			if ($_______) {
				$____ = \XF::phrase('cnet_download_log_x', ['count' => $_______['count']]);
				$________ = $this->app()->router('public')->buildLink('threads/download-logs', $this);
				$_____ .= '<a class="menu-linkRow" href="' . $________ . '" title="' . $____ . '">' . $____ . '</a>';
			}
		}
		return $_____;
	}
	public function getMessageLimit()
	{
		$_ = $this->app()->options();
		$__ = \XF::visitor();
		$___ = $__->user_id;
		if (!$_->cnet_limit_download || !$___ || $___ == $this->user_id || $__->user_state != 'valid' || !in_array($this->node_id, (array)$_->cnet_limit_category))
			return false;
		$____ = '';
		if (!\XF::visitor()->hasNodePermission($this->node_id, 'viewAttachment'))
			$____ =  \XF::phrase('cnet_you_can_not_download');
		else {
			$_____ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
			$_____->setType('Thread');
			$______ = $_____->listItems($this->node_id, false);
			if ($______) {
				$_______ = ($_->cnet_limit_count_type == 'content' ? \XF::phrase('threads') : \XF::phrase('attachments'));
				if ($______['limitCount'] == -1)
					$____ = '';
				else if ($______['limitCount'] == 0)
					$____ =  \XF::phrase('cnet_you_can_not_download');
				else if ($_____->isUserUpgrade()) {
					$________ = $______['count'] . '/' . $______['limitCount'];
					$_________ = $this->app()->router('public')->buildLink('forums/downloaded-list');
					$____ = \XF::phrase('cnet_you_have_downloaded_x_contents', ['count' => $________, 'contents' => $_______]);
					$____ = '<a href="' . $_________ . '" title="' . \XF::phrase('cnet_downloaded_list') . '">' . $____ . '</a>';
				} else {
					$__________ = $this->repoUtility()->convertWaitTime($_____->getLimitTime());
					$________ = $______['count'] . '/' . $______['limitCount'];
					$_________ = $this->app()->router('public')->buildLink('forums/downloaded-list');
					$____ = \XF::phrase('cnet_you_have_downloaded_x_contents_in_time', ['count' => $________, 'contents' => $_______, 'time' => $__________]);
					$____ = '<a href="' . $_________ . '" title="' . \XF::phrase('cnet_downloaded_list') . '">' . $____ . '</a>';
				}
				if (($_->cnet_force_like == 'download' || $_->cnet_force_like == 'all') && !$__->hasNodePermission($this->node_id, 'cnet_bypass_like_view')) {
					$___________ = \XF::phrase('like');
					$____________ = \XF::phrase('reply');
					$_____________ = \XF::phrase('download');
					$______________ = \XF::phrase('cnet_you_must_x_the_content_to_y', ['action' => $___________, 'result' => $_____________]);
					$_______________ = \XF::phrase('cnet_you_must_x_the_content_to_y', ['action' => "$___________ / $____________", 'result' => $_____________]);
					if ($____)
						$____ .= ' &middot; ';
					$____ .= ($this->reply_count ? $______________ : $_______________);
				}
			} else
				$____ =  \XF::phrase('cnet_you_can_not_download');
		}
		if ($____)
			return '<div class="limitMessage hScroller" data-xf-init="h-scroller"><span class="hScroller-scroll"><span class="limitMessage-icon"></span>' . $____ . '</span></div>';
	}
	public function getRelatedThreads()
	{
		$_ = $this->app()->options()->cnet_related_statistic;
		if (!$_)
			return false;
		$__ = $this->repoUtility()->get_similar_threads($this->title, $this->thread_id, $this->node_id, $_);
		$___ = ([
			'results' => $__,
			'thread_id' => $this->thread_id,
			'node_id' => $this->node_id
		]);
		return $___;
	}
	public function getNextPrevious()
	{
		$_ = $__ = false;
		if ($this->app()->options()->cnet_next_previous_item) {
			$_ = $this->finder('XF:Thread')
				->where('post_date', '>', $this->post_date)
				->where('node_id', $this->node_id)
				->where('discussion_state', 'visible')
				->where('discussion_type', '<>', 'redirect')
				->setDefaultOrder('post_date', 'ASC')
				->fetch(10)
				->filter(function (\XF\Entity\Thread $___) {
					return ($___->canView());
				})
				->shift();
			$__ = $this->finder('XF:Thread')
				->where('post_date', '<', $this->post_date)
				->where('node_id', $this->node_id)
				->where('discussion_state', 'visible')
				->where('discussion_type', '<>', 'redirect')
				->setDefaultOrder('post_date', 'DESC')
				->fetch(10)
				->filter(function (\XF\Entity\Thread $___) {
					return ($___->canView());
				})
				->shift();
		}
		if (!$_ & !$__)
			return false;
		$____ = [
			'next' => $_,
			'previous' => $__
		];
		return $____;
	}
	public function getListImages()
	{
		$_ = $this->FirstPost;
		$__ = $_->Attachments;
		$___ = $_->message;
		return $this->repoUtility()->createListImages($___, $__);
	}
	public function getCoverImage()
	{
		$_ = $this->app()->options();
		if ($_->cnet_view_all_image && ($_->cnet_optimal_meta_data || $_->cnet_thread_detail) && $this->image)
			return $this->image;
		return parent::getCoverImage();
	}
	public function setImage($_ = '', $__ = '', $___ = '')
	{
		$____ = [];
		$_____ = $this->FirstPost;
		if ($_____)
			$____ = $_____->Attachments;
		if ($____ && $_)
			$_ = $_->merge($____);
		else if (!$_)
			$_ = $____;
		if (!$__)
			$__ = $_____->message ?? '';
		$______ = $this->repoUtility()->createImage($_, $__, $this->title, $this->User, $___);
		if ($______['image'] != $this->image)
			$this->set('image', $______['image'], ['forceSet' => true]);
		if ($______['icon'] != $this->icon)
			$this->set('icon', $______['icon'], ['forceSet' => true]);
	}
	public function setDescription($_ = '')
	{
		if (!$_) {
			$__ = $this->FirstPost;
			$_ = $__->message ?? '';
		}
		if ($_) {
			$___ = $this->repoUtility()->createDescription($_);
			if ($___ != $this->description)
				$this->set('description', $___, ['forceSet' => true]);
		}
	}
	public function setSuffix($_)
	{
		$_ = str_replace(['"', "'", "`"], '', $_);
		$_ = preg_replace('/\s+/', ' ', trim($_));
		if (strlen($_) > 20)
			$_ = trim(substr($_, 0, 20));
		if ($_ != $this->suffix)
			$this->set('suffix', $_, ['forceSet' => true]);
	}
	public function setUptop($_ = '')
	{
		$__ = \XF::$time;
		$this->set('post_date', $__, ['forceSet' => true]);
		$this->set('last_post_date', $__, ['forceSet' => true]);
		if (!empty($this->FirstPost->last_edit_date))
			$this->FirstPost->set('last_edit_date', $__, ['forceSet' => true]);
		$___ = $this->app()->repository('XF:Thread');
		$___->markThreadReadByVisitor($this, $__);
		$____ = $this->app()->router('public')->buildLink('threads', $this);
		$this->repoUtility()->sentAlert('thread', $this->thread_id, $this->user_id, $____, $this->title, $this->suffix, $_);
	}
	public function setLanguage($_ = '')
	{
		$__ = '';
		$___ = $this->Language;
		if ($___)
			$__ = $___->language_code;
		$____ = [];
		$_____ = $this->Translation;
		if ($_____) {
			foreach ($_____ as $______) {
				$____[] = $______->language_code;
			}
		}
		if (($_ != $__) || (!$___ && $this->translation_group)) {
			if (!$_) {
				if ($___)
					$___->delete();
				$this->set('translation_group', '', ['forceSet' => true]);
			} else {
				$_______ = $this->repoUtility()->getLanguageList();
				if (isset($_______[$_])) {
					if ($___) {
						if ($____ && in_array($_, $____)) {
							$this->error(\XF::phrase('language_chooser') . ': ' . \XF::phrase('existing') . ' (' . $_ . ')');
							return false;
						}
						$___->set('language_code', $_, ['forceSet' => true]);
						$___->save(true, false);
					} else if ($this->thread_id) {
						$___ = $this->em()->create("CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e");
						$___->content_id = $this->thread_id;
						$___->content_type = 'thread';
						$___->language_code = $_;
						$___->save(true, false);
						$________ = $___->translation_id;
						$___->fastUpdate('group_id', $________);
						$this->set('translation_group', $________, ['forceSet' => true]);
					}
				} else {
					$this->error(\XF::phrase('language_chooser') . ': ' . \XF::phrase('unknown') . ' (' . $_ . ')');
					return false;
				}
			}
		}
		return true;
	}
	public function setWatchThread()
	{
		$_ = \XF::visitor();
		if ($_->user_id && $this->user_id != $_->user_id && $this->canWatch()) {
			$__ = $this->app()->repository('XF:ThreadWatch');
			$__->setWatchState($this, $_, 'watch_no_email');
		}
	}
	public function getIcon($_ = false)
	{
		$__ = $this->app();
		$___ = $__->options();
		$____ = rtrim($___->boardUrl, '/');
		$_____ = '';
		if ($___->cnet_optimal_meta_data)
			$_____ = $this->icon;
		if ($_____ && $_ && \XF::$versionId >= 2030871) {
			$______ = '/(' . preg_quote($____, '/') . '\/)(' . $__->config('externalDataPath') . '\/attachments\/\d+)(\/\d+-[a-z0-9.]+)/i';
			if (preg_match($______, $_____, $_______)) {
				$________ = str_replace('\\', '/', \XF::getRootDirectory()) . '/';
				$_________ = $________ . $_______[2] . '/2x' . $_______[3];
				if (is_file($_________))
					$_____ = $_______[1] . $_______[2] . '/2x' . $_______[3];
			}
		}
		if (!$_____) {
			$__________ = $this->User;
			if ($__________) {
				$_____ = $__________->getAvatarUrl('l', null, true);
				if ($_____)
					$_____ = preg_replace('/\?\d+$/i', '', $_____);
			}
		}
		if (!$_____) {
			$___________ = $___->cnet_default_image ?: "\x73\x74\x79\x6c\x65\x73\x2fCNet\x2f\x6e\x6f\x2d\x69\x6d\x61\x67\x65\x2e\x77\x65\x62\x70";
			$_____ = $____ . '/' . $___________;
		}
		return $_____;
	}
	public function getDescription()
	{
		$_ = $this->app()->options();
		$__ = '';
		if ($_->cnet_optimal_meta_data)
			$__ = $this->description;
		else
			$__ = $this->repoUtility()->createDescription($this->FirstPost->message);
		return $__;
	}
	public function getLanguageList($_ = false)
	{
		$__ = $this->repoUtility()->getLanguageList();
		$___ = $this->Translation;
		$____ = [];
		$_____ = $this->Language;
		if ($_ && $_____)
			$____[] = $_____->language_code;
		if ($___) {
			foreach ($___ as $______) {
				$____[] = $______->language_code;
			}
		}
		if (count($____)) {
			foreach ($____ as $______) {
				if (isset($__[$______]))
					unset($__[$______]);
			}
		}
		return $__;
	}
	public function getDefaultLanguageThread()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_multilingual_content || !$this->translation_group)
			return '';
		$__ = $this->repoUtility()->getDefaultLanguageCode();
		$___ = $this->Language;
		if (!$___ || ($___->language_code == $__))
			return '';
		$____ = $this->Translation;
		if ($____) {
			foreach ($____ as $_____) {
				if ($_____->language_code == $__)
					return $_____->Thread;
			}
		}
		return '';
	}
	protected function getDefaultLanguageAttachments()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_multilingual_content || !$_->cnet_sync_attachments_language || !$this->translation_group)
			return '';
		$__ = $this->repoUtility();
		$___ = $__->getDefaultLanguageCode();
		$____ = $__->getLanguageList();
		$_____ = $this->Language;
		if (!$_____ || ($_____->language_code == $___))
			return '';
		$______ = $this->Translation;
		if ($______) {
			foreach ($______ as $_______) {
				if ($_______->language_code == $___) {
					$________ = $_______->Thread;
					if ($________) {
						$_________ = $________->FirstPostAttachments;
						$__________ = $____[$___];
						if ($_________) {
							$___________ = $________->FirstPost;
							foreach ($_________ as $____________ => $_____________) {
								if ($___________->isAttachmentEmbedded($_____________->attachment_id))
									unset($_________[$____________]);
								else
									$_____________->getInLanguage($__________);
							}
							return $_________;
						}
					}
				}
			}
		}
		return '';
	}
	public function getFullAttachments($_ = null)
	{
		$__ = $this->getDefaultLanguageAttachments();
		if ($_ && $__)
			return $__->merge($_);
		else if (!$__)
			return $_;
		else if (!$_)
			return $__;
		return null;
	}
	public function rebuildFirstPostInfo()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_uptop_time && !$_->cnet_change_post)
			return parent::rebuildFirstPostInfo();
		$__ = $this->db()->fetchRow("
			SELECT post_id, post_date, user_id, username, reaction_score, reactions
			FROM xf_post USE INDEX (thread_id_post_date)
			WHERE thread_id = ?
			ORDER BY post_date
			LIMIT 1
		", $this->thread_id);
		if (!$__)
			return false;
		$this->first_post_id = $__['post_id'];
		$this->user_id = $__['user_id'];
		$this->username = $__['username'] ?: '-';
		$this->first_post_reaction_score = $__['reaction_score'];
		$this->first_post_reactions = $__['reactions'] ? @json_decode($__['reactions'], true) : [];
		$___ = $__['post_date'];
		if ($this->post_date > $___ || ($this->post_date == $this->last_post_date && $this->post_date != $___))
			return true;
		$this->post_date = $___;
		return true;
	}
	public function rebuildLastPostInfo()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_uptop_time && !$_->cnet_change_post)
			return parent::rebuildLastPostInfo();
		$__ = $this->db()->fetchRow("
			SELECT post_id, post_date, user_id, username
			FROM xf_post USE INDEX (thread_id_post_date)
			WHERE thread_id = ?
				AND message_state = 'visible'
			ORDER BY post_date DESC
			LIMIT 1
		", $this->thread_id);
		if (!$__)
			return false;
		$this->last_post_id = $__['post_id'];
		$this->last_post_user_id = $__['user_id'];
		$this->last_post_username = $__['username'] ?: '-';
		$___ = $__['post_date'];
		if ($this->post_date > $___ || ($this->post_date == $this->last_post_date && $this->post_date != $___))
			return true;
		$this->last_post_date = $___;
		return true;
	}
	protected function _preSave()
	{
		if ($this->app()->options()->cnet_block_duplicate_title && $this->isChanged('title')) {
			$_ = $this->title;
			if (function_exists('mb_strlen'))
				$__ = mb_strlen($_);
			else
				$__ = strlen($_);
			if ($__ < 3) {
				$this->error(\XF::phrase('cnet_title_length_min_3'));
				return false;
			} else {
				$___ = str_replace(['"', "'", "`"], '', $_);
				$____ = $this->finder('XF:Thread')
					->whereOR(['discussion_state', '=', 'visible'], ['scheduled', '>', 0])
					->where('discussion_type', '<>', 'redirect')
					->where('thread_id', '<>', $this->thread_id)
					->where('node_id', '=', $this->node_id)
					->where('title', 'LIKE', $___)
					->fetchOne();
				if ($____) {
					$_____ = $this->app()->router('public')->buildLink('threads', $____);
					$this->error(\XF::phrase('cnet_title_exists_x', ['link' => $_____]));
					return false;
				}
			}
		}
		return parent::_preSave();
	}
	protected function _postDelete()
	{
		parent::_postDelete();
		if ($this->Language)
			$this->Language->delete();
	}
	public static function getStructure(Structure $_)
	{
		$_ = parent::getStructure($_);
		$_->columns += [
			'suffix' => ['type' => self::STR, 'default' => ''],
			'image' => ['type' => self::STR, 'default' => ''],
			'icon' => ['type' => self::STR, 'default' => ''],
			'description' => ['type' => self::STR, 'default' => ''],
			'scheduled' => ['type' => self::UINT, 'default' => 0],
			'translation_group' => ['type' => self::UINT, 'default' => 0]
		];
		$_->relations += [
			'Translation' => [
				'entity' => "CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e",
				'type' => self::TO_MANY,
				'conditions' => [
					['group_id', '=', '$translation_group'],
					['content_type', '=', 'thread'],
					['content_id', '<>', '$thread_id']
				],
				'with' => ['Thread']
			],
			'Language' => [
				'entity' => "CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e",
				'type' => self::TO_ONE,
				'conditions' => [
					['group_id', '=', '$translation_group'],
					['content_id', '=', '$thread_id'],
					['content_type', '=', 'thread']
				]
			],
			'FirstPostAttachments' => [
				'entity' => 'XF:Attachment',
				'type' => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'post'],
					['content_id', '=', '$first_post_id']
				]
			],
		];
		$_->withAliases['full'][] = 'LastPost';
		$_->withAliases += [
			'Statistic' => [
				'User',
				'LastPoster',
				'LastPost',
				function () {
					$__ = ['Forum', 'Forum.Node'];
					$___ = \XF::visitor();
					$____ = $___->user_id;
					if ($____) {
						$__[] = 'Read|' . $____;
						$__[] = 'Forum.Read|' . $____;
					}
					$__[] = 'Forum.Node.Permissions|' . $___->permission_combination_id;
					return $__;
				}
			]
		];
		return $_;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */