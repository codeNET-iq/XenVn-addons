<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
class Translation extends Entity
{
	public static function getStructure(Structure $_)
	{
		$_->table = 'xf_translation';
		$_->shortName = "CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e";
		$_->primaryKey = 'translation_id';
		$_->columns = [
			'translation_id' => ['type' => self::UINT, 'autoIncrement' => true],
			'group_id' => ['type' => self::UINT, 'default' => 0],
			'content_id' => ['type' => self::UINT, 'default' => 0],
			'content_type' => ['type' => self::STR, 'default' => ''],
			'language_code' => ['type' => self::STR, 'default' => '']
		];
		$_->getters = [];
		$_->relations = [
			'Thread' => [
				'entity' => 'XF:Thread',
				'type' => self::TO_ONE,
				'conditions' => [
					['thread_id', '=', '$content_id'],
					['translation_group', '=', '$group_id']
				],
				'with' => ['User', 'FirstPost']
			],
			'ResourceItem' => [
				'entity' => 'XFRM:ResourceItem',
				'type' => self::TO_ONE,
				'conditions' => [
					['resource_id', '=', '$content_id'],
					['translation_group', '=', '$group_id']
				],
				'with' => ['User', 'CurrentVersion']
			]
		];
		return $_;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */