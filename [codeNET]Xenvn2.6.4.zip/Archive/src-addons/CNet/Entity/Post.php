<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
class Post extends XFCP_Post
{
	public function hasLikePost()
	{
		$_ = \XF::visitor();
		$__ = $_->user_id;
		if (!$__ || $_->user_state != 'valid')
			return false;
		if ($this->user_id == $__ || $this->Thread->user_id == $__)
			return true;
		if ($this->isFirstPost()) {
			foreach ($this->Thread->UserPosts as $___) {
				if ($___->user_id == $__) {
					return true;
					break;
				}
			}
		}
		foreach ($this->Reactions as $____) {
			if ($____->reaction_user_id == $__ && $____->Reaction->reaction_score > 0) {
				return true;
				break;
			}
		}
		return false;
	}
	protected function parseMessage()
	{
		$_ = $this->app();
		$__ = $_->options();
		$___ = \XF::visitor();
		if (!$___->user_id)
			return;
		$____ = $this->repoUtility();
		if ($__->cnet_convert_external_image && $___->hasNodePermission($this->Thread->node_id, 'uploadAttachment') && $this->attach_count < $__->attachmentMaxPerMessage) {
			if ($____->checkExtImages($this->message))
				$this->app()->jobManager()->enqueueAutoBlocking("CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x43\x6f\x6e\x76\x65\x72\x74\x49\x6d\x61\x67\x65", ['id' => $this->post_id, 'type' => 'post']);
		}
		if ($__->cnet_add_redirect_page && $____->checkRedirectURL($this->message)) {
			$_->jobManager()->enqueueUnique(
				'cnetConvertRedirectPost' . $this->post_id,
				"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
				['job_type' => 'convert_redirect', 'id' => $this->post_id, 'content_type' => 'post'],
				false
			);
		}
	}
	protected function _postSave()
	{
		parent::_postSave();
		if ($this->isChanged('message'))
			$this->parseMessage();
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */