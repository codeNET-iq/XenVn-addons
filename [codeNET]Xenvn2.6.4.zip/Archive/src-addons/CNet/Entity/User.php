<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
use XF\Mvc\Entity\Structure;
class User extends XFCP_User
{
	protected $_ = null;
	public function getControlPanel()
	{
		$__ = $this->user_id;
		$___ = $this->repoUtility();
		$____ = 'control_panel' . $__;
		$_____ = $___->getXFCache($____);
		if (!$_____) {
			$_____ = [];
			$______ = $this->app()->router('public');
			$_____[] = [
				'name' => strval(\XF::phrase('your_content')),
				'link' => strval($______->buildLink('search/member', null, ['user_id' => $this->user_id])),
				'count' => intval($this->message_count),
				'id' => ''
			];
			$_______ = $this->finder('XF:Thread')
				->where('discussion_state', 'visible')
				->where('discussion_type', '<>', 'redirect')
				->where('user_id', $__)
				->total();
			$_____[] = [
				'name' => strval(\XF::phrase('your_threads')),
				'link' => strval($______->buildLink('find-threads/started')),
				'count' => intval($_______),
				'id' => ''
			];
			$________ = \XF::$time - $this->app()->options()->readMarkingDataLifetime * 86400;
			$_______ = $this->finder('XF:Thread')
				->where('discussion_state', 'visible')
				->where('discussion_type', '<>', 'redirect')
				->where('last_post_date', '>', $________)
				->indexHint('FORCE', 'last_post_date');
			$_______ = $_______->unreadOnly($__)->total();
			$_____[] = [
				'name' => strval(\XF::phrase('unread_threads')),
				'link' => strval($______->buildLink('whats-new/posts')),
				'count' => intval($_______),
				'id' => ''
			];
			$_______ = $this->finder('XF:Thread')
				->with('Watch|' . $__, true)
				->where('discussion_state', 'visible')
				->total();
			$_____[] = [
				'name' => strval(\XF::phrase('watched_threads')),
				'link' => strval($______->buildLink('watched/threads')),
				'count' => intval($_______),
				'id' => ''
			];
			$_________ = $this->app()->addonManager()->getById('XFRM');
			if ($_________ && $_________->isActive()) {
				$_____[] = [
					'name' => strval(\XF::phrase('xfrm_your_resources')),
					'link' => strval($______->buildLink('resources/authors', $this)),
					'count' => intval($this->xfrm_resource_count),
					'id' => ''
				];
				$_______ = $this->finder('XFRM:ResourceItem')
					->with('Watch|' . $__, true)
					->where('resource_state', 'visible')
					->total();
				$_____[] = [
					'name' => strval(\XF::phrase('xfrm_watched_resources')),
					'link' => strval($______->buildLink('watched/resources')),
					'count' => intval($_______),
					'id' => ''
				];
			}
			$_____[] = [
				'name' => strval(\XF::phrase('reaction_score')),
				'link' => strval($______->buildLink('account/reactions')),
				'count' => intval($this->reaction_score),
				'id' => ''
			];
			if (\XF::$versionId < 2030035) {
				$_____[] = [
					'name' => strval(\XF::phrase('conversations')),
					'link' => strval($______->buildLink('conversations')),
					'count' => intval($this->conversations_unread),
					'id' => 'cnet-conversations'
				];
			} else {
				$_____[] = [
					'name' => strval(\XF::phrase('direct_messages')),
					'link' => strval($______->buildLink('direct-messages')),
					'count' => intval($this->conversations_unread),
					'id' => 'cnet-conversations'
				];
			}
			$_____[] = [
				'name' => strval(\XF::phrase('alerts')),
				'link' => strval($______->buildLink('account/alerts')),
				'count' => intval($this->alerts_unviewed),
				'id' => 'cnet-alerts'
			];
			$___->setXFCache($____, $_____);
		}
		return $_____;
	}
	protected function verifyEmail(&$__)
	{
		$___ = parent::verifyEmail($__);
		if ($___ == false)
			return false;
		if (!empty($__)) {
			$____ = $this->app()->options();
			$_____ = $____->cnet_email_whitelist;
			$______ = explode('@', $__);
			if (!is_array($______) || count($______) != 2) {
				$this->error(\XF::phrase('please_enter_valid_email'), 'email');
				return false;
			}
			$_______ = $______[0];
			$________ = strtolower($______[1]);
			if ($_____) {
				$_________ = false;
				$__________ = explode(',', $_____);
				array_filter($__________);
				if (empty($________) || in_array($________, $__________))
					$_________ = true;
				if (!$_________) {
					$___________ = str_replace(',', ', ', $_____);
					$this->error(\XF::phrase('accept') . ': ' . $___________, 'email');
					return false;
				}
			}
			if ($____->cnet_login_security) {
				if (preg_match('/[^a-z0-9-_.]/i', $_______, $____________)) {
					$this->error(\XF::phrase('value_x_is_not_valid_email_address', ['email' => $__]) . ' (' . \XF::phrase('accept') . ': a-z 0-9 - _ .)', 'email');
					return false;
				}
				if (strlen($_______) < 5 || strlen($_______) > 30 || strlen($________) < 6 || strlen($________) > 30) {
					$this->error(\XF::phrase('value_x_is_not_valid_email_address', ['email' => $__]) . ' (' . \XF::phrase('spam') . ')', 'email');
					return false;
				}
				if (preg_match('/([a-z0-9][^a-z0-9]){3,}/', $_______, $____________)) {
					$this->error(\XF::phrase('value_x_is_not_valid_email_address', ['email' => $__]) . ' (' . \XF::phrase('spam') . ')', 'email');
					return false;
				}
				preg_match_all('/[^a-z0-9]/i', $_______, $_____________);
				if (isset($_____________[0]) && count($_____________[0]) > 4) {
					$this->error(\XF::phrase('value_x_is_not_valid_email_address', ['email' => $__]) . ' (' . \XF::phrase('spam') . ')', 'email');
					return false;
				}
			}
		}
		return $___;
	}
	public function getYearOfJoining($__ = false)
	{
		$___ = 0;
		$____ = $this->register_date;
		if ($____) {
			$_____ = \XF::$time - $____;
			$___ = floor($_____ / 31536000);
			if (!$__)
				return $___;
			if ($___ < 1) {
				$______ = floor($_____ / 2592000);
				if ($______ < 1)
					return '';
				return ' (' . \XF::phrase('x_months', ['months' => $______]) . ')';
			}
			return ' (' . \XF::phrase('x_years', ['years' => $___]) . ')';
		}
	}
	public function isUpgradeUser()
	{
		if ($this->_ !== null)
			return $this->_;
		$__ = $this->finder('XF:UserUpgradeActive')
			->where('user_id', $this->user_id)
			->whereOR(['end_date', '>=', \XF::$time], ['end_date', '0'])
			->fetchOne();
		$__ = ($__ ? true : false);
		$this->_ = $__;
		return $__;
	}
	public function isShownCaptcha()
	{
		$__ = $this->app()->options();
		$___ = $__->cnet_demo_user;
		if ($___ && $this->user_id) {
			$____ = explode(',', $___);
			if ($____ && in_array($this->user_id, $____))
				return true;
		}
		$_____ = $__->cnet_captcha_new_users;
		if (!$_____ || $this->register_date < (\XF::$time - ($_____ * 86400)) || $this->is_admin || $this->is_moderator || $this->isUpgradeUser())
			return parent::isShownCaptcha();
		return true;
	}
	public function getAjaxSearch()
	{
		if (!$this->canSearch())
			return '';
		$__ = $this->app()->options();
		$___ = [];
		if ($__->cnet_ajax_default_search)
			$___[] = 'input[name=keywords]';
		if ($__->cnet_ajax_quick_search)
			$___[] = 'input[name=cnet_quick_search]';
		if ($__->cnet_ajax_title_search)
			$___[] = 'textarea[name=title], input[name=title]';
		if ($__->cnet_multilingual_content)
			$___[] = 'input[name=cnet_search_url]';
		if (count($___))
			return implode(', ', $___);
		return '';
	}
	public function getPhone($__ = false)
	{
		if ($this->app()->options()->cnet_sms_verify && $this->phone && preg_match('/^\+[0-9]{7,15}$/', $this->phone)) {
			if (!$__)
				return $this->phone;
			$___ = strlen($this->phone);
			if ($___ <= 9)
				return substr($this->phone, 0, $___ - 4) . '****';
			return substr($this->phone, 0, $___ - 5) . '*****';
		}
		return '';
	}
	public static function getStructure(Structure $__)
	{
		$__ = parent::getStructure($__);
		$__->columns += [
			'phone' => ['type' => self::STR, 'default' => ''],
		];
		return $__;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */