<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
use XF\Mvc\Entity\Structure;
class ResourceItem extends XFCP_ResourceItem
{
	public function canUpdate()
	{
		$_ = \XF::visitor();
		if (!$_->user_id || $_->user_state != 'valid')
			return false;
		if (!$this->canEdit() && !$_->hasResourceCategoryPermission($this->resource_category_id, 'update_any_resource'))
			return false;
		$__ = $this->app()->options();
		if ($__->cnet_uptop_time || $__->cnet_update_attachment || $__->cnet_optimal_meta_data || $__->cnet_multilingual_content)
			return true;
		return false;
	}
	public function canSyncLanguage()
	{
		$_ = \XF::visitor();
		if (!$_->user_id || $_->user_state != 'valid')
			return false;
		if (!$this->canEdit())
			return false;
		$__ = $this->app()->options();
		if ($__->cnet_multilingual_content && ($_->is_admin || ($this->user_id == $_->user_id)))
			return true;
		return false;
	}
	public function canLanguage($_ = false)
	{
		$__ = $this->app()->options();
		if (!$__->cnet_multilingual_content)
			return false;
		if ($this->translation_group) {
			if ($_) {
				$___ = \XF::visitor();
				if (!$___->user_id || $___->user_state != 'valid')
					return false;
				if (!$this->canEdit())
					return false;
				if ($this->user_id == $___->user_id || $___->is_admin)
					return true;
				return false;
			}
			return true;
		}
		return false;
	}
	public function canUptop()
	{
		$_ = \XF::$time;
		$__ = false;
		$___ = $this->app()->options()->cnet_uptop_time;
		if ($___) {
			$___ = min($___, 720);
			$___ = $___ * 3600;
			$____ = $this->resource_date + $___;
			$_____ = round(($____ - $_) / 60);
			$______ = $this->repoUtility()->convertWaitTime($_____);
			$__ = \XF::phrase('cnet_please_wait_x', ['text' => $______]);
			if ($____ <= $_)
				$__ = '';
		}
		return $__;
	}
	public function isDisableUptop()
	{
		$_ = $this->app()['session.public'];
		return $_->get('cnet_disable_uptop');
	}
	public function getTextLimit()
	{
		$_ = $this->app()->options();
		$__ = \XF::visitor();
		$___ = $__->user_id;
		if (!$_->cnet_limit_download || !$___ || $__->user_state != 'valid' || !in_array('RM' . $this->resource_category_id, (array)$_->cnet_limit_category))
			return '';
		$____ = $_____ = '';
		if ($this->user_id == $___ || $__->is_admin) {
			$______ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
			$______->setType('Resource');
			$_______ = $______->downloadLogs($this->resource_id, false);
			if ($_______) {
				$____ = \XF::phrase('cnet_download_log_x', ['count' => $_______['count']]);
				$________ = $this->app()->router('public')->buildLink('resources/download-logs', $this);
				$_____ .= '<a class="menu-linkRow" href="' . $________ . '" title="' . $____ . '">' . $____ . '</a>';
			}
		}
		return $_____;
	}
	public function getMessageLimit()
	{
		$_ = $this->app()->options();
		$__ = \XF::visitor();
		$___ = $__->user_id;
		if (!$_->cnet_limit_download || !$___ || $___ == $this->user_id || $__->user_state != 'valid' || !in_array('RM' . $this->resource_category_id, (array)$_->cnet_limit_category))
			return false;
		$____ = '';
		if (!$this->canDownload())
			$____ =  \XF::phrase('cnet_you_can_not_download');
		else {
			$_____ = $this->repository("CNet\x3a\x4c\x69\x6d\x69\x74");
			$_____->setType('Resource');
			$______ = $_____->listItems($this->resource_category_id, false);
			if ($______) {
				$_______ = ($_->cnet_limit_count_type == 'content' ? \XF::phrase('xfrm_resources') : \XF::phrase('attachments'));
				if ($______['limitCount'] == -1)
					$____ = '';
				else if ($______['limitCount'] == 0)
					$____ =  \XF::phrase('cnet_you_can_not_download');
				else if ($_____->isUserUpgrade()) {
					$________ = $______['count'] . '/' . $______['limitCount'];
					$_________ = $this->app()->router('public')->buildLink('resources/downloaded-list');
					$____ = \XF::phrase('cnet_you_have_downloaded_x_contents', ['count' => $________, 'contents' => $_______]);
					$____ = '<a href="' . $_________ . '" title="' . \XF::phrase('cnet_downloaded_list') . '">' . $____ . '</a>';
				} else {
					$__________ = $this->repoUtility()->convertWaitTime($_____->getLimitTime());
					$________ = $______['count'] . '/' . $______['limitCount'];
					$_________ = $this->app()->router('public')->buildLink('resources/downloaded-list');
					$____ = \XF::phrase('cnet_you_have_downloaded_x_contents_in_time', ['count' => $________, 'contents' => $_______, 'time' => $__________]);
					$____ = '<a href="' . $_________ . '" title="' . \XF::phrase('cnet_downloaded_list') . '">' . $____ . '</a>';
				}
				if (($_->cnet_force_like == 'download' || $_->cnet_force_like == 'all') && !$__->hasResourceCategoryPermission($this->resource_category_id, 'cnet_bypass_like_view')) {
					$___________ = \XF::phrase('like');
					$____________ = \XF::phrase('reply');
					$_____________ = \XF::phrase('download');
					if ($____)
						$____ .= ' &middot; ';
					$____ .= \XF::phrase('cnet_you_must_x_the_content_to_y', ['action' => "$___________ / $____________", 'result' => $_____________]);
				}
			} else
				$____ =  \XF::phrase('cnet_you_can_not_download');
		}
		if ($____)
			return '<div class="limitMessage hScroller" data-xf-init="h-scroller"><span class="hScroller-scroll"><span class="limitMessage-icon"></span>' . $____ . '</span></div>';
	}
	public function getRelatedResources()
	{
		$_ = $this->app()->options()->cnet_related_statistic;
		if (!$_)
			return false;
		$__ = $this->repoUtility()->get_similar_resources($this->title, $this->resource_id, $this->resource_category_id, $_);
		$___ = ([
			'results' => $__,
			'resource_id' => $this->resource_id,
			'resource_category_id' => $this->resource_category_id
		]);
		return $___;
	}
	public function getNextPrevious()
	{
		$_ = $__ = false;
		if ($this->app()->options()->cnet_next_previous_item) {
			$_ = $this->finder('XFRM:ResourceItem')
				->where('resource_date', '>', $this->resource_date)
				->where('resource_category_id', $this->resource_category_id)
				->where('resource_state', 'visible')
				->setDefaultOrder('resource_date', 'ASC')
				->fetch(10)
				->filter(function (\XFRM\Entity\ResourceItem $___) {
					return ($___->canView());
				})
				->shift();
			$__ = $this->finder('XFRM:ResourceItem')
				->where('resource_date', '<', $this->resource_date)
				->where('resource_category_id', $this->resource_category_id)
				->where('resource_state', 'visible')
				->setDefaultOrder('resource_date', 'DESC')
				->fetch(10)
				->filter(function (\XFRM\Entity\ResourceItem $___) {
					return ($___->canView());
				})
				->shift();
		}
		if (!$_ & !$__)
			return false;
		$____ = [
			'next' => $_,
			'previous' => $__
		];
		return $____;
	}
	public function getListImages()
	{
		$_ = $this->Description;
		$__ = $_->Attachments;
		$___ = $_->message;
		return $this->repoUtility()->createListImages($___, $__);
	}
	public function setImage($_ = '', $__ = '', $___ = '')
	{
		$____ = [];
		$_____ =  $this->Description;
		if ($_____)
			$____ = $_____->Attachments;
		if ($____ && $_)
			$_ = $_->merge($____);
		else if (!$_)
			$_ = $____;
		if (!$__)
			$__ = $_____->message ?? '';
		$______ = $this->repoUtility()->createImage($_, $__, $this->title, $this->User, $___);
		if ($______['image'] != $this->image)
			$this->set('image', $______['image'], ['forceSet' => true]);
		if ($______['icon'] != $this->icon)
			$this->set('icon', $______['icon'], ['forceSet' => true]);
	}
	public function setDescription($_ = '')
	{
		if (!$_) {
			$__ = $this->Description;
			$_ = $__->message ?? '';
		}
		if ($_) {
			$__ = $this->repoUtility()->createDescription($_);
			if ($__ != $this->description)
				$this->set('description', $__, ['forceSet' => true]);
		}
	}
	public function setUptop($_ = '')
	{
		$__ = \XF::$time;
		$this->set('resource_date', $__, ['forceSet' => true]);
		$this->set('last_update', $__, ['forceSet' => true]);
		if (!empty($this->Description->last_edit_date))
			$this->Description->set('last_edit_date', $__, ['forceSet' => true]);
		$___ = $this->CurrentVersion;
		$____ = ($___ ? $___->version_string : '');
		$_____ = $this->app()->router('public')->buildLink('resources', $this);
		$this->repoUtility()->sentAlert('resource', $this->resource_id, $this->user_id, $_____, $this->title, $____, $_);
	}
	public function setLanguage($_ = '')
	{
		$__ = '';
		$___ = $this->Language;
		if ($___)
			$__ = $___->language_code;
		$____ = [];
		$_____ = $this->Translation;
		if ($_____) {
			foreach ($_____ as $______) {
				$____[] = $______->language_code;
			}
		}
		if (($_ != $__) || (!$___ && $this->translation_group)) {
			if (!$_) {
				if ($___)
					$___->delete();
				$this->set('translation_group', '', ['forceSet' => true]);
			} else {
				$_______ = $this->repoUtility()->getLanguageList();
				if (isset($_______[$_])) {
					if ($___) {
						if ($____ && in_array($_, $____)) {
							$this->error(\XF::phrase('language_chooser') . ': ' . \XF::phrase('existing') . ' (' . $_ . ')');
							return false;
						}
						$___->set('language_code', $_, ['forceSet' => true]);
						$___->save(true, false);
					} else if ($this->resource_id) {
						$___ = $this->em()->create("CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e");
						$___->content_id = $this->resource_id;
						$___->content_type = 'resource';
						$___->language_code = $_;
						$___->save(true, false);
						$________ = $___->translation_id;
						$___->fastUpdate('group_id', $________);
						$this->set('translation_group', $________, ['forceSet' => true]);
					}
				} else {
					$this->error(\XF::phrase('language_chooser') . ': ' . \XF::phrase('unknown') . ' (' . $_ . ')');
					return false;
				}
			}
		}
		return true;
	}
	public function setWatchResource()
	{
		$_ = \XF::visitor();
		if ($_->user_id && $this->user_id != $_->user_id && $this->canWatch()) {
			$__ = $this->app()->repository('XFRM:ResourceWatch');
			$__->setWatchState($this, $_, 'watch');
		}
	}
	public function hasLikeResource()
	{
		$_ = \XF::visitor();
		$__ = $_->user_id;
		if (!$__ || $_->user_state != 'valid')
			return false;
		if ($this->user_id == $__)
			return true;
		$___ = $this->Discussion;
		if ($___) {
			foreach ($___->UserPosts as $____) {
				if ($____->user_id == $__) {
					return true;
					break;
				}
			}
		}
		foreach ($this->Description->Reactions as $_____) {
			if ($_____->reaction_user_id == $__ && $_____->Reaction->reaction_score > 0) {
				return true;
				break;
			}
		}
		return false;
	}
	public function getIcon($_ = false)
	{
		$__ = $this->app()->options();
		$___ = rtrim($__->boardUrl, '/');
		$____ = '';
		if ($_)
			$____ = $this->icon;
		if (!$____) {
			if ($__->xfrmAllowIcons) {
				$____ = $this->getIconUrl(null, true);
				if ($____)
					$____ = preg_replace('/\?\d+$/i', '', $____);
			}
			if (!$____) {
				$_____ = $this->User;
				if ($_____) {
					$____ = $_____->getAvatarUrl('l', null, true);
					if ($____)
						$____ = preg_replace('/\?\d+$/i', '', $____);
				}
			}
		}
		if (!$____) {
			$______ = $__->cnet_default_image ?: "\x73\x74\x79\x6c\x65\x73\x2fCNet\x2f\x6e\x6f\x2d\x69\x6d\x61\x67\x65\x2e\x77\x65\x62\x70";
			$____ = $___ . '/' . $______;
		}
		return $____;
	}
	public function getDescription()
	{
		$_ = $this->app()->options();
		$__ = '';
		if ($_->cnet_optimal_meta_data)
			$__ = $this->description;
		else
			$__ = $this->repoUtility()->createDescription($this->Description->message);
		return $__;
	}
	public function getLanguageList($_ = false)
	{
		$__ = $this->repoUtility()->getLanguageList();
		$___ = $this->Translation;
		$____ = [];
		$_____ = $this->Language;
		if ($_ && $_____)
			$____[] = $_____->language_code;
		if ($___) {
			foreach ($___ as $______) {
				$____[] = $______->language_code;
			}
		}
		if (count($____)) {
			foreach ($____ as $______) {
				if (isset($__[$______]))
					unset($__[$______]);
			}
		}
		return $__;
	}
	public function getDefaultLanguageResources()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_multilingual_content || !$this->translation_group)
			return '';
		$__ = $this->repoUtility()->getDefaultLanguageCode();
		$___ = $this->Language;
		if (!$___ || ($___->language_code == $__))
			return '';
		$____ = $this->Translation;
		if ($____) {
			foreach ($____ as $_____) {
				if ($_____->language_code == $__)
					return $_____->ResourceItem;
			}
		}
		return '';
	}
	public function rebuildLastUpdateInfo()
	{
		$_ = $this->app()->options();
		if (!$_->cnet_uptop_time && !$_->cnet_change_post)
			return parent::rebuildLastUpdateInfo();
		$__ = $this->db()->fetchRow("
			SELECT *
			FROM xf_rm_resource_update
			WHERE resource_id = ?
				AND message_state = 'visible'
			ORDER BY post_date DESC
			LIMIT 1
		", $this->resource_id);
		if (!$__)
			return false;
		$___ = $__['post_date'];
		if ($this->resource_date > $___ || ($this->resource_date == $this->last_update && $this->resource_date != $___))
			return true;
		$this->last_update = $___;
		return true;
	}
	protected function _preSave()
	{
		if ($this->app()->options()->cnet_block_duplicate_title && $this->isChanged('title')) {
			$_ = $this->title;
			if (function_exists('mb_strlen'))
				$__ = mb_strlen($_);
			else
				$__ = strlen($_);
			if ($__ < 3) {
				$this->error(\XF::phrase('cnet_title_length_min_3'));
				return false;
			} else {
				$___ = str_replace(['"', "'", "`"], '', $_);
				$____ = $this->finder('XFRM:ResourceItem')
					->whereOr(['resource_state', '=', 'visible'], ['scheduled', '>', 0])
					->where('resource_id', '<>', $this->resource_id)
					->where('resource_category_id', '=', $this->resource_category_id)
					->where('title', 'LIKE', $___)
					->fetchOne();
				if ($____) {
					$_____ = $this->app()->router('public')->buildLink('resources', $____);
					$this->error(\XF::phrase('cnet_title_exists_x', ['link' => $_____]));
					return false;
				}
			}
		}
		return parent::_preSave();
	}
	protected function _postDelete()
	{
		parent::_postDelete();
		if ($this->Language)
			$this->Language->delete();
	}
	public static function getStructure(Structure $_)
	{
		$_ = parent::getStructure($_);
		$_->columns += [
			'image' => ['type' => self::STR, 'default' => ''],
			'icon' => ['type' => self::STR, 'default' => ''],
			'description' => ['type' => self::STR, 'default' => ''],
			'scheduled' => ['type' => self::UINT, 'default' => 0],
			'translation_group' => ['type' => self::UINT, 'default' => 0]
		];
		$_->relations += [
			'Translation' => [
				'entity' => "CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e",
				'type' => self::TO_MANY,
				'conditions' => [
					['group_id', '=', '$translation_group'],
					['content_type', '=', 'resource'],
					['content_id', '<>', '$resource_id']
				],
				'with' => ['ResourceItem']
			],
			'Language' => [
				'entity' => "CNet\x3a\x54\x72\x61\x6e\x73\x6c\x61\x74\x69\x6f\x6e",
				'type' => self::TO_ONE,
				'conditions' => [
					['group_id', '=', '$translation_group'],
					['content_id', '=', '$resource_id'],
					['content_type', '=', 'resource']
				]
			],
			'CurrentVersionAttachments' => [
				'entity' => 'XF:Attachment',
				'type' => self::TO_MANY,
				'conditions' => [
					['content_type', '=', 'resource_version'],
					['content_id', '=', '$current_version_id']
				]
			]
		];
		return $_;
	}
	protected function repoUtility()
	{
		return $this->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */