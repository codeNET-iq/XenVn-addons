<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
use XF\Mvc\Entity\Structure;
class Attachment extends XFCP_Attachment
{
	protected $_ = '';
	public function canView(&$__ = null)
	{
		if (!$this->app()->options()->cnet_view_all_image || !$this->has_thumbnail)
			return parent::canView($__);
		return true;
	}
	public function getDirectUrl(bool $__ = false): string
	{
		if ($this->app()->options()->cnet_external_storage && $this->storage && ($this->Data->file_path || $this->has_thumbnail) && $this->canView()) {
			[$___, $____] = $this->getExternalStorageUrl();
			if ($___) {
				if ($____ == 'url')
					return $___;
				else if ($____ == 'path')
					return $this->app()->router('public')->buildLink('full:attachments', $this);
			}
		}
		return parent::getDirectUrl($__);
	}
	public function getRealFilePath($__ = false, $___ = false)
	{
		if ($___)
			$____ = $this->Data->getExistingAbstractedDataPath();
		else
			$____ = $this->Data->getAbstractedDataPath();
		if (strpos($____, '://') < 1)
			return false;
		$_____ = explode('://', $____, 2);
		$______ = [
			'data' => $this->app()->config('externalDataPath'),
			'internal-data' => $this->app()->config('internalDataPath')
		];
		$_______ = $_____[0];
		if (!isset($______[$_______]))
			return false;
		if ($__)
			return str_replace('\\', '/', $______[$_______] . '/' . $_____[1]);
		return str_replace('\\', '/', \XF::getRootDirectory() . '/' . $______[$_______] . '/' . $_____[1]);
	}
	public function getExternalStorageUrl($__ = false)
	{
		if (!$this->storage)
			return false;
		$___ = $this->app()->options();
		$____ = $___->cnet_external_storage;
		$_____ = $___->cnet_external_storage_type;
		$______ = $___->cnet_external_storage_key;
		$_______ = $___->cnet_external_storage_url;
		if (!$____ || ($_____ == 'url' && (!$______ || !$_______)) || ($_____ == 'path' && !$_______))
			return false;
		$________ = str_replace('\\', '/', \XF::getRootDirectory());
		if ($__) {
			$_________ = $___->cnet_external_shared_folder;
			$_________ = ltrim($_________, "/\\");
			$__________ = $________ . '/' . $_________;
			if (!is_dir($__________) || !is_writable($__________))
				$_________ = '';
			if ($_____ == 'url' && $_________) {
				$_____ = 'path';
				$_______ = $_________;
			}
		}
		$___________ = $this->getRealFilePath(true);
		if ($_____ == 'url') {
			if ($this->canView() && ($this->has_thumbnail || $this->is_audio || $this->is_video || (!$___->cnet_add_redirect_page && !$___->cnet_limit_download)))
				$____________ = 0;
			else
				$____________ = round(\XF::$time / 60) * 60;
			$_____________ = $______________ = $this->filename;
			$_______________ = trim($___->cnet_attachment_prefix);
			$________________ = trim($_______________, " {}[]()-_");
			if ($_______________ && stripos($_____________, $________________) === false) {
				if (!$________________ || $_______________ == $________________ || stripos($_____________, $________________) === false)
					$______________ = $_______________ . ' ' . $______________;
			}
			$_________________ = trim($___->cnet_attachment_suffix);
			$__________________ = trim($_________________, " {}[]()-_");
			if ($_________________ && stripos($_____________, $__________________) === false) {
				if (!$__________________ || $_______________ == $__________________ || stripos($_____________, $__________________) === false) {
					$___________________ = pathinfo($______________);
					$______________ = $___________________['filename'] . ' ' . $_________________ . '.' . $___________________['extension'];
				}
			}
			$____________________ = $____________ . '|' . $___________ . '|' . $______________;
			$____________________ = openssl_encrypt($____________________, "AES-128-ECB", $______);
			$____________________ = rawurlencode($____________________);
			$_______ = $_______ . '?download=' . $____________________;
		} else if ($_____ == 'path') {
			$_______ = ltrim($_______, "/\\");
			$_______ = str_replace('\\', '/', $________ . '/' . $_______ . '/' . $___________);
		}
		return [$_______, $_____];
	}
	public function getInLanguage($__ = '')
	{
		if ($__)
			$this->_ = $__;
		return $this->_;
	}
	protected function _preSave()
	{
		$__ = $this->app()->options();
		$___ = $this->attachment_id;
		if ($___) {
			if ($__->cnet_malware_scanner && in_array($this->Data->extension, ['php', 'zip', 'txt'])) {
				$this->app()->jobManager()->enqueueUnique(
					'cnetScanAttachment' . $___,
					"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
					['job_type' => 'scan_attachment', 'attachment_id' => $___],
					false
				);
			}
		}
		return parent::_preSave();
	}
	protected function _postDelete()
	{
		$__ = $this->app()->options();
		$___ = $this->attachment_id;
		if ($___) {
			if (($__->cnet_optimal_meta_data || $__->cnet_thread_detail) && ($this->content_type == 'post' || $this->content_type == 'resource_update')) {
				$____ = $this->app()->router('public')->buildLink('full:attachments', $this);
				if ($____) {
					$this->app()->jobManager()->enqueueUnique(
						'cnetPostDeleteAttachment' . $___,
						"CNet\x3a\x52\x65\x62\x75\x69\x6c\x64\x44\x61\x74\x61",
						['job_type' => 'post_delete_attachment', 'url' => $____],
						false
					);
				}
			}
			if ($this->storage && $__->cnet_external_storage) {
				$_____ = $this->getRealFilePath();
				if ($_____) {
					$this->app()->jobManager()->enqueueUnique(
						'cnetDeleteExternalStorage' . $___,
						"CNet\x3a\x54\x6f\x6f\x6c\x73\x5c\x45\x78\x74\x65\x72\x6e\x61\x6c\x53\x74\x6f\x72\x61\x67\x65",
						['delete' => $_____],
						false
					);
				}
			}
		}
		return parent::_postDelete();
	}
	public static function getStructure(Structure $__)
	{
		$__ = parent::getStructure($__);
		$__->columns += [
			'storage' => ['type' => self::BOOL, 'default' => 0],
			'scan' => ['type' => self::STR, 'default' => '']
		];
		$__->relations += [
			'Post' => [
				'entity' => 'XF:Post',
				'type' => self::TO_ONE,
				'conditions' => [['post_id', '=', '$content_id']]
			],
			'ResourceUpdate' => [
				'entity' => 'XFRM:ResourceUpdate',
				'type' => self::TO_ONE,
				'conditions' => [['resource_update_id', '=', '$content_id']]
			],
			'ResourceVersion' => [
				'entity' => 'XFRM:ResourceVersion',
				'type' => self::TO_ONE,
				'conditions' => [['resource_version_id', '=', '$content_id']]
			]
		];
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */