<?php
/* Developed by CNet Tools */
namespace CNet\Entity;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
class DownloadLog extends Entity
{
	public static function getStructure(Structure $_)
	{
		$_->table = 'xf_download_log';
		$_->shortName = "CNet\x3a\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x4c\x6f\x67";
		$_->primaryKey = 'log_id';
		$_->columns = [
			'log_id' => ['type' => self::UINT, 'autoIncrement' => true],
			'user_id' => ['type' => self::UINT, 'default' => 0],
			'attachment_id' => ['type' => self::UINT, 'default' => 0],
			'content_id' => ['type' => self::UINT, 'default' => 0],
			'category_id' => ['type' => self::UINT, 'default' => 0],
			'type' => ['type' => self::STR, 'default' => ''],
			'ip' => ['type' => self::STR, 'default' => ''],
			'log_time' => ['type' => self::UINT, 'default' => \XF::$time]
		];
		$_->getters = [];
		$_->relations = [
			'User' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => 'user_id'
			],
			'Attachment' => [
				'entity' => 'XF:Attachment',
				'type' => self::TO_ONE,
				'conditions' => 'attachment_id'
			],
			'Node' => [
				'entity' => 'XF:Node',
				'type' => self::TO_ONE,
				'conditions' => [
					['node_id', '=', '$category_id']
				]
			],
			'Thread' => [
				'entity' => 'XF:Thread',
				'type' => self::TO_ONE,
				'conditions' => [
					['thread_id', '=', '$content_id']
				]
			],
			'ResourceVersion' => [
				'entity' => 'XFRM:ResourceVersion',
				'type' => self::TO_ONE,
				'conditions' => [
					['resource_version_id', '=', '$attachment_id']
				]
			],
			'Category' => [
				'entity' => 'XFRM:Category',
				'type' => self::TO_ONE,
				'conditions' => [
					['resource_category_id', '=', '$category_id']
				]
			],
			'ResourceItem' => [
				'entity' => 'XFRM:ResourceItem',
				'type' => self::TO_ONE,
				'conditions' => [
					['resource_id', '=', '$content_id']
				]
			]
		];
		return $_;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */