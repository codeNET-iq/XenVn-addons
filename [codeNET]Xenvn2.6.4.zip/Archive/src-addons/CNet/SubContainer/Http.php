<?php
namespace CNet\SubContainer;
use GuzzleHttp\Client;
use XF\Http\Reader;
use Psr\Http\Message\ResponseInterface;
class Http extends XFCP_Http
{
	public function initialize()
	{
		$_ = $this->container;
		$_['client'] = function ($__) {
			return $this->createClient();
		};
		$_['clientUntrusted'] = function ($__) {
			$___ = ['allow_redirects' => false];
			$config = $this->app->config();
			if ($config['http']['proxy']) {
				$___['proxy'] = $config['http']['proxy'];
			}
			$this->app->fire('http_client_options_untrusted', [&$___]);
			$____ = $this->createClient($___);
			$this->app->fire('http_client_config_untrusted', [&$____]);
			return $____;
		};
		$_['reader'] = function ($__) {
			$_____ = new class($__['client'], $__['clientUntrusted']) extends Reader {
				public function requestUntrusted($______, $_______, array $________ = [], $_________ = null, array $___ = [], &$__________ = null)
				{
					$_______ = $this->repoUtility()->getWorkerUrl($_______);
					return parent::requestUntrusted($______, $_______, $________, $_________, $___, $__________);
				}
				protected function repoUtility()
				{
					return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
				}
			};
			return $_____;
		};
		$_['metadataFetcher'] = function ($__) {
			$___________ = $this->extendClass('\XF\Http\MetadataFetcher');
			return new $___________($this->app, $__['reader']);
		};
	}
	public function createClient(array $_ = [])
	{
		$_ = $this->applyDefaultClientOptions($_);
		if (\XF::$versionId >= 2030035) {
			$__ = new class($_) extends Client {
				public function request(string $___, $____ = '', array $_ = []): ResponseInterface
				{
					$____ = $this->repoUtility()->getWorkerUrl($____);
					return parent::request($___, $____, $_);
				}
				protected function repoUtility()
				{
					return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
				}
			};
		} else {
			$__ = new class($_) extends Client {
				public function request($___, $____ = '', array $_ = [])
				{
					$____ = $this->repoUtility()->getWorkerUrl($____);
					return parent::request($___, $____, $_);
				}
				protected function repoUtility()
				{
					return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
				}
			};
		}
		$this->app->fire('http_client_config', [&$__]);
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */