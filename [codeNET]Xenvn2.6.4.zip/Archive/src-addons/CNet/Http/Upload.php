<?php
/* Developed by CNet Tools */
namespace CNet\Http;
class Upload_CNet extends XFCP_Upload
{
	protected $_ = false;
	public function setOptimize(bool $__)
	{
		$this->optimize = $__;
	}
	public function applyConstraints(array $__)
	{
		$this->_ = true;
		if (\XF::$versionId < 2030035 && defined('IMAGETYPE_WEBP') && \XF::app()->options()->cnet_convert_avif)
			$this->optimize = true;
		return parent::applyConstraints($__);
	}
	public function transformImage()
	{
		if ($this->transformed || !$this->tempFile)
			return $this;
		$this->transformed = true;
		$__ = \XF::app();
		$___ = $__->options();
		$____ = (\XF::$versionId >= 2030035 ? $___->imageOptimization : false);
		$_____ = ($____ || $this->optimize);
		if (defined('IMAGETYPE_AVIF') && $this->extension == 'avif' && $___->cnet_convert_avif) {
			$______ = false;
			if ($___->imageLibrary == 'imPecl' && class_exists('Imagick')) {
				$_______ = new \Imagick($this->tempFile);
				if ($_______) {
					if ($_____)
						$_______->setImageFormat('webp');
					else
						$_______->setImageFormat('jpg');
					$_______->setImageCompressionQuality(85);
					$______ = $_______->writeImages($this->tempFile, true);
					$_______->clear();
				}
			} else {
				$_______ = @imagecreatefromavif($this->tempFile);
				if ($_______) {
					imagepalettetotruecolor($_______);
					imagealphablending($_______, false);
					imagesavealpha($_______, true);
					if ($_____)
						$______ = imagewebp($_______, $this->tempFile, 85);
					else
						$______ = imagejpeg($_______, $this->tempFile, 85);
					imagedestroy($_______);
				}
			}
			if ($______) {
				$________ = @getimagesize($this->tempFile);
				if ($_____)
					$_________ = '.webp';
				else
					$_________ = '.jpg';
				$this->setFileName(pathinfo($this->fileName, PATHINFO_FILENAME) . $_________);
				$this->isImage = true;
				$this->imageType = $________[2];
				$this->imageWidth = $________[0];
				$this->imageHeight = $________[1];
				clearstatcache();
				$this->fileSize = filesize($this->tempFile);
			} else
				$this->isImage = false;
		}
		if ($this->extension == 'jfif' && $___->cnet_convert_avif) {
			$________ = @getimagesize($this->tempFile);
			if ($_____)
				$_________ = '.webp';
			else
				$_________ = '.jpg';
			$this->setFileName(pathinfo($this->fileName, PATHINFO_FILENAME) . $_________);
			$this->isImage = true;
			$this->imageType = $________[2];
			$this->imageWidth = $________[0];
			$this->imageHeight = $________[1];
			clearstatcache();
			$this->fileSize = filesize($this->tempFile);
		}
		$__________ = $this->repoUtility();
		if ($this->extension == 'zip') {
			$__________->addZipComment($this->tempFile);
			clearstatcache();
			$this->fileSize = filesize($this->tempFile);
		}
		if (!$this->isImage || $this->imageContentUnsafe) {
			return $this;
		}
		$___________ = 0;
		if ($this->exif && !empty($this->exif['IFD0']['Orientation']) && $this->exif['IFD0']['Orientation'] > 1) {
			$___________ = $this->exif['IFD0']['Orientation'];
		}
		$____________ = ($___________ > 1);
		$_____________ = $this->maxWidth;
		$______________ = $this->maxHeight;
		if ($___________ >= 5 && $___________ <= 8) {
			$______________ = $this->maxWidth;
			$_____________ = $this->maxHeight;
		}
		$_______________ = (
			($_____________ && $this->imageWidth > $_____________)
			|| ($______________ && $this->imageHeight > $______________)
		);
		$________________ = $___->cnet_image_watermark && $this->_ && $this->extension != 'gif';
		$_________________ = ($this->optimize && !$this->isOptimized);
		if ($_______________ || $____________ || $_________________ || $________________) {
			$__________________ = $__->imageManager();
			if ($__________________->canResize($this->imageWidth, $this->imageHeight)) {
				$_______ = $__________________->imageFromFile($this->tempFile);
				if ($_______) {
					$___________________ = false;
					if ($_______________) {
						$_______->resize($_____________ ?: $______________, $______________ ?: null);
						$this->imageWidth = $_______->getWidth();
						$this->imageHeight = $_______->getHeight();
						$___________________ = true;
					}
					if ($____________) {
						$_______->transformByExif($___________);
						$___________________ = true;
					}
					if ($________________) {
						$__________->addWatermark($_______);
						$___________________ = true;
					}
					if ($_________________) {
						$____________________ = $_______->optimizeImage($this->tempFile);
						if ($____________________) {
							$this->isOptimized = true;
							$this->setFileName(pathinfo($this->fileName, PATHINFO_FILENAME) . '.webp');
							$___________________ = true;
						}
					}
					if ($___________________ && $_______->save($this->tempFile)) {
						$this->imageWidth = $_______->getWidth();
						$this->imageHeight = $_______->getHeight();
						clearstatcache();
						$this->fileSize = filesize($this->tempFile);
					}
				} else
					$this->isImage = false;
			}
		}
		return $this;
	}
	protected function getImageExtensionMap()
	{
		$__ = parent::getImageExtensionMap();
		if (!isset($__['webp']))
			$__['webp'] = IMAGETYPE_WEBP;
		if (!isset($__['ico']))
			$__['ico'] = IMAGETYPE_ICO;
		return $__;
	}
	public function getFileWrapper()
	{
		if (\XF::$versionId >= 2030035)
			return parent::getFileWrapper();
		if (!$this->tempFile)
			throw new \LogicException("Cannot get file wrapper for invalid upload (no temp file)");
		$__ = \XF::extendClass('\CNet\FileWrapper');
		$___ = new $__($this->tempFile, $this->fileName);
		if (is_array($this->exif))
			$___->setExif($this->exif);
		return $___;
	}
	protected function repoUtility()
	{
		return \XF::app()->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}
if (\XF::$versionId >= 2030035) {
	class Upload extends Upload_CNet {}
} else {
	class Upload extends Upload_CNet
	{
		protected $optimize = false;
		protected $isOptimized = false;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */