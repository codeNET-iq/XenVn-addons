<?php
/* Developed by CNet Tools */
namespace CNet\Sitemap;
class Thread extends XFCP_Thread
{
	public function getRecords($_)
	{
		$__ = $this->app;
		if (!$__->options()->cnet_multilingual_content)
			return parent::getRecords($_);
		$___ = \XF::visitor();
		$____ = $this->getIds('xf_thread', 'thread_id', $_);
		$_____ = $__->finder('XF:Thread');
		$______ = $_____
			->where('thread_id', $____)
			->with(['Forum', 'Forum.Node', 'Forum.Node.Permissions|' . $___->permission_combination_id, 'Language'])
			->order('thread_id')
			->fetch();
		return $______;
	}
	public function getEntry($_)
	{
		$__ = $this->app;
		$___ = $__->options();
		if ($___->cnet_multilingual_content) {
			$____ = $this->app->extendClass('\CNet\Sitemap\Entry');
			$_____ = $____::create($_->getContentUrl(true), [
				'lastmod' => $_->last_post_date,
			]);
		} else
			$_____ = parent::getEntry($_);
		if ($___->cnet_optimize_sitemap)
			$_____->set('image', $_->getCoverImage());
		if ($___->cnet_multilingual_content && $_->translation_group) {
			$______ = $_->Translation;
			if ($______ && count($______->toArray())) {
				$_______ = $this->repoUtility()->getDefaultLanguageCode();
				$________ = [];
				$_________ = $_->Language;
				if ($_________) {
					$__________ = $_________->language_code;
					$___________ = $__->router('public')->buildLink('canonical:threads', $_);
					$________[] = ['hreflang' => $__________, 'href' => $___________];
					if ($__________ == $_______) {
						$________[] = ['hreflang' => 'x-default', 'href' => $___________];
						$_______ = 0;
					}
				}
				foreach ($______ as $____________) {
					$_____________ = $____________->Thread;
					$__________ = $____________->language_code;
					$___________ = $__->router('public')->buildLink('canonical:threads', $_____________);
					$________[] = ['hreflang' => $__________, 'href' => $___________];
					if ($_______ && $__________ == $_______) {
						$________[] = ['hreflang' => 'x-default', 'href' => $___________];
						$_______ = 0;
					}
				}
				if (count($________))
					$_____->set('alternates', $________);
			}
		}
		return $_____;
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */