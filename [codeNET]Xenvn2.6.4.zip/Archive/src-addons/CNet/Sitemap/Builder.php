<?php
/* Developed by CNet Tools */
namespace CNet\Sitemap;
use XF\Sitemap\Entry;
class Builder extends XFCP_Builder
{
	protected function getPreamble()
	{
		if (!$this->app->options()->cnet_multilingual_content)
			return parent::getPreamble();
		return '<?xml version="1.0" encoding="UTF-8"?>'
			. "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"'
			. ' xmlns:xhtml="http://www.w3.org/1999/xhtml"'
			. ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
	}
	protected function buildEntryXml(Entry $_)
	{
		if (!$this->app->options()->cnet_multilingual_content)
			return parent::buildEntryXml($_);
		$__ = '<url>' . $this->buildSimpleTag($_, 'loc');
		if ($_->lastmod)
			$__ .= $this->buildSimpleTag($_, 'lastmod', gmdate(\DateTime::W3C, $_->lastmod));
		if ($_->priority)
			$__ .= $this->buildSimpleTag($_, 'priority');
		if ($_->changefreq)
			$__ .= $this->buildSimpleTag($_, 'changefreq');
		if ($_->image) {
			if (!is_array($_->image) || isset($_->image['loc']))
				$___ = [$_->image];
			else
				$___ = $_->image;
			foreach ($___ as $____) {
				if (!is_array($____))
					$____ = ['loc' => $____];
				$__ .= '<image:image>';
				foreach ($____ as $_____ => $______)
					$__ .= $this->buildSimpleTag($_, "image:$_____", $______);
				$__ .= '</image:image>';
			}
		}
		if (isset($_->alternates)) {
			$_______ = $_->alternates;
			if (is_array($_______) && count($_______)) {
				foreach ($_______ as $______) {
					$__ .= '<xhtml:link rel="alternate" hreflang="' . $______['hreflang'] . '" href="' . $______['href'] . '" />';
				}
			}
		}
		$__ .= '</url>';
		return $__;
	}
	protected function writeCoreData()
	{
		parent::writeCoreData();
		$_ = $this->app;
		$__ = $_->router('public');
		if ($_->options()->cnet_seo_keywords) {
			$___ = $this->repoUtility()->getCache("cnet\x4b\x65\x79\x77\x6f\x72\x64\x73");
			if (!$___ || !is_array($___) || !count($___))
				return;
			foreach ($___ as $____ => $_____) {
				$______ = $__->buildLink('canonical:contents/' . $_____['url'] . '/');
				$_______ = $_____['lastmod'];
				$________ = Entry::create($______);
				if ($_______)
					$________->set('lastmod', $_______);
				$this->writeEntry($________);
			}
		}
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */