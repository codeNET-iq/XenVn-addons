<?php
/* Developed by CNet Tools */
namespace CNet\Sitemap;
class Node extends XFCP_Node
{
	public function getEntry($_)
	{
		$__ = parent::getEntry($_);
		$___ = $this->app;
		if ($___->options()->cnet_optimize_sitemap) {
			$____ = $___->finder('XF:Thread')
				->where('node_id', $_->node_id)
				->where('discussion_state', 'visible')
				->where('discussion_type', '<>', 'redirect')
				->order('post_date', 'DESC')
				->limit(1)
				->fetchOne();
			if ($____)
				$__->set('lastmod', $____->post_date);
		}
		return $__;
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */