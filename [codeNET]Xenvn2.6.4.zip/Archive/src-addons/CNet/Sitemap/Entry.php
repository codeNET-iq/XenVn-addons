<?php
/* Developed by CNet Tools */
namespace CNet\Sitemap;
use function intval, strval;
class Entry extends \XF\Sitemap\Entry
{
	public $loc;
	public $lastmod;
	public $changefreq;
	public $priority;
	public $image;
	public $alternates;
	public function __construct($_, $__, $___, $____, $_____, $______)
	{
		$this->loc = strval($_);
		$this->lastmod = intval($__);
		$this->changefreq = $___;
		$this->priority = $____;
		$this->image = $_____;
		$this->alternates = $______;
	}
	public function set($_______, $________)
	{
		$this->{$_______} = $________;
	}
	public static function create($_, array $_________ = [])
	{
		$_________ = array_merge([
			'lastmod' => 0,
			'changefreq' => '',
			'priority' => '',
			'image' => '',
			'alternates' => '',
		], $_________);
		return new self($_, $_________['lastmod'], $_________['changefreq'], $_________['priority'], $_________['image'], $_________['alternates']);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */