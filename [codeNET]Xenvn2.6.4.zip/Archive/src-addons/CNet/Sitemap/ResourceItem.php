<?php
/* Developed by CNet Tools */
namespace CNet\Sitemap;
class ResourceItem extends XFCP_ResourceItem
{
	public function getRecords($_)
	{
		$__ = $this->app;
		if (!$__->options()->cnet_multilingual_content)
			return parent::getRecords($_);
		$___ = \XF::visitor();
		$____ = $this->getIds('xf_rm_resource', 'resource_id', $_);
		$_____ = $__->finder('XFRM:ResourceItem');
		$______ = $_____
			->where('resource_id', $____)
			->with(['Category', 'Category.Permissions|' . $___->permission_combination_id, 'Language'])
			->order('resource_id')
			->fetch();
		return $______;
	}
	public function getEntry($_)
	{
		$__ = $this->app;
		$___ = $__->options();
		if ($___->cnet_multilingual_content) {
			$____ = $this->app->extendClass('\CNet\Sitemap\Entry');
			$_____ = $__->router('public')->buildLink('canonical:resources', $_);
			$______ = $____::create($_____, [
				'lastmod' => $_->last_update,
			]);
		} else
			$______ = parent::getEntry($_);
		if ($___->cnet_optimize_sitemap) {
			if ($___->cnet_optimal_meta_data && $___->cnet_view_all_image && $_->image)
				$______->set('image', $_->image);
			else
				$______->set('image', $_->getIconUrl(null, true));
		}
		if ($___->cnet_multilingual_content && $_->translation_group) {
			$_______ = $_->Translation;
			if ($_______ && count($_______->toArray())) {
				$________ = $this->repoUtility()->getDefaultLanguageCode();
				$_________ = [];
				$__________ = $_->Language;
				if ($__________) {
					$___________ = $__________->language_code;
					$_____ = $__->router('public')->buildLink('canonical:resources', $_);
					$_________[] = ['hreflang' => $___________, 'href' => $_____];
					if ($___________ == $________) {
						$_________[] = ['hreflang' => 'x-default', 'href' => $_____];
						$________ = 0;
					}
				}
				foreach ($_______ as $____________) {
					$_____________ = $____________->ResourceItem;
					$___________ = $____________->language_code;
					$_____ = $__->router('public')->buildLink('canonical:resources', $_____________);
					$_________[] = ['hreflang' => $___________, 'href' => $_____];
					if ($________ && $___________ == $________) {
						$_________[] = ['hreflang' => 'x-default', 'href' => $_____];
						$________ = 0;
					}
				}
				if (count($_________))
					$______->set('alternates', $_________);
			}
		}
		return $______;
	}
	protected function repoUtility()
	{
		return $this->app->repository("CNet\x3a\x55\x74\x69\x6c\x69\x74\x79");
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */