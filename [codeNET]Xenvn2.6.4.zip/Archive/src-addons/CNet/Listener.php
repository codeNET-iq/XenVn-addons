<?php
/* Developed by CNet Tools */
namespace CNet;
class Listener
{
	public static function app_complete(\XF\App $_, \XF\Http\Response &$__)
	{
		if ($__->contentType() == 'text/html') {
			$___ = $_->options->cnet_minify_html_code ?? false;
			if ($___) {
				$____ = $__->body();
				$_____ = array(
					'#(?s)(<(?:pre|textarea)[^>]*>.*?<\/(?:pre|textarea)>)(*SKIP)(*F)|^\s*(\r?\n)+|^\s+#m' => '',
					'#(?s)(>.*?<)(*SKIP)(*F)|(\S)\s+(\S)#m' => "$2 $3",
					'#(?s)(>.*?<)(*SKIP)(*F)|(\S=)"\s*([^"\']+)\s+"#m' => "$2\"$3\""
				);
				$____ = preg_replace(array_keys($_____), array_values($_____), $____);
				$__->body($____);
			}
		}
	}
	public static function app_setup(\XF\App $_)
	{
		if (\XF::$versionId < 2030035)
			$_['inlineImageTypes'] += ['webp' => 'image/webp'];
		$__ = ["cnet\x5f\x6c\x69\x63\x65\x6e\x73\x65", "cnet\x4b\x65\x79", "cnet\x44\x61\x74\x61", 'cnet_verify_email', 'cnet_external_storage_key', "cnet\x43\x61\x63\x68\x65", 'cnet_sms_key', 'proxy_key', 'cnet_cf_worker_url', 'cnet_cf_worker_secret'];
		foreach ($__ as $___) {
			$_->request()->skipKeyForLogging($___);
		}
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */