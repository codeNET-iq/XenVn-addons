<?php
/* Developed by CNet Tools */
namespace CNet;
class FileWrapper extends \XF\FileWrapper
{
	protected function analyzeImage()
	{
		if (\XF::$versionId >= 2030035 || $this->extension != 'webp')
			return parent::analyzeImage();
		$this->isImage = false;
		if (!$this->fileSize)
			return;
		$_ = [
			'gif' => IMAGETYPE_GIF,
			'jpg' => IMAGETYPE_JPEG,
			'jpeg' => IMAGETYPE_JPEG,
			'jpe' => IMAGETYPE_JPEG,
			'png' => IMAGETYPE_PNG,
			'webp' => IMAGETYPE_WEBP
		];
		if (!isset($_[$this->extension]))
			return;
		$__ = @getimagesize($this->filePath);
		if (!$__)
			return;
		$___ = $__[2];
		if (!in_array($___, $_))
			return;
		if ($___ != $_[$this->extension]) {
			foreach ($_ as $____ => $_____) {
				if ($___ == $_____) {
					$this->fileName .= ".$____";
					break;
				}
			}
		}
		$this->isImage = true;
		$this->imageInfo = $__;
		$this->exif = array_replace_recursive($this->exif ?? [], []);
	}
}

/* Build time: 2026-08-29 / 09:12 (GMT+7) - CNet Tools */