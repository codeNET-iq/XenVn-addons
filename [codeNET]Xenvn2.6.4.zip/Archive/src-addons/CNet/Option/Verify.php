<?php
/**
 * CNet Tools option validation and option controls.
 *
 * The original package replaced these callbacks with a textarea.  That made
 * array options impossible to configure and caused the statistics selector,
 * node selectors and user-group selectors to disappear from the ACP.
 */
namespace CNet\Option;

use XF\Entity\Option;

class Verify
{
    public static function verifyImagePath(&$value, Option $option)
    {
        $value = trim((string)$value);
        if ($value !== '' && strlen($value) > 1000)
        {
            $option->error('The image path is too long.', $option->option_id);
            return false;
        }

        return true;
    }

    public static function verifyMin30(&$value, Option $option)
    {
        $value = (int)$value;
        if ($value > 0 && $value < 30)
        {
            $option->error('The value must be 0 or at least 30.', $option->option_id);
            return false;
        }

        return true;
    }

    public static function verifyIds(&$value, Option $option)
    {
        $value = trim((string)$value);
        if ($value === '')
        {
            return true;
        }

        foreach (preg_split('/\s*,\s*/', $value) as $id)
        {
            if ($id !== '' && !preg_match('/^\d+$/', $id))
            {
                $option->error('Use numeric IDs separated by commas.', $option->option_id);
                return false;
            }
        }

        return true;
    }

    public static function verifyWorkersURL(&$value, Option $option)
    {
        $value = trim((string)$value);
        if ($value !== '' && !filter_var($value, FILTER_VALIDATE_URL))
        {
            $option->error('Enter a valid worker URL.', $option->option_id);
            return false;
        }

        return true;
    }

    public static function verifyExternalStoragePath(&$value, Option $option)
    {
        $value = trim((string)$value);
        if ($value !== '' && !preg_match('#^(https?://|/|[A-Za-z]:[\\\\/])#i', $value))
        {
            $option->error('Enter an absolute path or an HTTP(S) URL.', $option->option_id);
            return false;
        }

        return true;
    }

    public static function verifyRebuildTemplate(&$value, Option $option)
    {
        $value = (int)(bool)$value;
        return true;
    }

    public static function verifyOptimizeSitemap(&$value, Option $option)
    {
        $value = (int)(bool)$value;
        return true;
    }

    public static function verifyOptimizeXF(&$value, Option $option)
    {
        $value = (int)(bool)$value;
        return true;
    }

    public static function verifyRemoveRoute(&$value, Option $option)
    {
        $value = (int)(bool)$value;
        return true;
    }

    public static function verifySeoKeywords(&$value, Option $option)
    {
        $value = trim((string)$value);
        if (strlen($value) > 5000)
        {
            $option->error('SEO keywords are limited to 5000 characters.', $option->option_id);
            return false;
        }

        return true;
    }

    public static function verifySMSKey(&$value, Option $option)
    {
        $value = trim((string)$value);
        return strlen($value) <= 500
            ? true
            : self::error($option, 'The SMS key is too long.');
    }

    public static function verifySMSPhone(&$value, Option $option)
    {
        $value = trim((string)$value);
        if ($value !== '' && !preg_match('/^\+[0-9]{7,15}$/', $value))
        {
            return self::error($option, 'Use an international phone number beginning with +.');
        }

        return true;
    }

    public static function verifySMSServer(&$value, Option $option)
    {
        $value = in_array((string)$value, ['0', 'self'], true)
            ? (string)$value
            : '0';
        return true;
    }

    public static function verifySMS(&$value, Option $option)
    {
        $value = (int)(bool)$value;
        return true;
    }

    public static function verifyStatisticsTabs(&$value, Option $option)
    {
        $allowed = [
            'forum-last-thread',
            'forum-most-view',
            'forum-sticky-thread',
            'new-resources',
            'top-resources',
            'top-attachments',
            'new-members'
        ];

        $tabs = is_array($value) ? $value : [];
        $value = [];
        foreach ($tabs as $tab)
        {
            $tab = (string)$tab;
            if ($tab !== '' && in_array($tab, $allowed, true) && !in_array($tab, $value, true))
            {
                $value[] = $tab;
            }
            if (count($value) >= 7)
            {
                break;
            }
        }

        return true;
    }

    public static function verifyNodeIcon(&$value, Option $option)
    {
        if (!is_array($value))
        {
            $value = [];
            return true;
        }

        $clean = [];
        foreach ($value as $key => $item)
        {
            if (!ctype_digit((string)$key))
            {
                continue;
            }

            if (is_array($item))
            {
                $clean[(int)$key] = [
                    'icon' => self::cleanIcon($item['icon'] ?? ''),
                    'color' => self::cleanText($item['color'] ?? '', 100)
                ];
            }
            else
            {
                $clean[(int)$key] = self::cleanIcon($item);
            }
        }

        $value = $clean;
        return true;
    }

    public static function renderSelectMultiple(Option $option, array $htmlParams)
    {
        $choices = self::getCategoryChoices($option);
        return self::renderMultiSelect($option, $htmlParams, $choices);
    }

    public static function renderSelectMultipleGroup(Option $option, array $htmlParams)
    {
        $choices = [];
        $groups = \XF::app()->finder('XF:UserGroup')->fetch();
        foreach ($groups as $group)
        {
            if (is_object($group))
            {
                $choices[(string)($group->user_group_id ?? '')] = (string)($group->title ?? '');
            }
            elseif (is_array($group))
            {
                $choices[(string)($group['user_group_id'] ?? '')] = (string)($group['title'] ?? '');
            }
        }

        return self::renderMultiSelect($option, $htmlParams, $choices);
    }

    public static function renderStatisticsTabs(Option $option, array $htmlParams)
    {
        $choices = [
            'forum-last-thread' => self::phrase('cnet_last_thread_name'),
            'forum-most-view' => self::phrase('cnet_most_view_name'),
            'forum-sticky-thread' => self::phrase('stick_threads'),
            'new-resources' => self::phrase('xfrm_new_resources'),
            'top-resources' => self::phrase('xfrm_top_resources'),
            'top-attachments' => self::phrase('cnet_top_attachment_name'),
            'new-members' => self::phrase('cnet_new_member_name')
        ];

        $app = \XF::app();
        $xfrm = $app->addonManager()->getById('XFRM');
        if (!$xfrm || !$xfrm->isActive())
        {
            unset($choices['new-resources'], $choices['top-resources']);
        }

        $current = [];
        $optionValue = is_array($option->option_value) ? $option->option_value : [];
        foreach ($optionValue as $value)
        {
            $value = (string)$value;
            if (isset($choices[$value]) && !in_array($value, $current, true))
            {
                $current[] = $value;
            }
        }

        $inputName = self::inputName($option, $htmlParams);
        $html = '';
        for ($i = 0; $i < 7; $i++)
        {
            $name = $inputName . '[' . ($i + 1) . ']';
            $selected = $current[$i] ?? '';
            $html .= '<div class="inputGroup">'
                . '<span class="input cnet-stabs">' . self::escape(self::phrase('tabs')) . ' #' . ($i + 1) . '</span>'
                . '<span class="inputGroup-splitter"></span>'
                . '<select class="input" name="' . self::escape($name) . '">'
                . '<option value=""></option>';

            foreach ($choices as $value => $label)
            {
                $html .= '<option value="' . self::escape($value) . '"'
                    . ($selected === $value ? ' selected="selected"' : '') . '>'
                    . self::escape($label) . '</option>';
            }

            $html .= '</select></div>';
        }

        return self::renderRow($option, $htmlParams, $html);
    }

    public static function renderUserGroupIcon(Option $option, array $htmlParams)
    {
        $current = is_array($option->option_value) ? $option->option_value : [];
        $html = '';
        $groups = \XF::app()->finder('XF:UserGroup')->fetch();
        foreach ($groups as $group)
        {
            $groupId = is_object($group) ? ($group->user_group_id ?? 0) : (is_array($group) ? ($group['user_group_id'] ?? 0) : 0);
            $groupTitle = is_object($group) ? ($group->title ?? '') : (is_array($group) ? ($group['title'] ?? '') : '');
            
            $id = (int)$groupId;
            $item = is_array($current[$id] ?? null) ? $current[$id] : [];
            $html .= '<div class="inputGroup">'
                . '<span class="input cnet-over-hidden">' . self::escape($groupTitle) . '</span>'
                . '<span class="inputGroup-splitter"></span>'
                . '<input class="input" type="text" name="' . self::escape(self::inputName($option, $htmlParams) . '[' . $id . '][icon]') . '" value="' . self::escape($item['icon'] ?? '') . '" placeholder="fa-star" />'
                . '<span class="inputGroup-splitter"></span>'
                . '<input class="input" type="text" name="' . self::escape(self::inputName($option, $htmlParams) . '[' . $id . '][color]') . '" value="' . self::escape($item['color'] ?? '') . '" placeholder="CSS color" />'
                . '</div>';
        }

        return self::renderRow($option, $htmlParams, $html);
    }

    public static function renderNavigationIcon(Option $option, array $htmlParams)
    {
        $current = is_array($option->option_value) ? $option->option_value : [];
        $names = [
            '_login' => 'Login',
            '_register' => 'Register',
            'home' => 'Home',
            'forums' => 'Forums',
            'whats-new' => "What's new",
            'members' => 'Members',
            'resources' => 'Resources',
            'xfrm' => 'Resources (legacy)',
            'search' => 'Search',
            'cnettools' => 'CNet Tools'
        ];
        foreach ($current as $id => $icon)
        {
            if (!isset($names[$id]))
            {
                $names[$id] = 'Navigation: ' . $id;
            }
        }
        $html = '';
        foreach ($names as $id => $label)
        {
            $html .= '<div class="inputGroup">'
                . '<span class="input cnet-over-hidden">' . self::escape($label) . '</span>'
                . '<span class="inputGroup-splitter"></span>'
                . '<input class="input" type="text" name="' . self::escape(self::inputName($option, $htmlParams) . '[' . $id . ']') . '" value="' . self::escape($current[$id] ?? '') . '" placeholder="fa-star" />'
                . '</div>';
        }

        return self::renderRow($option, $htmlParams, $html);
    }

    public static function renderNodeIcon(Option $option, array $htmlParams)
    {
        $current = is_array($option->option_value) ? $option->option_value : [];
        $html = '';
        foreach (self::getIconNodes() as $node)
        {
            $nodeId = is_object($node) ? ($node->node_id ?? 0) : (is_array($node) ? ($node['node_id'] ?? 0) : 0);
            $nodeTitle = is_object($node) ? ($node->title ?? '') : (is_array($node) ? ($node['title'] ?? '') : '');

            $id = (int)$nodeId;
            $html .= '<div class="inputGroup">'
                . '<span class="input cnet-over-hidden">' . self::escape($nodeTitle) . '</span>'
                . '<span class="inputGroup-splitter"></span>'
                . '<input class="input" type="text" name="' . self::escape(self::inputName($option, $htmlParams) . '[' . $id . ']') . '" value="' . self::escape($current[$id] ?? '') . '" placeholder="fa-comments" />'
                . '</div>';
        }

        return self::renderRow($option, $htmlParams, $html);
    }

    public static function renderOptimizeXF(Option $option, array $htmlParams)
    {
        return self::renderBoolean($option, $htmlParams);
    }

    public static function renderConvertImage(Option $option, array $htmlParams)
    {
        return self::renderBoolean($option, $htmlParams);
    }

    protected static function getCategoryChoices(Option $option)
    {
        $choices = [];
        foreach (self::getForumNodes() as $node)
        {
            $nodeId = is_object($node) ? ($node->node_id ?? '') : (is_array($node) ? ($node['node_id'] ?? '') : '');
            $nodeTitle = is_object($node) ? ($node->title ?? '') : (is_array($node) ? ($node['title'] ?? '') : '');
            $choices[(string)$nodeId] = 'Forum: ' . (string)$nodeTitle;
        }

        $xfrm = \XF::app()->addonManager()->getById('XFRM');
        if ($xfrm && $xfrm->isActive())
        {
            $nodes = \XF::app()->finder('XF:Node')->fetch();
            foreach ($nodes as $node)
            {
                $nodeTypeId = is_object($node) ? ($node->node_type_id ?? '') : (is_array($node) ? ($node['node_type_id'] ?? '') : '');
                $nodeId = is_object($node) ? ($node->node_id ?? 0) : (is_array($node) ? ($node['node_id'] ?? 0) : 0);
                $nodeTitle = is_object($node) ? ($node->title ?? '') : (is_array($node) ? ($node['title'] ?? '') : '');

                if ($nodeTypeId === 'ResourceCategory')
                {
                    $choices['RM' . (int)$nodeId] = 'Resource: ' . (string)$nodeTitle;
                }
            }
        }

        return $choices;
    }

    protected static function getForumNodes()
    {
        $nodes = [];
        $allNodes = \XF::app()->finder('XF:Node')->fetch();
        foreach ($allNodes as $node)
        {
            $nodeTypeId = is_object($node) ? ($node->node_type_id ?? '') : (is_array($node) ? ($node['node_type_id'] ?? '') : '');
            if ($nodeTypeId === 'Forum')
            {
                $nodes[] = $node;
            }
        }

        return $nodes;
    }

    protected static function getIconNodes()
    {
        $nodes = [];
        $allNodes = \XF::app()->finder('XF:Node')->fetch();
        foreach ($allNodes as $node)
        {
            $nodeTypeId = is_object($node) ? ($node->node_type_id ?? '') : (is_array($node) ? ($node['node_type_id'] ?? '') : '');
            if (in_array($nodeTypeId, ['Forum', 'ResourceCategory'], true))
            {
                $nodes[] = $node;
            }
        }

        return $nodes;
    }

    protected static function renderMultiSelect(Option $option, array $htmlParams, array $choices)
    {
        $selected = [];
        $optionValue = is_array($option->option_value) ? $option->option_value : [];
        foreach ($optionValue as $value)
        {
            $selected[(string)$value] = true;
        }

        $name = self::inputName($option, $htmlParams) . '[]';
        $html = '<select class="input" name="' . self::escape($name) . '" multiple="multiple" size="8">';
        foreach ($choices as $value => $label)
        {
            $html .= '<option value="' . self::escape($value) . '"'
                . (isset($selected[(string)$value]) ? ' selected="selected"' : '') . '>'
                . self::escape($label) . '</option>';
        }
        $html .= '</select>';

        return self::renderRow($option, $htmlParams, $html);
    }

    protected static function renderBoolean(Option $option, array $htmlParams)
    {
        $name = self::inputName($option, $htmlParams);
        $html = '<label><input type="checkbox" name="' . self::escape($name)
            . '" value="1"' . ($option->option_value ? ' checked="checked"' : '') . ' /> '
            . self::escape(self::phrase('enabled')) . '</label>';
        return self::renderRow($option, $htmlParams, $html);
    }

    protected static function renderRow(Option $option, array $htmlParams, $control)
    {
        $label = self::escape((string)$option->title);
        $explain = (string)($htmlParams['explainHtml'] ?? '');
        $hint = (string)($htmlParams['hintHtml'] ?? '');
        $listed = (string)($htmlParams['listedHtml'] ?? '');
        return '<dl class="formRow">'
            . '<dt><div class="formRow-label"><label for="' . self::escape($option->option_id) . '">'
            . $label . '</label>' . ($hint ? '<span class="formRow-hint">' . $hint . '</span>' : '') . '</div></dt>'
            . '<dd>' . $control . $listed . ($explain ? '<div class="formRow-explain">' . $explain . '</div>' : '') . '</dd>'
            . '</dl>';
    }

    protected static function inputName(Option $option, array $htmlParams)
    {
        return (string)($htmlParams['name'] ?? 'options[' . $option->option_id . ']');
    }

    protected static function phrase($phrase)
    {
        return (string)\XF::phrase($phrase);
    }

    protected static function escape($value)
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }

    protected static function cleanText($value, $length)
    {
        return substr(trim((string)$value), 0, $length);
    }

    protected static function cleanIcon($value)
    {
        $value = self::cleanText($value, 100);
        if ($value === '')
        {
            return '';
        }

        return preg_match('/^fa-[a-z0-9-]+$/i', $value) ? $value : 'fa-' . ltrim($value, '-');
    }

    protected static function error(Option $option, $message)
    {
        $option->error($message, $option->option_id);
        return false;
    }
}
